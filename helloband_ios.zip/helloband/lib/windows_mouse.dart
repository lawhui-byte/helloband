import 'dart:ffi';
import 'dart:io';

/// Minimal Windows system mouse bridge used by HelloBand Mouse Mode.
/// Uses user32.dll directly, so no additional Flutter package is required.
class WindowsMouse {
  WindowsMouse._();

  static const int _mouseEventMove = 0x0001;
  static const int _mouseEventLeftDown = 0x0002;
  static const int _mouseEventLeftUp = 0x0004;
  static const int _mouseEventWheel = 0x0800;
  static const int _wheelDelta = 120;

  static DynamicLibrary? _library;
  static void Function(int, int, int, int, int)? _mouseEvent;

  static bool get supported => Platform.isWindows;

  static void _ensureLoaded() {
    if (!supported || _mouseEvent != null) return;
    _library = DynamicLibrary.open('user32.dll');
    _mouseEvent = _library!.lookupFunction<
        Void Function(Uint32, Uint32, Uint32, Uint32, IntPtr),
        void Function(int, int, int, int, int)>('mouse_event');
  }

  static int _u32(int value) => value & 0xFFFFFFFF;

  static void moveBy(double dx, double dy) {
    if (!supported) return;
    _ensureLoaded();
    final x = dx.round();
    final y = dy.round();
    if (x == 0 && y == 0) return;
    _mouseEvent?.call(_mouseEventMove, _u32(x), _u32(y), 0, 0);
  }

  static void leftClick() {
    if (!supported) return;
    _ensureLoaded();
    _mouseEvent?.call(_mouseEventLeftDown, 0, 0, 0, 0);
    _mouseEvent?.call(_mouseEventLeftUp, 0, 0, 0, 0);
  }

  /// Positive [steps] scrolls up; negative [steps] scrolls down.
  static void scroll(int steps) {
    if (!supported || steps == 0) return;
    _ensureLoaded();
    final data = steps * _wheelDelta;
    _mouseEvent?.call(_mouseEventWheel, 0, 0, _u32(data), 0);
  }
}
