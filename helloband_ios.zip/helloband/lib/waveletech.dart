import 'dart:async';
import 'dart:collection';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter_libserialport/flutter_libserialport.dart';

const int waveletechBaud = 921600;
const int waveletechPacketSize = 29;
const double gyroScaleRadS = 0.0012;
const double accScaleMS2 = 0.0005978;
const double emgFs = 256.0;
const double hpCutoffHz = 10.0;
const int rmsWindowMs = 200;

class WaveletechPacket {
  WaveletechPacket.emg({
    required this.sequence,
    required this.timestamp,
    required this.emgUv,
  })  : kind = 'AA',
        gyro = null,
        acc = null;

  WaveletechPacket.imu({
    required this.sequence,
    required this.timestamp,
    required this.gyro,
    required this.acc,
  })  : kind = 'BB',
        emgUv = null;

  final String kind;
  final int sequence;
  final DateTime timestamp;
  final List<double>? emgUv;
  final List<double>? gyro;
  final List<double>? acc;
}

class WaveletechPacketParser {
  final List<int> _buffer = <int>[];

  List<WaveletechPacket> add(Uint8List data) {
    _buffer.addAll(data);
    final out = <WaveletechPacket>[];

    while (true) {
      if (_buffer.length < 5) break;

      final idx = _findHeader();
      if (idx < 0) {
        if (_buffer.length > 2) {
          _buffer.removeRange(0, _buffer.length - 2);
        }
        break;
      }

      if (idx > 0) {
        _buffer.removeRange(0, idx);
      }

      if (_buffer.length < waveletechPacketSize) break;
      final type = _buffer[3];
      if (type != 0xAA && type != 0xBB) {
        _buffer.removeAt(0);
        continue;
      }

      final raw = Uint8List.fromList(
        _buffer.sublist(0, waveletechPacketSize),
      );
      _buffer.removeRange(0, waveletechPacketSize);

      final decoded = _decode(raw);
      if (decoded != null) out.add(decoded);
    }

    return out;
  }

  int _findHeader() {
    for (var i = 0; i <= _buffer.length - 3; i++) {
      if (_buffer[i] == 0xD2 &&
          _buffer[i + 1] == 0xD2 &&
          _buffer[i + 2] == 0xD2) {
        return i;
      }
    }
    return -1;
  }

  WaveletechPacket? _decode(Uint8List raw) {
    if (raw.length != waveletechPacketSize) return null;
    if (raw[0] != 0xD2 || raw[1] != 0xD2 || raw[2] != 0xD2) {
      return null;
    }

    final type = raw[3];
    final seq = raw[4];
    final payload = raw.sublist(5, 29);

    if (type == 0xAA) {
      final emg = <double>[];
      for (var i = 0; i < 8; i++) {
        final start = i * 3;
        emg.add(
          _signed24(
            payload[start],
            payload[start + 1],
            payload[start + 2],
          ).toDouble(),
        );
      }
      return WaveletechPacket.emg(
        sequence: seq,
        timestamp: DateTime.now(),
        emgUv: emg,
      );
    }

    if (type == 0xBB) {
      final gx = _signed16(payload[2], payload[3]) * gyroScaleRadS;
      final gy = _signed16(payload[4], payload[5]) * gyroScaleRadS;
      final gz = _signed16(payload[6], payload[7]) * gyroScaleRadS;

      final ax = _signed16(payload[8], payload[9]) * accScaleMS2;
      final ay = _signed16(payload[10], payload[11]) * accScaleMS2;
      final az = _signed16(payload[12], payload[13]) * accScaleMS2;

      return WaveletechPacket.imu(
        sequence: seq,
        timestamp: DateTime.now(),
        gyro: <double>[gx, gy, gz],
        acc: <double>[ax, ay, az],
      );
    }

    return null;
  }

  int _signed24(int b0, int b1, int b2) {
    var value = (b0 << 16) | (b1 << 8) | b2;
    if ((value & 0x800000) != 0) value -= 1 << 24;
    return value;
  }

  int _signed16(int hi, int lo) {
    var value = (hi << 8) | lo;
    if ((value & 0x8000) != 0) value -= 1 << 16;
    return value;
  }
}

class WaveletechSerialService {
  SerialPort? _port;
  SerialPortReader? _reader;
  StreamSubscription<Uint8List>? _subscription;
  final WaveletechPacketParser _parser = WaveletechPacketParser();
  final StreamController<WaveletechPacket> _packetController =
      StreamController<WaveletechPacket>.broadcast();

  Stream<WaveletechPacket> get packets => _packetController.stream;

  List<String> get availablePorts => SerialPort.availablePorts;

  bool get isOpen => _port?.isOpen ?? false;

  Future<void> connect(String portName) async {
    await disconnect();

    final port = SerialPort(portName);
    if (!port.openReadWrite()) {
      throw Exception(
        'Unable to open $portName: ${SerialPort.lastError}',
      );
    }

    final config = SerialPortConfig();
    config.baudRate = waveletechBaud;
    config.bits = 8;
    config.stopBits = 1;
    config.parity = SerialPortParity.none;
    port.config = config;

    _port = port;
    _reader = SerialPortReader(port);
    _subscription = _reader!.stream.listen(
      (data) {
        for (final packet in _parser.add(data)) {
          _packetController.add(packet);
        }
      },
      onError: (Object error, StackTrace stackTrace) {
        _packetController.addError(error, stackTrace);
      },
    );
  }

  Future<void> disconnect() async {
    await _subscription?.cancel();
    _subscription = null;
    _reader = null;

    final port = _port;
    _port = null;
    if (port != null) {
      if (port.isOpen) port.close();
      port.dispose();
    }
  }

  Future<void> dispose() async {
    await disconnect();
    await _packetController.close();
  }
}

class EmgProcessor {
  EmgProcessor() {
    final dt = 1.0 / emgFs;
    final rc = 1.0 / (2.0 * math.pi * hpCutoffHz);
    _hpAlpha = rc / (rc + dt);
    _rmsN = math.max(8, (emgFs * rmsWindowMs / 1000.0).round());
    _hpHist = List.generate(8, (_) => Queue<double>());
  }

  late final double _hpAlpha;
  late final int _rmsN;
  late final List<Queue<double>> _hpHist;

  final List<double> _prevX = List.filled(8, 0.0);
  final List<double> _prevY = List.filled(8, 0.0);
  final List<double> currentHp = List.filled(8, 0.0);
  final List<double> currentRms = List.filled(8, 0.0);
  bool _initialized = false;

  List<double>? restChRms;
  double? restScoreMean;
  double? restScoreSd;
  double? contractScoreMean;
  double? contractScoreSd;
  double? clickThreshold;
  double? releaseThreshold;
  double sensitivity = 1.0;

  void resetFilter() {
    for (var i = 0; i < 8; i++) {
      _prevX[i] = 0.0;
      _prevY[i] = 0.0;
      currentHp[i] = 0.0;
      currentRms[i] = 0.0;
      _hpHist[i].clear();
    }
    _initialized = false;
  }

  void update(List<double> emg) {
    if (emg.length != 8) return;

    if (!_initialized) {
      for (var i = 0; i < 8; i++) {
        _prevX[i] = emg[i];
        _prevY[i] = 0.0;
      }
      _initialized = true;
    }

    for (var i = 0; i < 8; i++) {
      final y = _hpAlpha * (_prevY[i] + emg[i] - _prevX[i]);
      _prevX[i] = emg[i];
      _prevY[i] = y;
      currentHp[i] = y;

      final q = _hpHist[i];
      q.addLast(y);
      while (q.length > _rmsN) {
        q.removeFirst();
      }

      if (q.isEmpty) {
        currentRms[i] = 0.0;
      } else {
        var sumSq = 0.0;
        for (final v in q) {
          sumSq += v * v;
        }
        currentRms[i] = math.sqrt(sumSq / q.length);
      }
    }
  }

  double rawRmsActivation() {
    var sum = 0.0;
    for (final v in currentRms) {
      sum += v * v;
    }
    return math.sqrt(sum / currentRms.length);
  }

  double activationScore() {
    final rest = restChRms;
    if (rest == null) return rawRmsActivation();

    final med = median(rest);
    final floor = math.max(med * 0.25, 1.0);
    final ratios = <double>[];
    for (var i = 0; i < 8; i++) {
      ratios.add(currentRms[i] / math.max(rest[i], floor));
    }
    ratios.sort();
    final top = ratios.sublist(math.max(0, ratios.length - 4));
    return top.reduce((a, b) => a + b) / top.length;
  }

  void setRestCalibration(List<List<double>> rmsSamples) {
    var samples = rmsSamples
        .where((row) => row.length == 8 && row.every((v) => v.isFinite))
        .map((row) => List<double>.from(row))
        .toList();

    if (samples.length > emgFs.round()) {
      final skip = (0.5 * emgFs).round();
      samples = samples.sublist(math.min(skip, samples.length));
    }
    if (samples.length < 20) {
      throw Exception('Too few valid REST samples.');
    }

    final ch = List<double>.filled(8, 0.0);
    for (var i = 0; i < 8; i++) {
      ch[i] = median(samples.map((row) => row[i]).toList());
    }

    final globalFloor = math.max(median(ch) * 0.10, 1.0);
    for (var i = 0; i < 8; i++) {
      ch[i] = math.max(ch[i], globalFloor);
    }
    restChRms = ch;

    final denomFloor = math.max(median(ch) * 0.25, 1.0);
    final scores = <double>[];
    for (final sample in samples) {
      final ratios = <double>[];
      for (var i = 0; i < 8; i++) {
        ratios.add(sample[i] / math.max(ch[i], denomFloor));
      }
      ratios.sort();
      final top = ratios.sublist(4);
      scores.add(top.reduce((a, b) => a + b) / 4.0);
    }

    List<double> clean = scores;
    if (scores.length >= 50) {
      final hi = percentile(scores, 98.0);
      clean = scores.where((v) => v <= hi).toList();
    }

    restScoreMean = mean(clean);
    restScoreSd = stdDev(clean);
    contractScoreMean = null;
    contractScoreSd = null;
    clickThreshold = null;
    releaseThreshold = null;
  }

  void setContractCalibration(List<double> scoreSamples) {
    var arr = scoreSamples.where((v) => v.isFinite).toList();
    if (arr.length < 20) {
      throw Exception('Too few valid CONTRACT samples.');
    }

    if (arr.length > emgFs.round()) {
      final skip = (0.5 * emgFs).round();
      arr = arr.sublist(math.min(skip, arr.length));
    }

    final lower = percentile(arr, 40.0);
    var active = arr.where((v) => v >= lower).toList();
    if (active.length < 10) active = arr;

    contractScoreMean = mean(active);
    contractScoreSd = stdDev(active);
    _calculateThresholds();
  }

  void setSensitivity(double value) {
    sensitivity = value;
    _calculateThresholds();
  }

  void _calculateThresholds() {
    final rest = restScoreMean;
    if (rest == null) return;
    final restSd = math.max(restScoreSd ?? 0.0, 0.0);

    double click;
    double release;
    final contract = contractScoreMean;

    if (contract == null) {
      click = math.max(rest + 4.0 * restSd, rest * 1.7);
      release = math.max(rest + 2.0 * restSd, rest * 1.25);
    } else {
      final separation = contract - rest;
      if (separation > 0) {
        click = math.max(rest + 0.35 * separation, rest + 3.0 * restSd);
        release = math.max(rest + 0.15 * separation, rest + 1.5 * restSd);
      } else {
        click = math.max(rest + 4.0 * restSd, rest * 1.5);
        release = math.max(rest + 2.0 * restSd, rest * 1.20);
      }
    }

    var adjustedClick = rest + (click - rest) * sensitivity;
    var adjustedRelease = rest + (release - rest) * sensitivity;
    if (adjustedRelease >= adjustedClick) {
      adjustedRelease = rest + 0.60 * (adjustedClick - rest);
    }

    clickThreshold = adjustedClick;
    releaseThreshold = adjustedRelease;
  }

  double? separationRatio() {
    final rest = restScoreMean;
    final contract = contractScoreMean;
    if (rest == null || contract == null || rest <= 0) return null;
    return contract / rest;
  }
}

class ClickStateMachine {
  bool armed = true;
  DateTime? _aboveSince;
  DateTime? _belowSince;
  DateTime _lastClick = DateTime.fromMillisecondsSinceEpoch(0);

  bool update(double score, double? clickThreshold, double? releaseThreshold) {
    if (clickThreshold == null || releaseThreshold == null) return false;

    final now = DateTime.now();
    const clickConfirm = Duration(milliseconds: 80);
    const releaseConfirm = Duration(milliseconds: 150);
    const cooldown = Duration(milliseconds: 250);

    if (armed) {
      _belowSince = null;
      if (score >= clickThreshold) {
        _aboveSince ??= now;
        if (now.difference(_aboveSince!) >= clickConfirm &&
            now.difference(_lastClick) >= cooldown) {
          armed = false;
          _aboveSince = null;
          _lastClick = now;
          return true;
        }
      } else {
        _aboveSince = null;
      }
      return false;
    }

    _aboveSince = null;
    if (score <= releaseThreshold) {
      _belowSince ??= now;
      if (now.difference(_belowSince!) >= releaseConfirm) {
        armed = true;
        _belowSince = null;
      }
    } else {
      _belowSince = null;
    }
    return false;
  }

  void reset() {
    armed = true;
    _aboveSince = null;
    _belowSince = null;
  }
}

class ControlEngine {
  List<double> gyroBias = <double>[0, 0, 0];
  List<double>? rightVector;
  List<double>? downVector;
  List<double>? spinAxis;

  bool get vectorCalibrated => rightVector != null && downVector != null;
  bool get spinCalibrated => spinAxis != null;

  double cursorDeadzone = 0.045;
  double cursorGain = 42.0;
  double cursorMaxStep = 48.0;
  double smoothingAlpha = 0.75;
  double crossAxisSuppression = 0.45;
  double responseGamma = 1.10;

  final List<double> _filteredGyro = <double>[0, 0, 0];

  void setGyroBias(List<double> bias) {
    gyroBias = List<double>.from(bias);
    _filteredGyro.fillRange(0, 3, 0.0);
  }

  double applyVectorCalibration(
    List<double> bias,
    List<double> rightRaw,
    List<double> downRaw,
  ) {
    setGyroBias(bias);
    final r = unit(rightRaw);
    final dRaw = unit(downRaw);

    var dotRd = dot(r, dRaw).clamp(-1.0, 1.0).toDouble();
    final angle = math.acos(dotRd) * 180.0 / math.pi;

    final projection = scale(r, dot(dRaw, r));
    final dOrth = sub(dRaw, projection);
    final d = unit(dOrth);

    rightVector = r;
    downVector = d;
    spinAxis = null;
    return angle;
  }

  void applySpinCalibration(List<double> leftSpin, List<double> rightSpin) {
    if (!vectorCalibrated) {
      throw Exception('Cursor calibration must be completed first.');
    }

    final leftResidual = removeCursorPlane(leftSpin);
    final rightResidual = removeCursorPlane(rightSpin);
    final leftMag = norm(leftResidual);
    final rightMag = norm(rightResidual);

    if (leftMag < 0.05 || rightMag < 0.05) {
      throw Exception('Spin movement was too similar to cursor motion.');
    }

    final leftU = unit(leftResidual);
    final rightU = unit(rightResidual);
    final angle = math.acos(dot(leftU, rightU).clamp(-1.0, 1.0)) * 180 / math.pi;
    if (angle < 90) {
      throw Exception('LEFT and RIGHT spin are not opposite enough.');
    }

    var axis = unit(sub(leftU, rightU));
    if (dot(axis, leftResidual) < 0) axis = scale(axis, -1.0);
    spinAxis = axis;
  }

  List<double> removeCursorPlane(List<double> v) {
    final r = rightVector!;
    final d = downVector!;
    return sub(sub(v, scale(r, dot(v, r))), scale(d, dot(v, d)));
  }

  List<double> cursorComponents(List<double> gyro) {
    final corrected = sub(gyro, gyroBias);
    for (var i = 0; i < 3; i++) {
      _filteredGyro[i] = smoothingAlpha * corrected[i] +
          (1.0 - smoothingAlpha) * _filteredGyro[i];
    }

    double x;
    double y;
    if (vectorCalibrated) {
      x = dot(_filteredGyro, rightVector!);
      y = dot(_filteredGyro, downVector!);
    } else {
      x = _filteredGyro[1];
      y = _filteredGyro[0];
    }

    final ax = x.abs();
    final ay = y.abs();
    final c = crossAxisSuppression.clamp(0.0, 0.95);
    if (ax > 0 || ay > 0) {
      if (ax < c * ay) {
        x = 0;
      } else if (ay < c * ax) {
        y = 0;
      }
    }

    return <double>[x, y];
  }

  List<double> cursorDelta(List<double> gyro) {
    final c = cursorComponents(gyro);
    return <double>[
      componentToPixels(c[0]),
      componentToPixels(c[1]),
    ];
  }

  double componentToPixels(double value) {
    final av = value.abs();
    if (av <= cursorDeadzone) return 0.0;
    final magnitude = av - cursorDeadzone;
    var pixels = cursorGain * math.pow(magnitude, responseGamma).toDouble();
    pixels = math.min(cursorMaxStep, pixels);
    pixels = math.max(1.0, pixels);
    return value > 0 ? pixels : -pixels;
  }

  /// Signed spin intensity. Positive follows the calibrated SPIN LEFT
  /// direction and negative follows SPIN RIGHT. Cursor-plane motion is removed
  /// first so normal pointing does not accidentally scroll.
  double spinComponent(List<double> gyro) {
    if (!spinCalibrated || !vectorCalibrated) return 0.0;
    final corrected = sub(gyro, gyroBias);
    final residual = removeCursorPlane(corrected);
    final value = dot(residual, spinAxis!);
    const deadzone = 0.08;
    if (value.abs() <= deadzone) return 0.0;
    return value > 0 ? value - deadzone : value + deadzone;
  }

  /// Continuous scroll intent. Mouse Mode accumulates this value into discrete
  /// Windows wheel steps for smooth, noise-resistant scrolling.
  double scrollDelta(List<double> gyro) {
    final value = spinComponent(gyro);
    if (value == 0.0) return 0.0;
    return (value * 0.85).clamp(-2.5, 2.5).toDouble();
  }

  List<double> extractMotionVector(List<List<double>> samples) {
    if (samples.length < 5) {
      throw Exception('Too few gyro samples for calibration.');
    }

    final corrected = samples.map((v) => sub(v, gyroBias)).toList();
    final norms = corrected.map(norm).toList();
    var peakIdx = 0;
    for (var i = 1; i < norms.length; i++) {
      if (norms[i] > norms[peakIdx]) peakIdx = i;
    }

    final peakNorm = norms[peakIdx];
    if (peakNorm < 0.08) {
      throw Exception('Movement was too small.');
    }

    final peakUnit = scale(corrected[peakIdx], 1.0 / peakNorm);
    final selected = <List<double>>[];
    final weights = <double>[];

    for (var i = 0; i < corrected.length; i++) {
      final directionDot = dot(corrected[i], peakUnit);
      if (norms[i] >= 0.30 * peakNorm && directionDot > 0) {
        selected.add(corrected[i]);
        weights.add(math.max(norms[i], 1e-6));
      }
    }

    if (selected.isEmpty) return corrected[peakIdx];

    final out = <double>[0, 0, 0];
    var wsum = 0.0;
    for (var i = 0; i < selected.length; i++) {
      wsum += weights[i];
      for (var j = 0; j < 3; j++) {
        out[j] += selected[i][j] * weights[i];
      }
    }
    for (var j = 0; j < 3; j++) {
      out[j] /= wsum;
    }
    if (norm(out) < 0.05) throw Exception('Unstable movement direction.');
    return out;
  }
}

double mean(List<double> values) {
  if (values.isEmpty) return 0.0;
  return values.reduce((a, b) => a + b) / values.length;
}

double median(List<double> values) {
  if (values.isEmpty) return 0.0;
  final v = List<double>.from(values)..sort();
  final m = v.length ~/ 2;
  if (v.length.isOdd) return v[m];
  return (v[m - 1] + v[m]) / 2.0;
}

double stdDev(List<double> values) {
  if (values.length <= 1) return 0.0;
  final m = mean(values);
  var sum = 0.0;
  for (final v in values) {
    final d = v - m;
    sum += d * d;
  }
  return math.sqrt(sum / (values.length - 1));
}

double percentile(List<double> values, double p) {
  if (values.isEmpty) return 0.0;
  final v = List<double>.from(values)..sort();
  final rank = (p / 100.0) * (v.length - 1);
  final low = rank.floor();
  final high = rank.ceil();
  if (low == high) return v[low];
  final t = rank - low;
  return v[low] * (1.0 - t) + v[high] * t;
}

List<double> sub(List<double> a, List<double> b) =>
    List.generate(a.length, (i) => a[i] - b[i]);

List<double> scale(List<double> a, double s) =>
    a.map((v) => v * s).toList();

double dot(List<double> a, List<double> b) {
  var out = 0.0;
  for (var i = 0; i < a.length; i++) {
    out += a[i] * b[i];
  }
  return out;
}

double norm(List<double> a) => math.sqrt(dot(a, a));

List<double> unit(List<double> a) {
  final n = norm(a);
  if (n < 1e-9) throw Exception('Calibration movement was too small.');
  return scale(a, 1.0 / n);
}
