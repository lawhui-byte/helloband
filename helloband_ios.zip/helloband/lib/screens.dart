import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'helloband_controller.dart';
import 'game_audio.dart';
import 'windows_mouse.dart';

class ConnectionScreen extends StatefulWidget {
  const ConnectionScreen({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  State<ConnectionScreen> createState() => _ConnectionScreenState();
}

class _ConnectionScreenState extends State<ConnectionScreen> {
  String? selectedPort;
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final ports = widget.controller.ports;
    if (selectedPort != null && !ports.contains(selectedPort)) {
      selectedPort = null;
    }
    selectedPort ??= ports.isNotEmpty ? ports.first : null;

    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(36),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'HelloBand',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 42,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Waveletech-powered assistive interaction',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFF667085), fontSize: 17),
                    ),
                    const SizedBox(height: 36),
                    const Text(
                      '1. Plug in the Waveletech USB Bluetooth receiver.\n'
                      '2. Power on the wristband and wait for a stable connection.\n'
                      '3. Select the COM port below.',
                      style: TextStyle(height: 1.6),
                    ),
                    const SizedBox(height: 24),
                    DropdownButtonFormField<String>(
                      initialValue: selectedPort,
                      items: ports
                          .map(
                            (p) => DropdownMenuItem<String>(
                              value: p,
                              child: Text(p),
                            ),
                          )
                          .toList(),
                      onChanged: busy
                          ? null
                          : (value) => setState(() => selectedPort = value),
                      decoration: const InputDecoration(
                        labelText: 'Waveletech COM port',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 18),
                    FilledButton.icon(
                      onPressed: busy || selectedPort == null
                          ? null
                          : () async {
                              final messenger = ScaffoldMessenger.of(context);
                              setState(() => busy = true);
                              try {
                                await widget.controller.connect(selectedPort!);
                              } catch (e) {
                                if (!mounted) return;
                                messenger.showSnackBar(
                                  SnackBar(content: Text('Connection failed: $e')),
                                );
                              } finally {
                                if (mounted) {
                                  setState(() => busy = false);
                                }
                              }
                            },
                      icon: const Icon(Icons.bluetooth_connected),
                      label: Text(busy ? 'Connecting...' : 'Connect wristband'),
                      style: FilledButton.styleFrom(
                        minimumSize: const Size.fromHeight(58),
                      ),
                    ),
                    if (ports.isEmpty) ...[
                      const SizedBox(height: 16),
                      const Text(
                        'No COM ports detected. Reconnect the receiver, then restart the app.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.orangeAccent),
                      ),
                    ],
                    if (widget.controller.lastError != null) ...[
                      const SizedBox(height: 16),
                      Text(
                        widget.controller.lastError!,
                        style: const TextStyle(color: Colors.redAccent),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CalibrationScreen extends StatelessWidget {
  const CalibrationScreen({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  Widget build(BuildContext context) {
    final started = controller.stage != CalibrationStage.notStarted;
    final preparing = controller.calibrationPhase == CalibrationPhase.prepare;
    final recording = controller.calibrationPhase == CalibrationPhase.recording;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'HelloBand Calibration',
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Guided calibration · 3-second preparation before every recording',
                          style: TextStyle(color: Color(0xFF667085)),
                        ),
                      ],
                    ),
                  ),
                  _StatusPill(
                    text:
                        '${controller.connectedPort ?? ''} · EMG ${controller.aaRate}/s · IMU ${controller.bbRate}/s',
                  ),
                ],
              ),
              const SizedBox(height: 18),
              _CalibrationTimeline(controller: controller),
              const SizedBox(height: 18),
              Expanded(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 3,
                      child: Card(
                        clipBehavior: Clip.antiAlias,
                        child: Padding(
                          padding: const EdgeInsets.all(28),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 14,
                                      vertical: 8,
                                    ),
                                    decoration: BoxDecoration(
                                      color: _phaseColor(controller.calibrationPhase)
                                          .withValues(alpha: 0.16),
                                      borderRadius: BorderRadius.circular(30),
                                      border: Border.all(
                                        color: _phaseColor(controller.calibrationPhase)
                                            .withValues(alpha: 0.7),
                                      ),
                                    ),
                                    child: Text(
                                      controller.calibrationPhaseTitle,
                                      style: TextStyle(
                                        color: _phaseColor(controller.calibrationPhase),
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: 1.1,
                                      ),
                                    ),
                                  ),
                                  const Spacer(),
                                  if (started && !controller.calibrationComplete)
                                    Text(
                                      'STEP ${controller.calibrationStepNumber} OF 7',
                                      style: const TextStyle(
                                        color: Color(0xFF98A2B3),
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                ],
                              ),
                              const Spacer(),
                              _CalibrationMotionDemo(
                                stage: controller.stage,
                                preparing: preparing,
                                recording: recording,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                controller.stageTitle,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 42,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 14),
                              if (preparing) ...[
                                const Text(
                                  'WAIT — DO NOT START YET',
                                  style: TextStyle(
                                    color: Color(0xFFFFC857),
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  '${controller.prepareSecondsRemaining}',
                                  style: const TextStyle(
                                    color: Color(0xFFFFC857),
                                    fontSize: 76,
                                    height: 0.95,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ] else if (recording) ...[
                                const Text(
                                  'GO NOW',
                                  style: TextStyle(
                                    color: Color(0xFF137A59),
                                    fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.4,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  '${controller.recordingSecondsRemaining.toStringAsFixed(1)} s',
                                  style: const TextStyle(
                                    color: Color(0xFF137A59),
                                    fontSize: 42,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ],
                              const SizedBox(height: 16),
                              ConstrainedBox(
                                constraints: const BoxConstraints(maxWidth: 720),
                                child: Text(
                                  controller.calibrationMessage,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(fontSize: 20, height: 1.4),
                                ),
                              ),
                              const SizedBox(height: 24),
                              LinearProgressIndicator(
                                value: recording ? controller.calibrationProgress : 0,
                                minHeight: 14,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                preparing
                                    ? 'Recording begins automatically after the 3-second countdown.'
                                    : recording
                                        ? 'The sensor is recording this movement now.'
                                        : controller.nextStageTitle,
                                textAlign: TextAlign.center,
                                style: const TextStyle(color: Color(0xFF667085)),
                              ),
                              const Spacer(),
                              if (!started)
                                FilledButton.icon(
                                  onPressed: controller.beginCalibration,
                                  icon: const Icon(Icons.play_arrow_rounded),
                                  label: const Text('Start guided calibration'),
                                  style: FilledButton.styleFrom(
                                    minimumSize: const Size(340, 58),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      flex: 2,
                      child: Column(
                        children: [
                          Expanded(
                            child: Card(
                              child: Padding(
                                padding: const EdgeInsets.all(20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.stretch,
                                  children: [
                                    const Text(
                                      '8-channel EMG',
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Expanded(
                                      child: ListView.separated(
                                        padding: EdgeInsets.zero,
                                        physics: const ClampingScrollPhysics(),
                                        itemCount: 8,
                                        separatorBuilder: (_, __) =>
                                            const SizedBox(height: 7),
                                        itemBuilder: (context, i) {
                                          return Row(
                                            children: [
                                              SizedBox(
                                                width: 44,
                                                child: Text('CH${i + 1}'),
                                              ),
                                              Expanded(
                                                child: LinearProgressIndicator(
                                                  value: _rmsBar(
                                                    controller.latestRms[i],
                                                  ),
                                                  minHeight: 9,
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              SizedBox(
                                                width: 62,
                                                child: Text(
                                                  controller.latestRms[i]
                                                      .toStringAsFixed(1),
                                                  textAlign: TextAlign.right,
                                                ),
                                              ),
                                            ],
                                          );
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 16),
                          Card(
                            child: Padding(
                              padding: const EdgeInsets.all(18),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Muscle activation',
                                    style: TextStyle(
                                      fontSize: 17,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    '${controller.contractionPercent.toStringAsFixed(0)}%',
                                    style: const TextStyle(
                                      fontSize: 40,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                  Text(
                                    'Score ${controller.activationScore.toStringAsFixed(3)}',
                                    style: const TextStyle(color: Color(0xFF667085)),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    controller.nextStageTitle,
                                    style: const TextStyle(
                                      color: Color(0xFFA695FF),
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Color _phaseColor(CalibrationPhase phase) {
    switch (phase) {
      case CalibrationPhase.prepare:
        return const Color(0xFFFFC857);
      case CalibrationPhase.recording:
        return const Color(0xFF5BE7A9);
      case CalibrationPhase.finished:
        return const Color(0xFF8F80FF);
      case CalibrationPhase.idle:
        return const Color(0xFF8F80FF);
    }
  }


  static double _rmsBar(double rms) {
    return (math.log(rms.abs() + 1) / math.log(10000)).clamp(0.0, 1.0);
  }
}


class _CalibrationMotionDemo extends StatefulWidget {
  const _CalibrationMotionDemo({
    required this.stage,
    required this.preparing,
    required this.recording,
  });

  final CalibrationStage stage;
  final bool preparing;
  final bool recording;

  @override
  State<_CalibrationMotionDemo> createState() => _CalibrationMotionDemoState();
}

class _CalibrationMotionDemoState extends State<_CalibrationMotionDemo>
    with SingleTickerProviderStateMixin {
  late final AnimationController controller;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.preparing
        ? const Color(0xFFFFB547)
        : widget.recording
            ? const Color(0xFF35B985)
            : const Color(0xFF7A5AF8);

    return SizedBox(
      width: 250,
      height: 130,
      child: AnimatedBuilder(
        animation: controller,
        builder: (context, child) {
          final t = Curves.easeInOut.transform(controller.value);
          Widget motion;
          String hint;

          switch (widget.stage) {
            case CalibrationStage.right:
              motion = Transform.translate(
                offset: Offset(-48 + 96 * t, 0),
                child: child,
              );
              hint = 'Move toward RIGHT, then return to centre';
              break;
            case CalibrationStage.down:
              motion = Transform.translate(
                offset: Offset(0, -34 + 68 * t),
                child: child,
              );
              hint = 'Move DOWN, then return to centre';
              break;
            case CalibrationStage.spinLeft:
              motion = Transform.rotate(
                angle: -0.48 * t,
                child: child,
              );
              hint = 'Rotate forearm LEFT';
              break;
            case CalibrationStage.spinRight:
              motion = Transform.rotate(
                angle: 0.48 * t,
                child: child,
              );
              hint = 'Rotate forearm RIGHT';
              break;
            case CalibrationStage.contract:
              motion = Transform.scale(
                scale: 0.92 + 0.18 * t,
                child: child,
              );
              hint = 'Comfortable muscle contraction';
              break;
            case CalibrationStage.rest:
              motion = Transform.translate(
                offset: Offset(0, 3 * math.sin(t * math.pi)),
                child: child,
              );
              hint = 'Relax and keep the arm still';
              break;
            case CalibrationStage.neutral:
              motion = Transform.scale(
                scale: 0.96 + 0.06 * t,
                child: child,
              );
              hint = 'Hold a comfortable centre position';
              break;
            case CalibrationStage.complete:
              motion = child!;
              hint = 'Ready to use HelloBand';
              break;
            case CalibrationStage.notStarted:
              motion = child!;
              hint = 'Follow the animated movement guide';
              break;
          }

          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(child: Center(child: motion)),
              Text(
                hint,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFF667085),
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          );
        },
        child: Container(
          width: 84,
          height: 84,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.11),
            shape: BoxShape.circle,
            border: Border.all(color: color.withValues(alpha: 0.35), width: 2),
          ),
          child: Icon(
            _iconForStage(widget.stage),
            size: 46,
            color: color,
          ),
        ),
      ),
    );
  }

  static IconData _iconForStage(CalibrationStage stage) {
    switch (stage) {
      case CalibrationStage.rest:
        return Icons.front_hand_rounded;
      case CalibrationStage.contract:
        return Icons.bolt_rounded;
      case CalibrationStage.neutral:
        return Icons.center_focus_strong_rounded;
      case CalibrationStage.right:
        return Icons.pan_tool_alt_rounded;
      case CalibrationStage.down:
        return Icons.pan_tool_alt_rounded;
      case CalibrationStage.spinLeft:
        return Icons.rotate_left_rounded;
      case CalibrationStage.spinRight:
        return Icons.rotate_right_rounded;
      case CalibrationStage.complete:
        return Icons.check_circle_rounded;
      case CalibrationStage.notStarted:
        return Icons.waving_hand_rounded;
    }
  }
}

class _CalibrationTimeline extends StatelessWidget {
  const _CalibrationTimeline({required this.controller});

  final HelloBandController controller;

  static const labels = <String>[
    'REST',
    'CONTRACT',
    'NEUTRAL',
    'RIGHT',
    'DOWN',
    'SPIN L',
    'SPIN R',
  ];

  @override
  Widget build(BuildContext context) {
    final current = controller.calibrationStepNumber;
    return Row(
      children: List.generate(labels.length, (i) {
        final step = i + 1;
        final done = current > step || controller.calibrationComplete;
        final active = current == step && !controller.calibrationComplete;
        return Expanded(
          child: Container(
            margin: EdgeInsets.only(right: i == labels.length - 1 ? 0 : 7),
            padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 6),
            decoration: BoxDecoration(
              color: done
                  ? const Color(0xFFE9F8F2)
                  : active
                      ? const Color(0xFFF2ECFF)
                      : Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: done
                    ? const Color(0xFF35B985)
                    : active
                        ? const Color(0xFF7A5AF8)
                        : const Color(0xFFE4E7EC),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (done) ...[
                  const Icon(Icons.check, size: 15, color: Color(0xFF5BE7A9)),
                  const SizedBox(width: 4),
                ],
                Flexible(
                  child: Text(
                    labels[i],
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: active ? const Color(0xFF7A5AF8) : const Color(0xFF667085),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class CursorHomeScreen extends StatefulWidget {
  const CursorHomeScreen({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  State<CursorHomeScreen> createState() => _CursorHomeScreenState();
}

class _CursorHomeScreenState extends State<CursorHomeScreen> {
  Timer? timer;
  Offset cursor = const Offset(520, 390);
  int lastClickSerial = 0;
  String? hover;
  Size canvasSize = Size.zero;

  @override
  void initState() {
    super.initState();
    lastClickSerial = widget.controller.clickSerial;
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void _tick() {
    if (!mounted || canvasSize == Size.zero) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;

    final delta = widget.controller.consumeCursorDelta();
    var next = Offset(cursor.dx + delta[0], cursor.dy + delta[1]);
    next = Offset(
      next.dx.clamp(12.0, canvasSize.width - 12.0),
      next.dy.clamp(12.0, canvasSize.height - 12.0),
    );

    final rects = _tileRects(canvasSize);
    String? newHover;
    for (final entry in rects.entries) {
      if (entry.value.contains(next)) {
        newHover = entry.key;
        break;
      }
    }

    final clickChanged = widget.controller.clickSerial != lastClickSerial;
    if (clickChanged) {
      lastClickSerial = widget.controller.clickSerial;
      _activate(newHover);
    }

    if (next != cursor || newHover != hover) {
      setState(() {
        cursor = next;
        hover = newHover;
      });
    }
  }

  Future<void> _activate(String? target) async {
    if (target == null) return;
    if (target == 'MOUSE') {
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => MouseModeScreen(controller: widget.controller),
        ),
      );
    } else if (target == 'DRAWING') {
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => DrawingModeScreen(controller: widget.controller),
        ),
      );
    } else if (target == 'GAME') {
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => GameHubScreen(controller: widget.controller),
        ),
      );
    } else if (target == 'KEYBOARD') {
      try {
        await Process.start('osk.exe', const <String>[]);
      } catch (_) {}
      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => MouseModeScreen(
            controller: widget.controller,
            keyboardOpened: true,
          ),
        ),
      );
    } else if (target == 'RECALIBRATE') {
      widget.controller.beginCalibration();
    }
  }

  Map<String, Rect> _tileRects(Size s) {
    const gap = 18.0;
    const side = 44.0;
    final top = math.max(155.0, s.height * 0.22);
    final availableW = math.max(520.0, s.width - side * 2);
    final tileW = math.min(360.0, (availableW - gap) / 2);
    final tileH = math.min(178.0, math.max(135.0, (s.height - top - 130.0 - gap) / 2));
    final gridW = tileW * 2 + gap;
    final left = (s.width - gridW) / 2;

    return <String, Rect>{
      'MOUSE': Rect.fromLTWH(left, top, tileW, tileH),
      'DRAWING': Rect.fromLTWH(left + tileW + gap, top, tileW, tileH),
      'GAME': Rect.fromLTWH(left, top + tileH + gap, tileW, tileH),
      'KEYBOARD': Rect.fromLTWH(left + tileW + gap, top + tileH + gap, tileW, tileH),
      'RECALIBRATE': Rect.fromLTWH(s.width - 225, 30, 185, 58),
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          canvasSize = Size(constraints.maxWidth, constraints.maxHeight);
          final rects = _tileRects(canvasSize);
          return Stack(
            children: [
              Positioned.fill(
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFFF8FBFF),
                        Color(0xFFF2F7FF),
                        Color(0xFFFFF8FC),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 48,
                top: 32,
                right: 250,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.waving_hand_rounded, color: Color(0xFFFFB547), size: 34),
                        SizedBox(width: 12),
                        Text(
                          'HelloBand',
                          style: TextStyle(
                            color: Color(0xFF101828),
                            fontSize: 36,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      'Choose an activity · move with your forearm · contract to select',
                      style: TextStyle(color: Color(0xFF667085), fontSize: 16),
                    ),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 10,
                      runSpacing: 8,
                      children: [
                        _LightStatusChip(
                          icon: Icons.bluetooth_connected_rounded,
                          label: widget.controller.connectedPort ?? 'Connected',
                          color: const Color(0xFF4C8DFF),
                        ),
                        _LightStatusChip(
                          icon: Icons.bolt_rounded,
                          label: 'EMG ${widget.controller.contractionPercent.toStringAsFixed(0)}%',
                          color: const Color(0xFFFF6B9A),
                        ),
                        const _LightStatusChip(
                          icon: Icons.check_circle_rounded,
                          label: 'Calibrated',
                          color: Color(0xFF35B985),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Positioned.fromRect(
                rect: rects['MOUSE']!,
                child: _DashboardModeCard(
                  title: 'Mouse Control',
                  subtitle: 'Control Windows & apps',
                  detail: 'Move = cursor · Contract = click · Spin = scroll',
                  icon: Icons.mouse_rounded,
                  accent: const Color(0xFF4C8DFF),
                  soft: const Color(0xFFEAF2FF),
                  active: hover == 'MOUSE',
                  onTap: () => _activate('MOUSE'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['DRAWING']!,
                child: _DashboardModeCard(
                  title: 'Drawing',
                  subtitle: 'Paint with muscle strength',
                  detail: 'Small squeeze = thin · strong squeeze = thick',
                  icon: Icons.brush_rounded,
                  accent: const Color(0xFFFF6B9A),
                  soft: const Color(0xFFFFEDF4),
                  active: hover == 'DRAWING',
                  onTap: () => _activate('DRAWING'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['GAME']!,
                child: _DashboardModeCard(
                  title: 'Games',
                  subtitle: 'Play & train',
                  detail: 'Racing · Fruit · Word Balloons · Color Match',
                  icon: Icons.sports_esports_rounded,
                  accent: const Color(0xFF8F67E8),
                  soft: const Color(0xFFF2ECFF),
                  active: hover == 'GAME',
                  onTap: () => _activate('GAME'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['KEYBOARD']!,
                child: _DashboardModeCard(
                  title: 'Keyboard',
                  subtitle: 'Open Windows On-Screen Keyboard',
                  detail: 'Use Mouse Control to point and type',
                  icon: Icons.keyboard_alt_rounded,
                  accent: const Color(0xFF35B985),
                  soft: const Color(0xFFE8F8F1),
                  active: hover == 'KEYBOARD',
                  onTap: () => _activate('KEYBOARD'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['RECALIBRATE']!,
                child: FilledButton.tonalIcon(
                  onPressed: () => _activate('RECALIBRATE'),
                  icon: const Icon(Icons.tune_rounded),
                  label: const Text('Recalibrate'),
                ),
              ),
              Positioned(
                left: cursor.dx - 13,
                top: cursor.dy - 13,
                child: IgnorePointer(
                  child: Container(
                    width: 26,
                    height: 26,
                    decoration: BoxDecoration(
                      color: widget.controller.contraction
                          ? const Color(0xFF35B985)
                          : const Color(0xFF4C8DFF),
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x444C8DFF),
                          blurRadius: 18,
                          spreadRadius: 4,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _DashboardModeCard extends StatelessWidget {
  const _DashboardModeCard({
    required this.title,
    required this.subtitle,
    required this.detail,
    required this.icon,
    required this.accent,
    required this.soft,
    required this.active,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final String detail;
  final IconData icon;
  final Color accent;
  final Color soft;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 130),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: active ? soft : Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: active ? accent : const Color(0xFFE4E7EC),
            width: active ? 3 : 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: active ? accent.withValues(alpha: 0.18) : const Color(0x12000000),
              blurRadius: active ? 26 : 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(color: soft, shape: BoxShape.circle),
              child: Icon(icon, size: 38, color: accent),
            ),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Color(0xFF101828),
                      fontSize: 23,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: TextStyle(color: accent, fontSize: 14, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    detail,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Color(0xFF667085), fontSize: 12.5, height: 1.25),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LightStatusChip extends StatelessWidget {
  const _LightStatusChip({required this.icon, required this.label, required this.color});
  final IconData icon;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.09),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: color.withValues(alpha: 0.28)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
        ],
      ),
    );
  }
}

class MouseModeScreen extends StatefulWidget {
  const MouseModeScreen({
    super.key,
    required this.controller,
    this.keyboardOpened = false,
  });

  final HelloBandController controller;
  final bool keyboardOpened;

  @override
  State<MouseModeScreen> createState() => _MouseModeScreenState();
}

class _MouseModeScreenState extends State<MouseModeScreen> {
  Timer? timer;
  int lastClickSerial = 0;
  double scrollAccumulator = 0.0;
  int clicks = 0;
  int scrollSteps = 0;

  @override
  void initState() {
    super.initState();
    lastClickSerial = widget.controller.clickSerial;
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void _tick() {
    if (!mounted || ModalRoute.of(context)?.isCurrent != true) return;

    final delta = widget.controller.consumeCursorDelta();
    WindowsMouse.moveBy(delta[0], delta[1]);

    scrollAccumulator += widget.controller.consumeScrollDelta();
    if (scrollAccumulator.abs() >= 1.0) {
      final steps = scrollAccumulator.truncate();
      scrollAccumulator -= steps;
      WindowsMouse.scroll(steps);
      scrollSteps += steps.abs();
    }

    if (widget.controller.clickSerial != lastClickSerial) {
      lastClickSerial = widget.controller.clickSerial;
      WindowsMouse.leftClick();
      clicks++;
    }

    if (mounted) setState(() {});
  }

  Future<void> _openKeyboard() async {
    try {
      // Launch the Windows keyboard after this Flutter screen is ready so the
      // OSK gets the foreground window instead of being immediately covered
      // again by HelloBand.
      await Future<void>.delayed(const Duration(milliseconds: 250));
      if (!mounted) return;
      await Process.start('osk.exe', const <String>[]);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open Windows On-Screen Keyboard: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7FAFF),
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        title: const Text('HelloBand Mouse Control'),
        leading: IconButton(
          tooltip: 'Back to dashboard',
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
        ),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 980),
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(28),
              child: Column(
                children: [
                  Container(
                    width: 108,
                    height: 108,
                    decoration: const BoxDecoration(
                      color: Color(0xFFEAF2FF),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.mouse_rounded, size: 58, color: Color(0xFF4C8DFF)),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Windows Mouse Mode is Active',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFF101828), fontSize: 32, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'You can leave HelloBand in the background and control other Windows apps.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFF667085), fontSize: 16),
                  ),
                  const SizedBox(height: 28),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 16,
                    runSpacing: 16,
                    children: const [
                      _MouseInstructionCard(
                        icon: Icons.open_with_rounded,
                        title: 'Move forearm',
                        text: 'Move Windows cursor',
                        color: Color(0xFF4C8DFF),
                      ),
                      _MouseInstructionCard(
                        icon: Icons.ads_click_rounded,
                        title: 'Contract muscle',
                        text: 'Left click',
                        color: Color(0xFFFF6B9A),
                      ),
                      _MouseInstructionCard(
                        icon: Icons.rotate_left_rounded,
                        title: 'Spin left',
                        text: 'Scroll up',
                        color: Color(0xFF35B985),
                      ),
                      _MouseInstructionCard(
                        icon: Icons.rotate_right_rounded,
                        title: 'Spin right',
                        text: 'Scroll down',
                        color: Color(0xFF8F67E8),
                      ),
                    ],
                  ),
                  const SizedBox(height: 26),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(22),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Live control', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                                const SizedBox(height: 8),
                                Text(
                                  'Muscle ${widget.controller.contractionPercent.toStringAsFixed(0)}%  ·  Clicks $clicks  ·  Scroll actions $scrollSteps',
                                  style: const TextStyle(color: Color(0xFF667085)),
                                ),
                              ],
                            ),
                          ),
                          FilledButton.icon(
                            onPressed: _openKeyboard,
                            icon: const Icon(Icons.keyboard_alt_rounded),
                            label: Text(widget.keyboardOpened ? 'Open Keyboard Again' : 'Open On-Screen Keyboard'),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).popUntil((route) => route.isFirst),
                    icon: const Icon(Icons.dashboard_rounded),
                    label: const Text('Back to Dashboard'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MouseInstructionCard extends StatelessWidget {
  const _MouseInstructionCard({
    required this.icon,
    required this.title,
    required this.text,
    required this.color,
  });

  final IconData icon;
  final String title;
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 205,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.30)),
      ),
      child: Column(
        children: [
          Icon(icon, size: 40, color: color),
          const SizedBox(height: 10),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF667085), fontSize: 13)),
        ],
      ),
    );
  }
}

enum _DrawingTool { pen, eraser }

class _StrokePoint {
  const _StrokePoint(this.position, this.width);
  final Offset position;
  final double width;
}

class DrawingModeScreen extends StatefulWidget {
  const DrawingModeScreen({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  State<DrawingModeScreen> createState() => _DrawingModeScreenState();
}

class _DrawingModeScreenState extends State<DrawingModeScreen> {
  Timer? timer;
  Offset cursor = const Offset(500, 350);
  final List<List<_StrokePoint>> strokes = <List<_StrokePoint>>[];
  List<_StrokePoint>? activeStroke;
  Size area = Size.zero;
  _DrawingTool tool = _DrawingTool.pen;
  int lastClickSerial = 0;
  String? hoverTool;

  static const double toolbarTop = 18;
  static const double canvasTop = 104;
  static const double eraserRadius = 30;

  double get currentPenWidth => 2.5 + widget.controller.contractionLevel * 17.5;

  String get currentPenLabel {
    final p = widget.controller.contractionPercent;
    if (p < 34) return 'THIN';
    if (p < 67) return 'MEDIUM';
    return 'THICK';
  }

  @override
  void initState() {
    super.initState();
    lastClickSerial = widget.controller.clickSerial;
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Map<String, Rect> _toolRects(Size s) {
    const buttonH = 54.0;
    var x = 22.0;
    final out = <String, Rect>{};
    for (final item in <MapEntry<String, double>>[
      const MapEntry('BACK', 112.0),
      const MapEntry('PEN', 104.0),
      const MapEntry('ERASER', 126.0),
      const MapEntry('CLEAR', 110.0),
    ]) {
      out[item.key] = Rect.fromLTWH(x, toolbarTop + 6, item.value, buttonH);
      x += item.value + 10;
    }
    return out;
  }

  String? _toolAt(Offset p) {
    for (final e in _toolRects(area).entries) {
      if (e.value.contains(p)) return e.key;
    }
    return null;
  }

  void _activateTool(String? target) {
    if (target == null) return;
    if (target == 'BACK') {
      GameAudio.back();
      Navigator.of(context).popUntil((route) => route.isFirst);
      return;
    }

    setState(() {
      if (target == 'PEN') {
        tool = _DrawingTool.pen;
        activeStroke = null;
      } else if (target == 'ERASER') {
        tool = _DrawingTool.eraser;
        activeStroke = null;
      } else if (target == 'CLEAR') {
        strokes.clear();
        activeStroke = null;
      }
    });
  }

  void _eraseAt(Offset point) {
    final replacement = <List<_StrokePoint>>[];
    for (final stroke in strokes) {
      var current = <_StrokePoint>[];
      for (final p in stroke) {
        if ((p.position - point).distance <= eraserRadius) {
          if (current.length >= 2) replacement.add(current);
          current = <_StrokePoint>[];
        } else {
          current.add(p);
        }
      }
      if (current.length >= 2) replacement.add(current);
    }
    strokes
      ..clear()
      ..addAll(replacement);
  }

  void _tick() {
    if (!mounted || area == Size.zero) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;

    final delta = widget.controller.consumeCursorDelta();
    final next = Offset(
      (cursor.dx + delta[0]).clamp(10.0, area.width - 10.0),
      (cursor.dy + delta[1]).clamp(10.0, area.height - 10.0),
    );

    final newHover = _toolAt(next);
    final clickChanged = widget.controller.clickSerial != lastClickSerial;
    if (clickChanged) {
      lastClickSerial = widget.controller.clickSerial;
      if (newHover != null) _activateTool(newHover);
    }

    final onCanvas = next.dy >= canvasTop;
    if (onCanvas && widget.controller.contraction) {
      if (tool == _DrawingTool.pen) {
        activeStroke ??= <_StrokePoint>[];
        activeStroke!.add(_StrokePoint(next, currentPenWidth));
        if (!strokes.contains(activeStroke)) strokes.add(activeStroke!);
      } else {
        activeStroke = null;
        _eraseAt(next);
      }
    } else {
      activeStroke = null;
    }

    if (mounted) {
      setState(() {
        cursor = next;
        hoverTool = newHover;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          area = Size(constraints.maxWidth, constraints.maxHeight);
          final rects = _toolRects(area);
          return Stack(
            children: [
              Positioned.fill(child: Container(color: const Color(0xFFF9FBFF))),
              Positioned(
                left: 0,
                right: 0,
                top: canvasTop,
                bottom: 0,
                child: CustomPaint(painter: _DrawingPainter(strokes)),
              ),
              Positioned(
                left: 0,
                right: 0,
                top: 0,
                height: 94,
                child: Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    border: Border(bottom: BorderSide(color: Color(0xFFE4E7EC))),
                  ),
                  child: Stack(
                    children: [
                      for (final entry in rects.entries)
                        Positioned.fromRect(
                          rect: entry.value,
                          child: _DrawingToolButton(
                            onPressed: () => _activateTool(entry.key),
                            label: entry.key == 'BACK'
                                ? 'Back'
                                : entry.key == 'PEN'
                                    ? 'Pen'
                                    : entry.key == 'ERASER'
                                        ? 'Eraser'
                                        : 'Clear',
                            icon: entry.key == 'BACK'
                                ? Icons.arrow_back_rounded
                                : entry.key == 'PEN'
                                    ? Icons.brush_rounded
                                    : entry.key == 'ERASER'
                                        ? Icons.auto_fix_normal_rounded
                                        : Icons.delete_outline_rounded,
                            selected: (entry.key == 'PEN' && tool == _DrawingTool.pen) ||
                                (entry.key == 'ERASER' && tool == _DrawingTool.eraser),
                            hovered: hoverTool == entry.key,
                          ),
                        ),
                      Positioned(
                        right: 24,
                        top: 14,
                        child: Row(
                          children: [
                            if (tool == _DrawingTool.pen) ...[
                              Container(
                                width: 50,
                                height: 50,
                                alignment: Alignment.center,
                                decoration: const BoxDecoration(
                                  color: Color(0xFFF2ECFF),
                                  shape: BoxShape.circle,
                                ),
                                child: Container(
                                  width: currentPenWidth.clamp(4.0, 24.0).toDouble(),
                                  height: currentPenWidth.clamp(4.0, 24.0).toDouble(),
                                  decoration: const BoxDecoration(
                                    color: Color(0xFF7A5AF8),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                            ],
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  tool == _DrawingTool.pen
                                      ? 'BRUSH $currentPenLabel · ${currentPenWidth.toStringAsFixed(1)} px'
                                      : 'ERASER · contract to erase',
                                  style: TextStyle(
                                    color: tool == _DrawingTool.pen
                                        ? const Color(0xFF7A5AF8)
                                        : const Color(0xFFD34B68),
                                    fontWeight: FontWeight.w900,
                                    fontSize: 15,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Muscle ${widget.controller.contractionPercent.toStringAsFixed(0)}%',
                                  style: const TextStyle(
                                    color: Color(0xFF667085),
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 22,
                bottom: 20,
                child: IgnorePointer(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.94),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: const Color(0xFFE4E7EC)),
                    ),
                    child: const Text(
                      'Pen width follows your contraction strength in real time',
                      style: TextStyle(color: Color(0xFF667085), fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: cursor.dx - (tool == _DrawingTool.eraser ? eraserRadius : currentPenWidth / 2 + 7),
                top: cursor.dy - (tool == _DrawingTool.eraser ? eraserRadius : currentPenWidth / 2 + 7),
                child: IgnorePointer(
                  child: Container(
                    width: tool == _DrawingTool.eraser ? eraserRadius * 2 : currentPenWidth + 14,
                    height: tool == _DrawingTool.eraser ? eraserRadius * 2 : currentPenWidth + 14,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: tool == _DrawingTool.eraser
                          ? const Color(0x22FF5470)
                          : const Color(0x227A5AF8),
                      border: Border.all(
                        color: tool == _DrawingTool.eraser
                            ? const Color(0xFFFF5470)
                            : const Color(0xFF7A5AF8),
                        width: 2,
                      ),
                    ),
                    child: tool == _DrawingTool.eraser
                        ? const Icon(Icons.auto_fix_normal_rounded, color: Color(0xFFFF5470), size: 22)
                        : null,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _DrawingToolButton extends StatelessWidget {
  const _DrawingToolButton({
    required this.label,
    required this.icon,
    required this.selected,
    required this.hovered,
    required this.onPressed,
  });

  final String label;
  final IconData icon;
  final bool selected;
  final bool hovered;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final active = selected || hovered;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onPressed,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 100),
        decoration: BoxDecoration(
          color: selected
              ? const Color(0xFF7A5AF8)
              : hovered
                  ? const Color(0xFFF2ECFF)
                  : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: active ? const Color(0xFF7A5AF8) : const Color(0xFFD0D5DD),
            width: hovered ? 3 : 1,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: selected ? Colors.white : const Color(0xFF344054)),
            const SizedBox(width: 7),
            Text(
              label,
              style: TextStyle(
                color: selected ? Colors.white : const Color(0xFF344054),
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrawingPainter extends CustomPainter {
  _DrawingPainter(this.strokes);

  final List<List<_StrokePoint>> strokes;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.translate(0, -_DrawingModeScreenState.canvasTop);

    final paint = Paint()
      ..color = const Color(0xFF7A5AF8)
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;

    for (final stroke in strokes) {
      if (stroke.length < 2) continue;
      for (var i = 1; i < stroke.length; i++) {
        final a = stroke[i - 1];
        final b = stroke[i];
        paint.strokeWidth = ((a.width + b.width) / 2.0).clamp(2.5, 20.0).toDouble();
        canvas.drawLine(a.position, b.position, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DrawingPainter oldDelegate) => true;
}

class GameHubScreen extends StatefulWidget {

  const GameHubScreen({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  State<GameHubScreen> createState() => _GameHubScreenState();
}

class _GameHubScreenState extends State<GameHubScreen> {
  Timer? timer;
  Offset cursor = const Offset(620, 430);
  int lastClickSerial = 0;
  String? hover;
  Size area = Size.zero;

  @override
  void initState() {
    super.initState();
    lastClickSerial = widget.controller.clickSerial;
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Map<String, Rect> _rects(Size s) {
    // Eight responsive game cards. Stack positioning + FittedBox cards avoids
    // RenderFlex overflows even when the Windows window is resized smaller.
    const side = 22.0;
    const gapX = 14.0;
    const gapY = 14.0;
    final top = math.min(152.0, math.max(118.0, s.height * 0.16));
    final columns = s.width >= 1480 ? 4 : (s.width >= 980 ? 3 : 2);
    final rows = (9 / columns).ceil();
    final availableW = math.max(360.0, s.width - side * 2);
    final availableH = math.max(300.0, s.height - top - 24.0);
    final cardW = math.min(318.0, (availableW - gapX * (columns - 1)) / columns);
    final cardH = math.min(210.0, (availableH - gapY * (rows - 1)) / rows);
    final gridW = cardW * columns + gapX * (columns - 1);
    final left = (s.width - gridW) / 2;

    Rect slot(int index) {
      final row = index ~/ columns;
      final col = index % columns;
      return Rect.fromLTWH(
        left + col * (cardW + gapX),
        top + row * (cardH + gapY),
        cardW,
        cardH,
      );
    }

    return <String, Rect>{
      'DRIVE': slot(0),
      'METRO': slot(1),
      'FRUIT': slot(2),
      'MAZE': slot(3),
      'DINO': slot(4),
      'BALLOON': slot(5),
      'WORD': slot(6),
      'COLOR': slot(7),
      'TARGET': slot(8),
      'BACK': const Rect.fromLTWH(18, 18, 205, 56),
    };
  }

  void _activate(String? target) {
    if (target == null) return;
    GameAudio.select();

    if (target == 'BACK') {
      GameAudio.back();
      Navigator.of(context).popUntil((route) => route.isFirst);
      return;
    }

    Widget? page;
    if (target == 'DRIVE') {
      page = GameModeScreen(controller: widget.controller);
    } else if (target == 'METRO') {
      page = MetroDashScreen(controller: widget.controller);
    } else if (target == 'FRUIT') {
      page = FruitSliceScreen(controller: widget.controller);
    } else if (target == 'MAZE') {
      page = MazeMunchScreen(controller: widget.controller);
    } else if (target == 'DINO') {
      page = DinoJumpScreen(controller: widget.controller);
    } else if (target == 'BALLOON') {
      page = BalloonPopScreen(controller: widget.controller);
    } else if (target == 'WORD') {
      page = WordBalloonScreen(controller: widget.controller);
    } else if (target == 'COLOR') {
      page = ColorMatchScreen(controller: widget.controller);
    } else if (target == 'TARGET') {
      page = TargetTapScreen(controller: widget.controller);
    }

    if (page != null) {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => page!));
    }
  }

  void _tick() {
    if (!mounted || area == Size.zero) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;

    final delta = widget.controller.consumeCursorDelta();
    final next = Offset(
      (cursor.dx + delta[0]).clamp(12.0, area.width - 12.0),
      (cursor.dy + delta[1]).clamp(12.0, area.height - 12.0),
    );

    String? newHover;
    for (final entry in _rects(area).entries) {
      if (entry.value.contains(next)) {
        newHover = entry.key;
        break;
      }
    }

    final clickChanged = widget.controller.clickSerial != lastClickSerial;
    if (clickChanged) {
      lastClickSerial = widget.controller.clickSerial;
      _activate(newHover);
    }

    if (next != cursor || newHover != hover) {
      setState(() {
        cursor = next;
        hover = newHover;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          area = Size(constraints.maxWidth, constraints.maxHeight);
          final rects = _rects(area);
          return Stack(
            children: [
              Positioned.fill(
                child: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFFF7FAFF),
                        Color(0xFFEAF2FF),
                        Color(0xFFFFFFFF),
                      ],
                    ),
                  ),
                ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(painter: _GameHubBackgroundPainter()),
                ),
              ),
              Positioned(
                left: 235,
                right: 20,
                top: 24,
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Column(
                    children: [
                      const Text(
                        'HelloBand Games',
                        style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Move the HelloBand cursor · contract to select',
                        style: TextStyle(color: Color(0xFF667085), fontSize: 16),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '9 interactive games · EMG ${widget.controller.contractionPercent.toStringAsFixed(0)}%',
                        style: const TextStyle(
                          color: Color(0xFF137A59),
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned.fromRect(
                rect: rects['DRIVE']!,
                child: _GameChoiceCard(
                  title: 'HelloDrive',
                  subtitle: 'Arcade obstacle racing',
                  instruction: 'LEFT / RIGHT steer · UP brake · CONTRACT accelerate',
                  icon: Icons.directions_car_filled_rounded,
                  accent: const Color(0xFFFFB547),
                  active: hover == 'DRIVE',
                  onTap: () => _activate('DRIVE'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['METRO']!,
                child: _GameChoiceCard(
                  title: 'Metro Dash',
                  subtitle: '3-lane urban runner',
                  instruction: 'LEFT / RIGHT lane · UP jump · DOWN slide · CONTRACT boost',
                  icon: Icons.directions_run_rounded,
                  accent: const Color(0xFF43E6C4),
                  active: hover == 'METRO',
                  onTap: () => _activate('METRO'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['FRUIT']!,
                child: _GameChoiceCard(
                  title: 'Fruit Slice',
                  subtitle: 'Motion-only slicing',
                  instruction: 'MOVE LEFT / RIGHT · automatic slicing · avoid bombs',
                  icon: Icons.restaurant_rounded,
                  accent: const Color(0xFFFF5D8F),
                  active: hover == 'FRUIT',
                  onTap: () => _activate('FRUIT'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['MAZE']!,
                child: _GameChoiceCard(
                  title: 'Maze Munch',
                  subtitle: 'Puzzle maze challenge',
                  instruction: 'MOVE through maze · collect keys · CONTRACT power pulse',
                  icon: Icons.grid_4x4_rounded,
                  accent: const Color(0xFFFFE45E),
                  active: hover == 'MAZE',
                  onTap: () => _activate('MAZE'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['DINO']!,
                child: _GameChoiceCard(
                  title: 'Dino Jump',
                  subtitle: 'Green dinosaur runner',
                  instruction: 'MOVE UP or CONTRACT to jump over obstacles',
                  icon: Icons.pets_rounded,
                  accent: const Color(0xFF75E66B),
                  active: hover == 'DINO',
                  onTap: () => _activate('DINO'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['BALLOON']!,
                child: _GameChoiceCard(
                  title: 'Balloon Pop',
                  subtitle: '2-D precision target game',
                  instruction: 'MOVE cursor freely · touch balloons to POP automatically',
                  icon: Icons.bubble_chart_rounded,
                  accent: const Color(0xFF57C7FF),
                  active: hover == 'BALLOON',
                  onTap: () => _activate('BALLOON'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['WORD']!,
                child: _GameChoiceCard(
                  title: 'Word Balloons',
                  subtitle: 'Spell simple words',
                  instruction: 'POP letters in the correct order to complete each word',
                  icon: Icons.abc_rounded,
                  accent: const Color(0xFFFF8ED8),
                  active: hover == 'WORD',
                  onTap: () => _activate('WORD'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['COLOR']!,
                child: _GameChoiceCard(
                  title: 'Color Match',
                  subtitle: 'Visual reaction challenge',
                  instruction: 'Touch only the bubble matching the target color',
                  icon: Icons.palette_rounded,
                  accent: const Color(0xFFA695FF),
                  active: hover == 'COLOR',
                  onTap: () => _activate('COLOR'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['TARGET']!,
                child: _GameChoiceCard(
                  title: 'Target Tap',
                  subtitle: 'Easy contraction practice',
                  instruction: 'Move to the target · CONTRACT once to collect it',
                  icon: Icons.ads_click_rounded,
                  accent: const Color(0xFF4C8DFF),
                  active: hover == 'TARGET',
                  onTap: () => _activate('TARGET'),
                ),
              ),
              Positioned.fromRect(
                rect: rects['BACK']!,
                child: FilledButton.icon(
                  onPressed: () => _activate('BACK'),
                  icon: const Icon(Icons.arrow_back_rounded),
                  label: const Text('Dashboard'),
                  style: FilledButton.styleFrom(
                    backgroundColor: const Color(0xFF1F6FEB),
                    foregroundColor: Colors.white,
                  ),
                ),
              ),
              Positioned(
                left: cursor.dx - 11,
                top: cursor.dy - 11,
                child: IgnorePointer(
                  child: Container(
                    width: 22,
                    height: 22,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: widget.controller.contraction
                          ? const Color(0xFFFFE45E)
                          : Colors.white,
                      border: Border.all(color: const Color(0xFF101828), width: 3),
                      boxShadow: const [
                        BoxShadow(color: Colors.black54, blurRadius: 10),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _GameHubBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final random = math.Random(12);
    final paint = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < 48; i++) {
      final x = random.nextDouble() * size.width;
      final y = random.nextDouble() * size.height;
      final r = 1.5 + random.nextDouble() * 4.0;
      final colors = <Color>[
        const Color(0xFF43E6C4),
        const Color(0xFFFF5D8F),
        const Color(0xFFFFE45E),
        const Color(0xFFA695FF),
      ];
      paint.color = colors[i % colors.length].withValues(alpha: 0.18);
      canvas.drawCircle(Offset(x, y), r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GameHubBackgroundPainter oldDelegate) => false;
}

class _GameChoiceCard extends StatelessWidget {
  const _GameChoiceCard({
    required this.title,
    required this.subtitle,
    required this.instruction,
    required this.icon,
    required this.accent,
    required this.active,
    this.onTap,
  });

  final String title;
  final String subtitle;
  final String instruction;
  final IconData icon;
  final Color accent;
  final bool active;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          color: active
              ? accent.withValues(alpha: 0.10)
              : Colors.white,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(
            color: active ? accent : const Color(0xFFD0D5DD),
            width: active ? 4 : 1.5,
          ),
          boxShadow: active
              ? <BoxShadow>[
                  BoxShadow(
                    color: accent.withValues(alpha: 0.35),
                    blurRadius: 34,
                    spreadRadius: 5,
                  ),
                ]
              : const <BoxShadow>[],
        ),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.center,
          child: SizedBox(
            width: 290,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 86,
                  height: 86,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.16),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, size: 52, color: accent),
                ),
                const SizedBox(height: 14),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xFF101828),
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  subtitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Color(0xFF667085),
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 11),
                Text(
                  instruction,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: accent,
                    fontWeight: FontWeight.w800,
                    height: 1.25,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GameTopControls extends StatefulWidget {
  const _GameTopControls({
    this.controller,
    this.cursor,
    required this.onBack,
    required this.onStop,
    this.stopped = false,
  });

  final HelloBandController? controller;
  final Offset? cursor;
  final VoidCallback onBack;
  final VoidCallback onStop;
  final bool stopped;

  @override
  State<_GameTopControls> createState() => _GameTopControlsState();
}

class _GameTopControlsState extends State<_GameTopControls> {
  Timer? virtualClickTimer;
  int lastClickSerial = 0;

  @override
  void initState() {
    super.initState();
    lastClickSerial = widget.controller?.clickSerial ?? 0;
    virtualClickTimer = Timer.periodic(const Duration(milliseconds: 16), (_) {
      if (mounted) _checkVirtualClick();
    });
  }

  @override
  void dispose() {
    virtualClickTimer?.cancel();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant _GameTopControls oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      lastClickSerial = widget.controller?.clickSerial ?? 0;
    }
  }

  void _checkVirtualClick() {
    final controller = widget.controller;
    final cursor = widget.cursor;
    if (controller == null || cursor == null) return;
    final serial = controller.clickSerial;
    if (serial == lastClickSerial) return;
    lastClickSerial = serial;

    // The buttons are fixed-size, so contraction can be used exactly like a
    // normal click when the virtual cursor is over them.
    final backRect = const Rect.fromLTWH(20, 12, 174, 56);
    final stopRect = const Rect.fromLTWH(204, 12, 164, 56);
    if (backRect.contains(cursor)) {
      GameAudio.stopGame();
      GameAudio.back();
      widget.onBack();
    } else if (stopRect.contains(cursor)) {
      widget.onStop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.only(left: 20, top: 12),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 174,
              height: 56,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF1F6FEB),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  textStyle: const TextStyle(fontWeight: FontWeight.w800),
                ),
                onPressed: () {
                  GameAudio.stopGame();
                  GameAudio.back();
                  widget.onBack();
                },
                icon: const Icon(Icons.arrow_back_rounded),
                label: const Text('Back to Games'),
              ),
            ),
            const SizedBox(width: 10),
            SizedBox(
              width: 164,
              height: 56,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: widget.stopped
                      ? const Color(0xFF137A59)
                      : const Color(0xFFD74444),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  textStyle: const TextStyle(fontWeight: FontWeight.w800),
                ),
                onPressed: widget.onStop,
                icon: Icon(widget.stopped ? Icons.play_arrow_rounded : Icons.stop_rounded),
                label: Text(widget.stopped ? 'Resume' : 'Stop Game'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GameStoppedOverlay extends StatelessWidget {
  const _GameStoppedOverlay({
    required this.title,
    required this.onResume,
    required this.onRestart,
    required this.onBack,
  });

  final String title;
  final VoidCallback onResume;
  final VoidCallback onRestart;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xC9081020),
      alignment: Alignment.center,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Card(
            color: const Color(0xFF14203A),
            elevation: 8,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: const BorderSide(color: Color(0xFFFF6B6B), width: 1.0),
            ),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 38, vertical: 30),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                const Icon(Icons.stop_circle_rounded, size: 74, color: Color(0xFFFF6B6B)),
                const SizedBox(height: 12),
                Text(
                  '$title Stopped',
                  style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                const Text(
                  'The game is paused. Your calibration remains active.',
                  style: TextStyle(color: Colors.white70, fontSize: 16),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    FilledButton.icon(
                      onPressed: () {
                        GameAudio.resume();
                        onResume();
                      },
                      icon: const Icon(Icons.play_arrow_rounded),
                      label: const Text('Resume'),
                    ),
                    FilledButton.tonalIcon(
                      onPressed: () {
                        GameAudio.restart();
                        onRestart();
                      },
                      icon: const Icon(Icons.refresh_rounded),
                      label: const Text('Restart'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () {
                        GameAudio.stopGame();
                        GameAudio.back();
                        onBack();
                      },
                      icon: const Icon(Icons.arrow_back_rounded),
                      label: const Text('Back to Games'),
                    ),
                  ],
                ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

enum _RacePhase { instructions, countdown, racing }

enum _RoadObstacleType { car, barrier, cone }

class GameModeScreen extends StatefulWidget {
  const GameModeScreen({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  State<GameModeScreen> createState() => _GameModeScreenState();
}

class _GameModeScreenState extends State<GameModeScreen> {
  final math.Random random = math.Random();
  Timer? timer;

  _RacePhase phase = _RacePhase.instructions;
  DateTime phaseStart = DateTime.now();

  // Virtual on-screen cursor used for the game controls.
  // It follows the same calibrated IMU cursor movement as the other modes.
  Offset cursor = const Offset(600, 430);

  // Player horizontal position across the road: -1 = far left, +1 = far right.
  double carX = 0.0;
  double speedKmh = 60.0;
  double distanceKm = 0.0;
  int score = 0;
  int bestSpeed = 60;
  bool braking = false;
  bool boosting = false;
  bool lastBraking = false;
  bool lastBoosting = false;
  bool gameStopped = false;
  double collisionFlash = 0.0;
  double roadScroll = 0.0;
  double spawnClock = 0.0;

  final List<_RoadObstacle> obstacles = <_RoadObstacle>[];

  @override
  void initState() {
    super.initState();
    phaseStart = DateTime.now();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void _tick() {
    if (!mounted) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    const dt = 0.016;

    final now = DateTime.now();
    final elapsed = now.difference(phaseStart);

    if (gameStopped) {
      widget.controller.consumeCursorDelta();
      return;
    }

    if (phase == _RacePhase.instructions) {
      widget.controller.consumeCursorDelta();
      if (elapsed >= const Duration(seconds: 4)) {
        phase = _RacePhase.countdown;
        phaseStart = now;
      }
      setState(() {});
      return;
    }

    if (phase == _RacePhase.countdown) {
      widget.controller.consumeCursorDelta();
      if (elapsed >= const Duration(seconds: 3)) {
        phase = _RacePhase.racing;
        phaseStart = now;
        GameAudio.start();
      }
      setState(() {});
      return;
    }

    final delta = widget.controller.consumeCursorDelta();

    // Keep a real virtual cursor for the game UI controls. This is separate
    // from the car position so the Back/Stop buttons can still be selected
    // with the same cursor + contraction interaction.
    final screenSize = MediaQuery.sizeOf(context);
    cursor = Offset(
      (cursor.dx + delta[0]).clamp(12.0, screenSize.width - 12.0),
      (cursor.dy + delta[1]).clamp(12.0, screenSize.height - 12.0),
    );

    // Same calibrated V2.7 cursor signal, reinterpreted as game controls.
    // Horizontal movement directly steers the car.
    carX = (carX + delta[0] * 0.0028).clamp(-0.88, 0.88);

    // Moving UP means negative screen Y in the calibrated cursor plane.
    braking = delta[1] < -3.0;
    boosting = widget.controller.contraction;

    if (boosting && !lastBoosting) {
      GameAudio.boost();
    }
    if (braking && !lastBraking) {
      GameAudio.brake();
    }
    lastBoosting = boosting;
    lastBraking = braking;

    const baseSpeed = 60.0;
    const maxSpeed = 180.0;
    const minSpeed = 25.0;

    if (boosting) {
      // Sustained residual-muscle contraction = accelerator.
      speedKmh += 82.0 * dt;
    }
    if (braking) {
      // Intentional UP movement = brake.
      final brakeStrength = (delta[1].abs() / 20.0).clamp(0.6, 2.0);
      speedKmh -= 115.0 * brakeStrength * dt;
    }

    // Gentle natural return toward a comfortable cruise speed.
    if (!boosting && !braking) {
      if (speedKmh > baseSpeed) {
        speedKmh -= 9.0 * dt;
      } else if (speedKmh < baseSpeed) {
        speedKmh += 5.0 * dt;
      }
    }

    speedKmh = speedKmh.clamp(minSpeed, maxSpeed);
    bestSpeed = math.max(bestSpeed, speedKmh.round());

    distanceKm += (speedKmh / 3600.0) * dt;
    score += math.max(1, (speedKmh * dt * 0.45).round());
    roadScroll = (roadScroll + dt * (0.22 + speedKmh / 145.0)) % 1.0;

    spawnClock += dt;
    final spawnInterval = (1.35 - speedKmh / 240.0).clamp(0.52, 1.15);
    if (spawnClock >= spawnInterval) {
      spawnClock = 0.0;
      _spawnObstacle();
    }

    final obstacleSpeed = 0.20 + speedKmh / 225.0;
    for (final obstacle in obstacles) {
      obstacle.y += obstacleSpeed * dt;
    }

    _checkCollisions();
    obstacles.removeWhere((o) => o.y > 1.18 || o.hit);

    collisionFlash = math.max(0.0, collisionFlash - dt * 2.8);
    setState(() {});
  }

  void _spawnObstacle() {
    final xPositions = <double>[-0.68, -0.34, 0.0, 0.34, 0.68];
    final x = xPositions[random.nextInt(xPositions.length)] +
        (random.nextDouble() - 0.5) * 0.06;
    final type = _RoadObstacleType.values[random.nextInt(_RoadObstacleType.values.length)];
    obstacles.add(
      _RoadObstacle(
        x: x,
        y: -0.12,
        type: type,
      ),
    );
  }

  void _checkCollisions() {
    for (final obstacle in obstacles) {
      if (obstacle.hit) continue;
      final lateralThreshold = obstacle.type == _RoadObstacleType.cone ? 0.13 : 0.18;
      final closeX = (obstacle.x - carX).abs() < lateralThreshold;
      final closeY = obstacle.y > 0.76 && obstacle.y < 0.94;
      if (closeX && closeY) {
        obstacle.hit = true;
        speedKmh = math.max(30.0, speedKmh * 0.55);
        score = math.max(0, score - 250);
        collisionFlash = 1.0;
        GameAudio.crash();
      }
    }
  }

  void _stopOrResume() {
    setState(() {
      gameStopped = !gameStopped;
    });
    if (gameStopped) {
      GameAudio.stopGame();
    } else {
      GameAudio.resume();
    }
  }

  void _restartRace() {
    setState(() {
      cursor = Offset(
        MediaQuery.sizeOf(context).width / 2,
        MediaQuery.sizeOf(context).height / 2,
      );
      carX = 0.0;
      speedKmh = 60.0;
      distanceKm = 0.0;
      score = 0;
      bestSpeed = 60;
      braking = false;
      boosting = false;
      lastBraking = false;
      lastBoosting = false;
      collisionFlash = 0.0;
      roadScroll = 0.0;
      spawnClock = 0.0;
      obstacles.clear();
      phase = _RacePhase.countdown;
      phaseStart = DateTime.now();
      gameStopped = false;
    });
  }

  int get countdownNumber {
    final elapsed = DateTime.now().difference(phaseStart).inMilliseconds;
    return math.max(1, 3 - (elapsed ~/ 1000));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _RoadRacePainter(
                carX: carX,
                speedKmh: speedKmh,
                distanceKm: distanceKm,
                score: score,
                bestSpeed: bestSpeed,
                obstacles: obstacles,
                roadScroll: roadScroll,
                boosting: boosting,
                braking: braking,
                collisionFlash: collisionFlash,
              ),
            ),
          ),
          if (phase == _RacePhase.racing)
            Positioned(
              right: 22,
              top: 20,
              child: _StatusPill(
                text: boosting
                    ? 'EMG BOOST · ${widget.controller.contractionPercent.toStringAsFixed(0)}%'
                    : braking
                        ? 'BRAKING · move UP to slow down'
                        : 'LEFT / RIGHT = steer · CONTRACT = accelerate · UP = brake',
              ),
            ),
          if (phase == _RacePhase.instructions)
            Positioned.fill(
              child: _RaceInstructionOverlay(
                contractionPercent: widget.controller.contractionPercent,
              ),
            ),
          if (phase == _RacePhase.countdown)
            Positioned.fill(
              child: Container(
                color: const Color(0x99040A14),
                alignment: Alignment.center,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'GET READY',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      '$countdownNumber',
                      style: const TextStyle(
                        color: Color(0xFFFFD166),
                        fontSize: 110,
                        height: 0.9,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (gameStopped)
            Positioned.fill(
              child: _GameStoppedOverlay(
                title: 'HelloDrive',
                onResume: () => setState(() => gameStopped = false),
                onRestart: _restartRace,
                onBack: () => Navigator.of(context).pop(),
              ),
            ),
          Positioned(
            left: 0,
            top: 0,
            child: _GameTopControls(
              controller: widget.controller,
              cursor: cursor,
              stopped: gameStopped,
              onBack: () => Navigator.of(context).pop(),
              onStop: _stopOrResume,
            ),
          ),
        ],
      ),
    );
  }
}

class _RoadObstacle {
  _RoadObstacle({
    required this.x,
    required this.y,
    required this.type,
  });

  final double x;
  double y;
  final _RoadObstacleType type;
  bool hit = false;
}

class _RaceInstructionOverlay extends StatelessWidget {
  const _RaceInstructionOverlay({required this.contractionPercent});

  final double contractionPercent;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xD9071020),
      alignment: Alignment.center,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 900),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 42, vertical: 34),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.directions_car_filled_rounded,
                  color: Color(0xFFFFD166),
                  size: 74,
                ),
                const SizedBox(height: 10),
                const Text(
                  'HelloDrive',
                  style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900),
                ),
                const Text(
                  'Waveletech arcade obstacle racing',
                  style: TextStyle(color: Colors.white70, fontSize: 17),
                ),
                const SizedBox(height: 28),
                const Row(
                  children: [
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.arrow_back_rounded,
                        title: 'MOVE LEFT',
                        subtitle: 'Steer left',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.arrow_forward_rounded,
                        title: 'MOVE RIGHT',
                        subtitle: 'Steer right',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.arrow_upward_rounded,
                        title: 'MOVE UP',
                        subtitle: 'Brake / slow down',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.bolt_rounded,
                        title: 'CONTRACT',
                        subtitle: 'Accelerate / boost',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Text(
                  'Current muscle activation: ${contractionPercent.toStringAsFixed(0)}%',
                  style: const TextStyle(
                    color: Color(0xFF137A59),
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'The race starts automatically after this instruction and a 3-second countdown.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white60),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ControlHint extends StatelessWidget {
  const _ControlHint({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      decoration: BoxDecoration(
        color: const Color(0xFF17243C),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2C4165)),
      ),
      child: Column(
        children: [
          Icon(icon, color: const Color(0xFFA695FF), size: 34),
          const SizedBox(height: 8),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 3),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white60, fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _RoadRacePainter extends CustomPainter {
  _RoadRacePainter({
    required this.carX,
    required this.speedKmh,
    required this.distanceKm,
    required this.score,
    required this.bestSpeed,
    required this.obstacles,
    required this.roadScroll,
    required this.boosting,
    required this.braking,
    required this.collisionFlash,
  });

  final double carX;
  final double speedKmh;
  final double distanceKm;
  final int score;
  final int bestSpeed;
  final List<_RoadObstacle> obstacles;
  final double roadScroll;
  final bool boosting;
  final bool braking;
  final double collisionFlash;

  @override
  void paint(Canvas canvas, Size size) {
    final sky = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF7ED7F7), Color(0xFFD5F5FF)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, sky);

    final horizon = size.height * 0.16;
    canvas.drawRect(
      Rect.fromLTRB(0, horizon, size.width, size.height),
      Paint()..color = const Color(0xFF5FD17A),
    );

    // Road has a mild perspective: narrow at the horizon, wide near the car.
    final cx = size.width / 2;
    final topHalf = size.width * 0.17;
    final bottomHalf = size.width * 0.34;
    final road = Path()
      ..moveTo(cx - topHalf, horizon)
      ..lineTo(cx + topHalf, horizon)
      ..lineTo(cx + bottomHalf, size.height)
      ..lineTo(cx - bottomHalf, size.height)
      ..close();
    canvas.drawPath(road, Paint()..color = const Color(0xFF39424E));

    // Road shoulders.
    final leftShoulder = Path()
      ..moveTo(cx - topHalf - 13, horizon)
      ..lineTo(cx - topHalf, horizon)
      ..lineTo(cx - bottomHalf, size.height)
      ..lineTo(cx - bottomHalf - 20, size.height)
      ..close();
    final rightShoulder = Path()
      ..moveTo(cx + topHalf, horizon)
      ..lineTo(cx + topHalf + 13, horizon)
      ..lineTo(cx + bottomHalf + 20, size.height)
      ..lineTo(cx + bottomHalf, size.height)
      ..close();
    final shoulderPaint = Paint()..color = const Color(0xFFFFE37D);
    canvas.drawPath(leftShoulder, shoulderPaint);
    canvas.drawPath(rightShoulder, shoulderPaint);

    // Scenery blocks / trees to create the bright casual-game feeling.
    for (var i = 0; i < 11; i++) {
      final yN = ((i / 10.0 + roadScroll * 0.18) % 1.0);
      final y = horizon + yN * (size.height - horizon);
      final perspective = yN;
      final sideOffset = topHalf + (bottomHalf - topHalf) * perspective + 55;
      final r = 10 + 18 * perspective;
      canvas.drawCircle(
        Offset(cx - sideOffset - (i % 2) * 35, y),
        r,
        Paint()..color = i.isEven ? const Color(0xFF1FA66A) : const Color(0xFF39B96B),
      );
      canvas.drawCircle(
        Offset(cx + sideOffset + ((i + 1) % 2) * 35, y),
        r,
        Paint()..color = i.isEven ? const Color(0xFF39B96B) : const Color(0xFF1FA66A),
      );
    }

    // Moving dashed lane dividers.
    for (final laneFraction in const <double>[-1 / 3, 1 / 3]) {
      for (var i = -1; i < 14; i++) {
        final yN = ((i / 12.0 + roadScroll) % 1.08);
        final y = horizon + yN * (size.height - horizon);
        final half = topHalf + (bottomHalf - topHalf) * yN;
        final x = cx + half * laneFraction;
        final h = 14 + 34 * yN;
        final w = 3 + 5 * yN;
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(center: Offset(x, y), width: w, height: h),
            const Radius.circular(4),
          ),
          Paint()..color = const Color(0xFFEFF2F6),
        );
      }
    }

    double roadX(double xNorm, double yNorm) {
      final half = topHalf + (bottomHalf - topHalf) * yNorm.clamp(0.0, 1.0);
      return cx + xNorm * half * 0.86;
    }

    for (final obstacle in obstacles) {
      final yN = obstacle.y.clamp(0.0, 1.0);
      final y = horizon + (size.height - horizon) * yN;
      final x = roadX(obstacle.x, yN);
      final scale = 0.42 + yN * 0.85;
      switch (obstacle.type) {
        case _RoadObstacleType.car:
          _drawCar(
            canvas,
            Offset(x, y),
            42 * scale,
            const Color(0xFFFF6B6B),
            facingUp: false,
          );
          break;
        case _RoadObstacleType.barrier:
          final rect = Rect.fromCenter(
            center: Offset(x, y),
            width: 62 * scale,
            height: 28 * scale,
          );
          canvas.drawRRect(
            RRect.fromRectAndRadius(rect, Radius.circular(7 * scale)),
            Paint()..color = const Color(0xFFFFA62B),
          );
          canvas.drawRect(
            Rect.fromCenter(
              center: Offset(x, y),
              width: 48 * scale,
              height: 7 * scale,
            ),
            Paint()..color = Colors.white,
          );
          break;
        case _RoadObstacleType.cone:
          final cone = Path()
            ..moveTo(x, y - 24 * scale)
            ..lineTo(x - 18 * scale, y + 20 * scale)
            ..lineTo(x + 18 * scale, y + 20 * scale)
            ..close();
          canvas.drawPath(cone, Paint()..color = const Color(0xFFFF8A3D));
          canvas.drawRect(
            Rect.fromCenter(
              center: Offset(x, y + 4 * scale),
              width: 24 * scale,
              height: 6 * scale,
            ),
            Paint()..color = Colors.white,
          );
          break;
      }
    }

    final playerY = size.height * 0.84;
    final playerX = roadX(carX, 0.84);
    if (boosting) {
      final flame = Path()
        ..moveTo(playerX - 10, playerY + 34)
        ..lineTo(playerX, playerY + 61 + randomLike(roadScroll) * 9)
        ..lineTo(playerX + 10, playerY + 34)
        ..close();
      canvas.drawPath(flame, Paint()..color = const Color(0xFFFFD166));
    }
    _drawCar(
      canvas,
      Offset(playerX, playerY),
      58,
      braking ? const Color(0xFF4EA8DE) : const Color(0xFF6D5DFB),
      facingUp: true,
    );

    // HUD cards.
    _drawHudCard(canvas, const Offset(32, 92), 'SPEED', '${speedKmh.round()} km/h');
    _drawHudCard(canvas, const Offset(32, 174), 'DISTANCE', '${distanceKm.toStringAsFixed(2)} km');
    _drawHudCard(canvas, Offset(size.width - 232, 92), 'SCORE', '$score');
    _drawHudCard(canvas, Offset(size.width - 232, 174), 'TOP SPEED', '$bestSpeed km/h');

    if (collisionFlash > 0) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = Color.fromRGBO(255, 55, 72, collisionFlash * 0.28),
      );
      final tp = TextPainter(
        text: const TextSpan(
          text: 'WATCH OUT!',
          style: TextStyle(
            color: Colors.white,
            fontSize: 42,
            fontWeight: FontWeight.w900,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(cx - tp.width / 2, size.height * 0.28));
    }
  }

  double randomLike(double x) => (math.sin(x * 39.7) + 1) / 2;

  void _drawCar(
    Canvas canvas,
    Offset center,
    double width,
    Color bodyColor, {
    required bool facingUp,
  }) {
    final h = width * 1.55;
    final body = Rect.fromCenter(center: center, width: width, height: h);
    canvas.drawRRect(
      RRect.fromRectAndRadius(body, Radius.circular(width * 0.22)),
      Paint()..color = bodyColor,
    );

    final windshield = Rect.fromCenter(
      center: Offset(center.dx, center.dy - h * 0.17),
      width: width * 0.66,
      height: h * 0.26,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(windshield, Radius.circular(width * 0.12)),
      Paint()..color = const Color(0xFFBEE8FF),
    );

    final wheelPaint = Paint()..color = const Color(0xFF141A22);
    final wheelW = width * 0.13;
    final wheelH = h * 0.22;
    for (final side in <double>[-1, 1]) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(center.dx + side * width * 0.54, center.dy - h * 0.20),
            width: wheelW,
            height: wheelH,
          ),
          const Radius.circular(3),
        ),
        wheelPaint,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
            center: Offset(center.dx + side * width * 0.54, center.dy + h * 0.24),
            width: wheelW,
            height: wheelH,
          ),
          const Radius.circular(3),
        ),
        wheelPaint,
      );
    }

    if (facingUp) {
      canvas.drawCircle(
        Offset(center.dx - width * 0.28, center.dy - h * 0.44),
        width * 0.07,
        Paint()..color = const Color(0xFFFFF2A8),
      );
      canvas.drawCircle(
        Offset(center.dx + width * 0.28, center.dy - h * 0.44),
        width * 0.07,
        Paint()..color = const Color(0xFFFFF2A8),
      );
    }
  }

  void _drawHudCard(Canvas canvas, Offset pos, String label, String value) {
    const w = 200.0;
    const h = 68.0;
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(pos.dx, pos.dy, w, h), const Radius.circular(16)),
      Paint()..color = const Color(0xD9111B2B),
    );
    final labelPainter = TextPainter(
      text: TextSpan(
        text: label,
        style: const TextStyle(
          color: Color(0xFF9EACC0),
          fontSize: 12,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.1,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    labelPainter.paint(canvas, pos + const Offset(14, 10));
    final valuePainter = TextPainter(
      text: TextSpan(
        text: value,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 23,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    valuePainter.paint(canvas, pos + const Offset(14, 28));
  }

  @override
  bool shouldRepaint(covariant _RoadRacePainter oldDelegate) => true;
}


enum _MetroPhase { instructions, countdown, running }

enum _MetroObjectType { train, lowBarrier, overheadBarrier, coin }

class MetroDashScreen extends StatefulWidget {
  const MetroDashScreen({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  State<MetroDashScreen> createState() => _MetroDashScreenState();
}

class _MetroDashScreenState extends State<MetroDashScreen> {
  final math.Random random = math.Random();
  Timer? timer;

  _MetroPhase phase = _MetroPhase.instructions;
  DateTime phaseStart = DateTime.now();

  int lane = 1;
  double laneVisual = 1.0;
  double horizontalIntent = 0.0;
  double verticalIntent = 0.0;
  DateTime lastLaneChange = DateTime.fromMillisecondsSinceEpoch(0);

  double jumpHeight = 0.0;
  double jumpVelocity = 0.0;
  double slideTimer = 0.0;

  double runSpeed = 1.0;
  double distance = 0.0;
  int score = 0;
  int coins = 0;
  double trackScroll = 0.0;
  double spawnClock = 0.0;
  double collisionFlash = 0.0;
  double boostGlow = 0.0;
  bool gameStopped = false;
  bool lastBoosting = false;

  final List<_MetroObject> objects = <_MetroObject>[];

  bool get jumping => jumpHeight > 0.02 || jumpVelocity.abs() > 0.01;
  bool get sliding => slideTimer > 0.0;
  bool get boosting => widget.controller.contraction;

  @override
  void initState() {
    super.initState();
    phaseStart = DateTime.now();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  int get countdownNumber {
    final elapsed = DateTime.now().difference(phaseStart).inMilliseconds;
    return math.max(1, 3 - (elapsed ~/ 1000));
  }

  void _tick() {
    if (!mounted) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    const dt = 0.016;
    final now = DateTime.now();
    final elapsed = now.difference(phaseStart);

    if (gameStopped) {
      widget.controller.consumeCursorDelta();
      return;
    }

    if (phase == _MetroPhase.instructions) {
      widget.controller.consumeCursorDelta();
      if (elapsed >= const Duration(seconds: 5)) {
        phase = _MetroPhase.countdown;
        phaseStart = now;
      }
      setState(() {});
      return;
    }

    if (phase == _MetroPhase.countdown) {
      widget.controller.consumeCursorDelta();
      if (elapsed >= const Duration(seconds: 3)) {
        phase = _MetroPhase.running;
        phaseStart = now;
        GameAudio.start();
      }
      setState(() {});
      return;
    }

    final delta = widget.controller.consumeCursorDelta();
    horizontalIntent = horizontalIntent * 0.62 + delta[0];
    verticalIntent = verticalIntent * 0.62 + delta[1];

    if (now.difference(lastLaneChange).inMilliseconds > 250) {
      if (horizontalIntent > 10.0 && lane < 2) {
        lane++;
        horizontalIntent = 0.0;
        lastLaneChange = now;
        GameAudio.laneChange();
      } else if (horizontalIntent < -10.0 && lane > 0) {
        lane--;
        horizontalIntent = 0.0;
        lastLaneChange = now;
        GameAudio.laneChange();
      }
    }

    if (!jumping && !sliding) {
      if (verticalIntent < -9.0) {
        jumpVelocity = 2.75;
        verticalIntent = 0.0;
        GameAudio.jump();
      } else if (verticalIntent > 9.0) {
        slideTimer = 0.72;
        verticalIntent = 0.0;
        GameAudio.slide();
      }
    }

    laneVisual += (lane - laneVisual) * 0.18;

    if (jumping) {
      jumpHeight += jumpVelocity * dt;
      jumpVelocity -= 5.8 * dt;
      if (jumpHeight <= 0.0 && jumpVelocity < 0.0) {
        jumpHeight = 0.0;
        jumpVelocity = 0.0;
      }
    }

    slideTimer = math.max(0.0, slideTimer - dt);

    if (boosting && !lastBoosting) {
      GameAudio.boost();
    }
    lastBoosting = boosting;

    if (boosting) {
      runSpeed += 0.85 * dt;
      boostGlow = math.min(1.0, boostGlow + 3.0 * dt);
    } else {
      runSpeed -= 0.34 * dt;
      boostGlow = math.max(0.0, boostGlow - 2.0 * dt);
    }
    runSpeed = runSpeed.clamp(1.0, 1.75).toDouble();

    distance += (10.0 + 9.0 * runSpeed) * dt;
    score += math.max(1, (4.5 * runSpeed).round());
    trackScroll = (trackScroll + dt * (0.42 + runSpeed * 0.34)) % 1.0;

    spawnClock += dt;
    final spawnInterval = (1.05 - 0.22 * runSpeed).clamp(0.52, 0.90);
    if (spawnClock >= spawnInterval) {
      spawnClock = 0.0;
      _spawnObject();
    }

    final objectSpeed = 0.31 + 0.16 * runSpeed;
    for (final object in objects) {
      object.y += objectSpeed * dt;
    }

    _checkInteractions();
    objects.removeWhere((o) => o.y > 1.18 || o.consumed);
    collisionFlash = math.max(0.0, collisionFlash - 2.6 * dt);

    setState(() {});
  }

  void _spawnObject() {
    final spawnLane = random.nextInt(3);
    final roll = random.nextDouble();
    _MetroObjectType type;
    if (roll < 0.28) {
      type = _MetroObjectType.train;
    } else if (roll < 0.51) {
      type = _MetroObjectType.lowBarrier;
    } else if (roll < 0.69) {
      type = _MetroObjectType.overheadBarrier;
    } else {
      type = _MetroObjectType.coin;
    }

    objects.add(
      _MetroObject(
        lane: spawnLane,
        y: -0.10,
        type: type,
      ),
    );

    // Sometimes create a short coin trail without making the obstacle pattern impossible.
    if (type == _MetroObjectType.coin && random.nextDouble() < 0.45) {
      objects.add(
        _MetroObject(
          lane: spawnLane,
          y: -0.28,
          type: _MetroObjectType.coin,
        ),
      );
    }
  }

  void _checkInteractions() {
    for (final object in objects) {
      if (object.consumed) continue;
      if ((object.lane - laneVisual).abs() > 0.42) continue;
      if (object.y < 0.76 || object.y > 0.93) continue;

      if (object.type == _MetroObjectType.coin) {
        object.consumed = true;
        coins++;
        score += 120;
        GameAudio.coin();
        continue;
      }

      var avoided = false;
      if (object.type == _MetroObjectType.lowBarrier) {
        avoided = jumpHeight > 0.34;
      } else if (object.type == _MetroObjectType.overheadBarrier) {
        avoided = sliding;
      }

      // A train must be avoided by changing lane.
      if (!avoided) {
        object.consumed = true;
        collisionFlash = 1.0;
        GameAudio.crash();
        score = math.max(0, score - 250);
        runSpeed = math.max(1.0, runSpeed * 0.72);
      }
    }
  }

  void _stopOrResume() {
    setState(() {
      gameStopped = !gameStopped;
    });
    if (gameStopped) {
      GameAudio.stopGame();
    } else {
      GameAudio.resume();
    }
  }

  void _restartMetro() {
    setState(() {
      lane = 1;
      laneVisual = 1.0;
      horizontalIntent = 0.0;
      verticalIntent = 0.0;
      jumpHeight = 0.0;
      jumpVelocity = 0.0;
      slideTimer = 0.0;
      runSpeed = 1.0;
      distance = 0.0;
      score = 0;
      coins = 0;
      trackScroll = 0.0;
      spawnClock = 0.0;
      collisionFlash = 0.0;
      boostGlow = 0.0;
      lastBoosting = false;
      objects.clear();
      phase = _MetroPhase.countdown;
      phaseStart = DateTime.now();
      gameStopped = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _MetroDashPainter(
                laneVisual: laneVisual,
                jumpHeight: jumpHeight,
                sliding: sliding,
                runSpeed: runSpeed,
                distance: distance,
                score: score,
                coins: coins,
                objects: objects,
                trackScroll: trackScroll,
                boostGlow: boostGlow,
                collisionFlash: collisionFlash,
              ),
            ),
          ),
          if (phase == _MetroPhase.running)
            Positioned(
              right: 22,
              top: 20,
              child: _StatusPill(
                text: boosting
                    ? 'BOOST · EMG ${widget.controller.contractionPercent.toStringAsFixed(0)}%'
                    : sliding
                        ? 'SLIDE'
                        : jumping
                            ? 'JUMP'
                            : 'LEFT / RIGHT lane · UP jump · DOWN slide · CONTRACT boost',
              ),
            ),
          if (phase == _MetroPhase.instructions)
            Positioned.fill(
              child: _MetroInstructionOverlay(
                contractionPercent: widget.controller.contractionPercent,
              ),
            ),
          if (phase == _MetroPhase.countdown)
            Positioned.fill(
              child: Container(
                color: const Color(0x99030C18),
                alignment: Alignment.center,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      'READY TO RUN',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      '$countdownNumber',
                      style: const TextStyle(
                        color: Color(0xFFFFD84A),
                        fontSize: 112,
                        height: 0.9,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (gameStopped)
            Positioned.fill(
              child: _GameStoppedOverlay(
                title: 'Metro Dash',
                onResume: () => setState(() => gameStopped = false),
                onRestart: _restartMetro,
                onBack: () => Navigator.of(context).pop(),
              ),
            ),
          // Always rendered last so navigation remains visible above overlays.
          Positioned(
            left: 0,
            top: 0,
            child: _GameTopControls(
              controller: widget.controller,
              stopped: gameStopped,
              onBack: () => Navigator.of(context).pop(),
              onStop: _stopOrResume,
            ),
          ),
        ],
      ),
    );
  }
}

class _MetroObject {
  _MetroObject({
    required this.lane,
    required this.y,
    required this.type,
  });

  final int lane;
  double y;
  final _MetroObjectType type;
  bool consumed = false;
}

class _MetroInstructionOverlay extends StatelessWidget {
  const _MetroInstructionOverlay({required this.contractionPercent});

  final double contractionPercent;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xD8091730),
      alignment: Alignment.center,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 980),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.directions_run_rounded, color: Color(0xFF43E6C4), size: 78),
                const SizedBox(height: 8),
                const Text(
                  'Metro Dash',
                  style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 3),
                const Text(
                  'Original HelloBand 3-lane city runner',
                  style: TextStyle(color: Colors.white70, fontSize: 17),
                ),
                const SizedBox(height: 26),
                const Row(
                  children: [
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.swap_horiz_rounded,
                        title: 'LEFT / RIGHT',
                        subtitle: 'Change lane',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.arrow_upward_rounded,
                        title: 'MOVE UP',
                        subtitle: 'Jump barrier',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.arrow_downward_rounded,
                        title: 'MOVE DOWN',
                        subtitle: 'Slide under sign',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.bolt_rounded,
                        title: 'CONTRACT',
                        subtitle: 'Speed boost',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 22),
                Text(
                  'Current muscle activation: ${contractionPercent.toStringAsFixed(0)}%',
                  style: const TextStyle(
                    color: Color(0xFF137A59),
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Avoid trains, jump low barriers, slide under overhead barriers, and collect coins. The run begins after the 3-second countdown.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white60, height: 1.4),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MetroDashPainter extends CustomPainter {
  _MetroDashPainter({
    required this.laneVisual,
    required this.jumpHeight,
    required this.sliding,
    required this.runSpeed,
    required this.distance,
    required this.score,
    required this.coins,
    required this.objects,
    required this.trackScroll,
    required this.boostGlow,
    required this.collisionFlash,
  });

  final double laneVisual;
  final double jumpHeight;
  final bool sliding;
  final double runSpeed;
  final double distance;
  final int score;
  final int coins;
  final List<_MetroObject> objects;
  final double trackScroll;
  final double boostGlow;
  final double collisionFlash;

  @override
  void paint(Canvas canvas, Size size) {
    final skyRect = Offset.zero & size;
    final sky = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFF39C7F4),
          Color(0xFF84E8F2),
          Color(0xFFFFD36F),
        ],
        stops: [0.0, 0.44, 1.0],
      ).createShader(skyRect);
    canvas.drawRect(skyRect, sky);

    final horizon = size.height * 0.18;
    final cx = size.width / 2;

    // Stylized city blocks, original to HelloBand.
    for (var i = 0; i < 12; i++) {
      final leftSide = i < 6;
      final idx = leftSide ? i : i - 6;
      final w = 74.0 + (idx % 3) * 18.0;
      final h = 110.0 + (idx % 4) * 32.0;
      final x = leftSide
          ? 18.0 + idx * 82.0
          : size.width - 18.0 - (idx + 1) * 82.0;
      final rect = Rect.fromLTWH(x, horizon - h + 25, w, h);
      final colors = <Color>[
        const Color(0xFFF06A66),
        const Color(0xFF8C65D7),
        const Color(0xFF28A5B8),
        const Color(0xFFF0A843),
      ];
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(8)),
        Paint()..color = colors[i % colors.length],
      );
      for (var row = 0; row < 3; row++) {
        for (var col = 0; col < 2; col++) {
          canvas.drawRect(
            Rect.fromLTWH(
              rect.left + 14 + col * 28,
              rect.top + 18 + row * 28,
              12,
              15,
            ),
            Paint()..color = const Color(0xFFFFE7A0),
          );
        }
      }
    }

    // Rail corridor / perspective base.
    final topHalf = size.width * 0.13;
    final bottomHalf = size.width * 0.39;
    final corridor = Path()
      ..moveTo(cx - topHalf, horizon)
      ..lineTo(cx + topHalf, horizon)
      ..lineTo(cx + bottomHalf, size.height)
      ..lineTo(cx - bottomHalf, size.height)
      ..close();
    canvas.drawPath(corridor, Paint()..color = const Color(0xFF44505B));

    // Track sleepers moving toward the player.
    for (var i = 0; i < 18; i++) {
      final yn = ((i / 17.0 + trackScroll) % 1.0);
      final y = horizon + yn * (size.height - horizon);
      final half = topHalf + (bottomHalf - topHalf) * yn;
      final thickness = 2.0 + 8.0 * yn;
      canvas.drawRect(
        Rect.fromLTRB(cx - half, y, cx + half, y + thickness),
        Paint()..color = const Color(0xFF75614D),
      );
    }

    // Three lanes with six bright rails.
    for (var laneIndex = 0; laneIndex < 3; laneIndex++) {
      for (final side in <double>[-1.0, 1.0]) {
        final laneCenterTop = cx + (laneIndex - 1) * topHalf * 0.62;
        final laneCenterBottom = cx + (laneIndex - 1) * bottomHalf * 0.62;
        final offsetTop = side * topHalf * 0.16;
        final offsetBottom = side * bottomHalf * 0.16;
        final rail = Path()
          ..moveTo(laneCenterTop + offsetTop, horizon)
          ..lineTo(laneCenterBottom + offsetBottom, size.height);
        canvas.drawPath(
          rail,
          Paint()
            ..color = const Color(0xFFDDE4E8)
            ..strokeWidth = 5
            ..style = PaintingStyle.stroke,
        );
      }
    }

    // Overhead gantries create depth.
    for (var i = 0; i < 4; i++) {
      final yn = ((i / 4 + trackScroll * 0.45) % 1.0);
      final y = horizon + yn * (size.height - horizon) * 0.72;
      final half = topHalf + (bottomHalf - topHalf) * yn * 0.72;
      final alpha = (80 + 120 * yn).round().clamp(0, 255).toInt();
      final p = Paint()
        ..color = Color.fromARGB(alpha, 34, 49, 57)
        ..strokeWidth = 4;
      canvas.drawLine(Offset(cx - half, y), Offset(cx + half, y), p);
      canvas.drawLine(Offset(cx - half, y), Offset(cx - half, y - 52 * yn), p);
      canvas.drawLine(Offset(cx + half, y), Offset(cx + half, y - 52 * yn), p);
    }

    for (final object in objects) {
      _drawMetroObject(canvas, size, object, horizon, topHalf, bottomHalf);
    }

    _drawRunner(canvas, size, horizon, topHalf, bottomHalf);
    _drawMetroHud(canvas, size);

    if (collisionFlash > 0) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = Color.fromRGBO(255, 55, 65, 0.28 * collisionFlash),
      );
    }
  }

  double _laneX(Size size, double laneIndex, double yn, double topHalf, double bottomHalf) {
    final cx = size.width / 2;
    final half = topHalf + (bottomHalf - topHalf) * yn;
    return cx + (laneIndex - 1.0) * half * 0.62;
  }

  void _drawMetroObject(
    Canvas canvas,
    Size size,
    _MetroObject object,
    double horizon,
    double topHalf,
    double bottomHalf,
  ) {
    final yn = object.y.clamp(0.0, 1.05).toDouble();
    final y = horizon + yn * (size.height - horizon);
    final x = _laneX(size, object.lane.toDouble(), yn, topHalf, bottomHalf);
    final scale = 0.28 + 1.05 * yn;

    if (object.type == _MetroObjectType.coin) {
      final r = 11.0 * scale;
      canvas.drawCircle(Offset(x, y), r, Paint()..color = const Color(0xFFFFD84A));
      canvas.drawCircle(
        Offset(x, y),
        r * 0.62,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3 * scale
          ..color = const Color(0xFFFF9F1C),
      );
      return;
    }

    if (object.type == _MetroObjectType.train) {
      final w = 72.0 * scale;
      final h = 120.0 * scale;
      final rect = Rect.fromCenter(center: Offset(x, y - h * 0.35), width: w, height: h);
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, Radius.circular(11 * scale)),
        Paint()..color = object.lane.isEven ? const Color(0xFFEF5350) : const Color(0xFF2569D8),
      );
      canvas.drawRect(
        Rect.fromLTWH(rect.left + 10 * scale, rect.top + 18 * scale, w - 20 * scale, 28 * scale),
        Paint()..color = const Color(0xFFBCEBFF),
      );
      canvas.drawRect(
        Rect.fromLTWH(rect.left + 8 * scale, rect.bottom - 24 * scale, w - 16 * scale, 8 * scale),
        Paint()..color = const Color(0xFFFFD84A),
      );
      return;
    }

    if (object.type == _MetroObjectType.lowBarrier) {
      final w = 82.0 * scale;
      final h = 42.0 * scale;
      final rect = Rect.fromCenter(center: Offset(x, y), width: w, height: h);
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, Radius.circular(6 * scale)),
        Paint()..color = const Color(0xFFFF7B35),
      );
      for (var i = 0; i < 4; i++) {
        canvas.drawRect(
          Rect.fromLTWH(rect.left + i * w / 4, rect.top, w / 8, h),
          Paint()..color = Colors.white,
        );
      }
      return;
    }

    // Overhead barrier: slide beneath it.
    final w = 94.0 * scale;
    final h = 78.0 * scale;
    final p = Paint()..color = const Color(0xFF7A4AD8);
    canvas.drawRect(Rect.fromLTWH(x - w / 2, y - h, 9 * scale, h), p);
    canvas.drawRect(Rect.fromLTWH(x + w / 2 - 9 * scale, y - h, 9 * scale, h), p);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(x - w / 2, y - h, w, 25 * scale),
        Radius.circular(5 * scale),
      ),
      p,
    );
  }

  void _drawRunner(
    Canvas canvas,
    Size size,
    double horizon,
    double topHalf,
    double bottomHalf,
  ) {
    final playerY = size.height * 0.83 - jumpHeight * 150.0;
    final x = _laneX(size, laneVisual, 0.86, topHalf, bottomHalf);
    final scaleY = sliding ? 0.62 : 1.0;

    if (boostGlow > 0.05) {
      canvas.drawCircle(
        Offset(x, playerY + 12),
        48 + 18 * boostGlow,
        Paint()..color = Color.fromRGBO(67, 230, 196, 0.15 + 0.20 * boostGlow),
      );
    }

    canvas.save();
    canvas.translate(x, playerY);
    canvas.scale(1.0, scaleY);

    // Original simple HelloBand runner character.
    final skin = Paint()..color = const Color(0xFFF2B384);
    final shirt = Paint()..color = const Color(0xFFFC4F73);
    final pants = Paint()..color = const Color(0xFF2469D8);
    final dark = Paint()..color = const Color(0xFF19243A);
    final shoe = Paint()..color = const Color(0xFFFFD84A);

    canvas.drawCircle(const Offset(0, -52), 17, skin);
    canvas.drawArc(
      Rect.fromCenter(center: const Offset(0, -58), width: 36, height: 25),
      math.pi,
      math.pi,
      false,
      dark,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-18, -36, 36, 43), const Radius.circular(10)),
      shirt,
    );
    final legPaint = Paint()
      ..color = pants.color
      ..strokeWidth = 9
      ..strokeCap = StrokeCap.round;
    final shoePaint = Paint()
      ..color = shoe.color
      ..strokeWidth = 8
      ..strokeCap = StrokeCap.round;
    final armPaint = Paint()
      ..color = skin.color
      ..strokeWidth = 7
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(const Offset(-10, 5), const Offset(-18, 37), legPaint);
    canvas.drawLine(const Offset(10, 5), const Offset(18, 37), legPaint);
    canvas.drawLine(const Offset(-18, 37), const Offset(-31, 39), shoePaint);
    canvas.drawLine(const Offset(18, 37), const Offset(31, 39), shoePaint);
    canvas.drawLine(const Offset(-16, -25), const Offset(-32, -4), armPaint);
    canvas.drawLine(const Offset(16, -25), const Offset(32, -4), armPaint);
    canvas.restore();
  }

  void _drawMetroHud(Canvas canvas, Size size) {
    final panel = RRect.fromRectAndRadius(
      Rect.fromLTWH(size.width / 2 - 230, 18, 460, 72),
      const Radius.circular(22),
    );
    canvas.drawRRect(panel, Paint()..color = const Color(0xD9121C2D));

    final speedPercent = ((runSpeed - 1.0) / 0.75 * 100.0).clamp(0.0, 100.0);
    final tp = TextPainter(textDirection: TextDirection.ltr);
    tp.text = TextSpan(
      text: 'SCORE $score     COINS $coins     DIST ${distance.toStringAsFixed(0)} m     BOOST ${speedPercent.toStringAsFixed(0)}%',
      style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w900),
    );
    tp.layout();
    tp.paint(canvas, Offset(size.width / 2 - tp.width / 2, 46));
  }

  @override
  bool shouldRepaint(covariant _MetroDashPainter oldDelegate) => true;
}


enum _FruitPhase { instructions, countdown, playing }
enum _FruitKind { apple, orange, kiwi, berry, bomb }

class FruitSliceScreen extends StatefulWidget {
  const FruitSliceScreen({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  State<FruitSliceScreen> createState() => _FruitSliceScreenState();
}

class _FruitSliceScreenState extends State<FruitSliceScreen> {
  final math.Random random = math.Random();
  Timer? timer;
  _FruitPhase phase = _FruitPhase.instructions;
  DateTime phaseStart = DateTime.now();
  Size area = Size.zero;
  Offset blade = const Offset(620, 430);
  Offset previousBlade = const Offset(620, 430);
  final List<Offset> trail = <Offset>[];
  final List<_FruitTarget> fruits = <_FruitTarget>[];
  final List<_JuiceParticle> particles = <_JuiceParticle>[];
  double spawnClock = 0.0;
  int score = 0;
  int combo = 0;
  int bestCombo = 0;
  int sliced = 0;
  int bombsHit = 0;
  int missed = 0;
  double flash = 0.0;
  bool gameStopped = false;

  // Fruit Slice is intentionally motion-only: moving LEFT / RIGHT slices automatically.

  @override
  void initState() {
    super.initState();
    phaseStart = DateTime.now();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  int get countdownNumber {
    final elapsed = DateTime.now().difference(phaseStart).inMilliseconds;
    return math.max(1, 3 - (elapsed ~/ 1000));
  }

  void _tick() {
    if (!mounted || area == Size.zero) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    const dt = 0.016;
    final now = DateTime.now();
    final elapsed = now.difference(phaseStart);

    final delta = widget.controller.consumeCursorDelta();

    if (gameStopped) {
      return;
    }

    // Fruit Slice uses only LEFT / RIGHT movement. The blade stays on a fixed
    // horizontal cutting line, so no contraction is required to slice.
    final bladeY = area.height * 0.72;
    previousBlade = Offset(blade.dx, bladeY);
    blade = Offset(
      (blade.dx + delta[0]).clamp(18.0, area.width - 18.0),
      bladeY,
    );

    trail.add(blade);
    if (trail.length > 22) trail.removeAt(0);

    if (phase == _FruitPhase.instructions) {
      if (elapsed >= const Duration(seconds: 5)) {
        phase = _FruitPhase.countdown;
        phaseStart = now;
      }
      setState(() {});
      return;
    }

    if (phase == _FruitPhase.countdown) {
      if (elapsed >= const Duration(seconds: 3)) {
        phase = _FruitPhase.playing;
        phaseStart = now;
        GameAudio.start();
      }
      setState(() {});
      return;
    }

    spawnClock += dt;
    final spawnInterval = (0.78 - score / 25000.0).clamp(0.38, 0.78);
    if (spawnClock >= spawnInterval) {
      spawnClock = 0.0;
      _spawnFruit();
      if (random.nextDouble() < 0.18) _spawnFruit(extra: true);
    }

    for (final fruit in fruits) {
      fruit.x += fruit.vx * dt;
      fruit.y += fruit.vy * dt;
      // Gentle acceleration makes the top-to-bottom drop feel more natural.
      fruit.vy += 28.0 * dt;
      fruit.rotation += fruit.spin * dt;
      if (fruit.cut) fruit.fade -= 2.8 * dt;
    }

    // Blade is always active: crossing a fruit with LEFT / RIGHT arm motion
    // slices it immediately.
    for (final fruit in fruits) {
      if (fruit.cut) continue;
      final center = Offset(fruit.x, fruit.y);
      final d = _distanceToSegment(center, previousBlade, blade);
      if (d <= fruit.radius + 14.0) {
        _slice(fruit);
      }
    }

    for (final p in particles) {
      p.position += p.velocity * dt;
      p.velocity += const Offset(0, 420) * dt;
      p.life -= 1.8 * dt;
    }
    particles.removeWhere((p) => p.life <= 0.0);

    for (final fruit in fruits) {
      if (!fruit.cut && fruit.y > area.height + 80) {
        fruit.fade = 0;
        if (fruit.kind != _FruitKind.bomb) {
          combo = 0;
          missed++;
          GameAudio.fruitMiss();
        }
      }
    }
    fruits.removeWhere((f) => f.fade <= 0 || f.y > area.height + 120);
    flash = math.max(0.0, flash - 2.7 * dt);
    setState(() {});
  }

  double _distanceToSegment(Offset p, Offset a, Offset b) {
    final ab = b - a;
    final len2 = ab.dx * ab.dx + ab.dy * ab.dy;
    if (len2 < 1e-6) return (p - a).distance;
    final ap = p - a;
    final t = ((ap.dx * ab.dx + ap.dy * ab.dy) / len2).clamp(0.0, 1.0);
    final q = Offset(a.dx + ab.dx * t, a.dy + ab.dy * t);
    return (p - q).distance;
  }

  void _spawnFruit({bool extra = false}) {
    if (area.width <= 100 || area.height <= 100) return;
    final bombChance = score > 500 ? 0.13 : 0.07;
    final kind = random.nextDouble() < bombChance
        ? _FruitKind.bomb
        : _FruitKind.values[random.nextInt(4)];
    final radius = 26.0 + random.nextDouble() * 10.0;
    final margin = math.min(100.0, area.width * 0.12);
    final x = margin + random.nextDouble() * math.max(1.0, area.width - margin * 2);
    final fallSpeed = 165.0 + random.nextDouble() * 155.0;
    fruits.add(
      _FruitTarget(
        x: x,
        y: -radius - (extra ? 55 : 0),
        vx: (random.nextDouble() - 0.5) * 55.0,
        vy: fallSpeed,
        radius: radius,
        kind: kind,
        spin: (random.nextDouble() - 0.5) * 3.2,
      ),
    );
  }

  void _slice(_FruitTarget fruit) {
    fruit.cut = true;
    fruit.fade = 1.0;
    final color = _fruitColor(fruit.kind);

    if (fruit.kind == _FruitKind.bomb) {
      bombsHit++;
      combo = 0;
      score = math.max(0, score - 350);
      flash = 1.0;
      GameAudio.crash();
      _addParticles(Offset(fruit.x, fruit.y), const Color(0xFFFF5B5B), 22);
      return;
    }

    sliced++;
    combo++;
    bestCombo = math.max(bestCombo, combo);
    score += 100 + math.min(400, combo * 12);
    GameAudio.fruitSlice(sliced);
    if (combo > 0 && combo % 5 == 0) {
      GameAudio.combo();
    }
    _addParticles(Offset(fruit.x, fruit.y), color, 18);
  }

  void _addParticles(Offset center, Color color, int count) {
    for (var i = 0; i < count; i++) {
      final a = random.nextDouble() * math.pi * 2;
      final speed = 60 + random.nextDouble() * 230;
      particles.add(
        _JuiceParticle(
          position: center,
          velocity: Offset(math.cos(a) * speed, math.sin(a) * speed - 80),
          color: color,
        ),
      );
    }
  }

  void _stopOrResume() {
    setState(() {
      gameStopped = !gameStopped;
    });
    if (gameStopped) {
      GameAudio.stopGame();
    } else {
      GameAudio.resume();
    }
  }

  void _restartFruit() {
    setState(() {
      fruits.clear();
      particles.clear();
      trail.clear();
      score = 0;
      combo = 0;
      bestCombo = 0;
      sliced = 0;
      bombsHit = 0;
      missed = 0;
      flash = 0.0;
      spawnClock = 0.0;
      blade = Offset(area.width > 0 ? area.width / 2 : 620, area.height > 0 ? area.height * 0.72 : 430);
      previousBlade = blade;
      phase = _FruitPhase.countdown;
      phaseStart = DateTime.now();
      gameStopped = false;
    });
  }

  Color _fruitColor(_FruitKind kind) {
    switch (kind) {
      case _FruitKind.apple:
        return const Color(0xFFFF4D6D);
      case _FruitKind.orange:
        return const Color(0xFFFFA62B);
      case _FruitKind.kiwi:
        return const Color(0xFF85D94E);
      case _FruitKind.berry:
        return const Color(0xFFA66CFF);
      case _FruitKind.bomb:
        return const Color(0xFF30323D);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          area = Size(constraints.maxWidth, constraints.maxHeight);
          if (blade.dx > area.width || blade.dy > area.height) {
            blade = Offset(area.width / 2, area.height * 0.72);
            previousBlade = blade;
          }
          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: _FruitSlicePainter(
                    fruits: fruits,
                    particles: particles,
                    blade: blade,
                    trail: trail,
                    score: score,
                    combo: combo,
                    bestCombo: bestCombo,
                    sliced: sliced,
                    bombsHit: bombsHit,
                    missed: missed,
                    flash: flash,
                  ),
                ),
              ),
              if (phase == _FruitPhase.instructions)
                const Positioned.fill(child: _FruitInstructionOverlay()),
              if (phase == _FruitPhase.countdown)
                Positioned.fill(
                  child: _GameCountdownOverlay(number: countdownNumber, title: 'FRUIT READY'),
                ),
              if (gameStopped)
                Positioned.fill(
                  child: _GameStoppedOverlay(
                    title: 'Fruit Slice',
                    onResume: () => setState(() => gameStopped = false),
                    onRestart: _restartFruit,
                    onBack: () => Navigator.of(context).pop(),
                  ),
                ),
              Positioned(
                left: 0,
                top: 0,
                child: _GameTopControls(
                  controller: widget.controller,
                  stopped: gameStopped,
                  onBack: () => Navigator.of(context).pop(),
                  onStop: _stopOrResume,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _FruitTarget {
  _FruitTarget({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.radius,
    required this.kind,
    required this.spin,
  });

  double x;
  double y;
  double vx;
  double vy;
  final double radius;
  final _FruitKind kind;
  final double spin;
  double rotation = 0.0;
  bool cut = false;
  double fade = 1.0;
}

class _JuiceParticle {
  _JuiceParticle({
    required this.position,
    required this.velocity,
    required this.color,
  });

  Offset position;
  Offset velocity;
  final Color color;
  double life = 1.0;
}

class _FruitInstructionOverlay extends StatelessWidget {
  const _FruitInstructionOverlay();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xD8080B1A),
      alignment: Alignment.center,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 900),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 42, vertical: 34),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.restaurant_rounded, color: Color(0xFFFF5D8F), size: 78),
                SizedBox(height: 8),
                Text('Fruit Slice', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
                Text(
                  'An original HelloBand slicing game',
                  style: TextStyle(color: Colors.white70, fontSize: 17),
                ),
                SizedBox(height: 26),
                Row(
                  children: [
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.swap_horiz_rounded,
                        title: 'MOVE LEFT / RIGHT',
                        subtitle: 'The blade slices automatically',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.south_rounded,
                        title: 'FRUIT FALLS DOWN',
                        subtitle: 'Track each fruit as it drops from the top',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.warning_amber_rounded,
                        title: 'AVOID BOMBS',
                        subtitle: 'Bombs reduce your score',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _FruitSlicePainter extends CustomPainter {
  _FruitSlicePainter({
    required this.fruits,
    required this.particles,
    required this.blade,
    required this.trail,
    required this.score,
    required this.combo,
    required this.bestCombo,
    required this.sliced,
    required this.bombsHit,
    required this.missed,
    required this.flash,
  });

  final List<_FruitTarget> fruits;
  final List<_JuiceParticle> particles;
  final Offset blade;
  final List<Offset> trail;
  final int score;
  final int combo;
  final int bestCombo;
  final int sliced;
  final int bombsHit;
  final int missed;
  final double flash;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF120A2A), Color(0xFF3D155F), Color(0xFF081B38)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    final glowPaint = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < 18; i++) {
      final x = (i * 97.0) % size.width;
      final y = (i * 173.0) % size.height;
      glowPaint.color = (i.isEven ? const Color(0xFFFF5D8F) : const Color(0xFF43E6C4))
          .withValues(alpha: 0.05);
      canvas.drawCircle(Offset(x, y), 40 + (i % 5) * 12, glowPaint);
    }

    for (final fruit in fruits) {
      _drawFruit(canvas, fruit);
    }
    for (final p in particles) {
      canvas.drawCircle(
        p.position,
        3.5 + p.life * 3.0,
        Paint()..color = p.color.withValues(alpha: p.life.clamp(0.0, 1.0).toDouble()),
      );
    }

    if (trail.length >= 2) {
      final path = Path()..moveTo(trail.first.dx, trail.first.dy);
      for (final p in trail.skip(1)) {
        path.lineTo(p.dx, p.dy);
      }
      final trailPaint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10
        ..strokeCap = StrokeCap.round
        ..shader = const LinearGradient(
          colors: [Color(0x00FFFFFF), Color(0xFFFFF06A), Color(0xFFFFFFFF)],
        ).createShader(Offset.zero & size);
      canvas.drawPath(path, trailPaint);
    }

    canvas.drawCircle(
      blade,
      17,
      Paint()..color = const Color(0xFFFFF06A),
    );
    canvas.drawCircle(
      blade,
      29,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = Colors.white.withValues(alpha: 0.78),
    );

    _drawFruitHud(canvas, size);

    if (flash > 0) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = const Color(0xFFFF3B4D).withValues(alpha: 0.26 * flash),
      );
    }
  }

  void _drawFruit(Canvas canvas, _FruitTarget f) {
    canvas.save();
    canvas.translate(f.x, f.y);
    canvas.rotate(f.rotation);
    final alpha = f.fade.clamp(0.0, 1.0).toDouble();

    if (f.kind == _FruitKind.bomb) {
      canvas.drawCircle(Offset.zero, f.radius, Paint()..color = const Color(0xFF272A35).withValues(alpha: alpha));
      canvas.drawCircle(Offset(-8, -8), f.radius * 0.35, Paint()..color = const Color(0xFF4B5162).withValues(alpha: alpha));
      final fuse = Paint()
        ..color = const Color(0xFFFFD166).withValues(alpha: alpha)
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(Offset(f.radius * 0.45, -f.radius * 0.62), Offset(f.radius * 0.75, -f.radius * 0.95), fuse);
      canvas.drawCircle(Offset(f.radius * 0.83, -f.radius * 1.04), 6, Paint()..color = const Color(0xFFFF5B5B));
      canvas.restore();
      return;
    }

    final color = switch (f.kind) {
      _FruitKind.apple => const Color(0xFFFF4D6D),
      _FruitKind.orange => const Color(0xFFFFA62B),
      _FruitKind.kiwi => const Color(0xFF85D94E),
      _FruitKind.berry => const Color(0xFFA66CFF),
      _FruitKind.bomb => const Color(0xFF30323D),
    };

    final body = Paint()..color = color.withValues(alpha: alpha);
    if (f.cut) {
      final left = Rect.fromCircle(center: Offset(-f.radius * 0.28, 0), radius: f.radius * 0.76);
      final right = Rect.fromCircle(center: Offset(f.radius * 0.28, 0), radius: f.radius * 0.76);
      canvas.drawArc(left, math.pi / 2, math.pi, true, body);
      canvas.drawArc(right, -math.pi / 2, math.pi, true, body);
    } else {
      canvas.drawCircle(Offset.zero, f.radius, body);
      canvas.drawCircle(
        Offset(-f.radius * 0.30, -f.radius * 0.34),
        f.radius * 0.17,
        Paint()..color = Colors.white.withValues(alpha: 0.33 * alpha),
      );
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(f.radius * 0.28, -f.radius * 0.85),
          width: f.radius * 0.55,
          height: f.radius * 0.27,
        ),
        Paint()..color = const Color(0xFF35B76E).withValues(alpha: alpha),
      );
    }
    canvas.restore();
  }

  void _drawFruitHud(Canvas canvas, Size size) {
    final panel = RRect.fromRectAndRadius(
      Rect.fromLTWH(size.width - 520, 18, 495, 66),
      const Radius.circular(20),
    );
    canvas.drawRRect(panel, Paint()..color = const Color(0xD90C1430));
    final tp = TextPainter(textDirection: TextDirection.ltr);
    tp.text = TextSpan(
      text: 'SCORE $score    COMBO x$combo    BEST x$bestCombo    CUT $sliced    MISSED $missed    BOMBS $bombsHit',
      style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900),
    );
    tp.layout(maxWidth: 470);
    tp.paint(canvas, Offset(size.width - 505, 42));
  }

  @override
  bool shouldRepaint(covariant _FruitSlicePainter oldDelegate) => true;
}

class _GameCountdownOverlay extends StatelessWidget {
  const _GameCountdownOverlay({required this.number, required this.title});
  final int number;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0x99040A14),
      alignment: Alignment.center,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
                const SizedBox(height: 14),
                Text(
                  '$number',
                  style: const TextStyle(
                    color: Color(0xFFFFE45E),
                    fontSize: 110,
                    height: 0.9,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

enum _MazePhase { instructions, countdown, playing, won }

class MazeMunchScreen extends StatefulWidget {
  const MazeMunchScreen({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  State<MazeMunchScreen> createState() => _MazeMunchScreenState();
}

class _MazeMunchScreenState extends State<MazeMunchScreen> {
  static const List<String> _map = <String>[
    '###################',
    '#S....#.....#....K#',
    '#.##.#.###.#.##...#',
    '#....#.....#..#.#.#',
    '###.#####.###.#.#.#',
    '#...#...#.....#...#',
    '#.###.#.#####.###.#',
    '#.....#...K...#...#',
    '#.#####.#####.#.#.#',
    '#...#.....#...#.#.#',
    '###.#.###.#.###.#.#',
    '#K..#...#.#.....#.#',
    '#.#####.#.#####...#',
    '#...............#E#',
    '###################',
  ];

  final math.Random random = math.Random();
  Timer? timer;
  _MazePhase phase = _MazePhase.instructions;
  DateTime phaseStart = DateTime.now();
  late math.Point<int> player;
  late math.Point<int> start;
  late math.Point<int> exit;
  final List<math.Point<int>> chasers = <math.Point<int>>[];
  final Set<math.Point<int>> pellets = <math.Point<int>>{};
  final Set<math.Point<int>> keys = <math.Point<int>>{};
  int collectedKeys = 0;
  int score = 0;
  int lives = 3;
  double moveCooldown = 0.0;
  double chaserClock = 0.0;
  double powerTimer = 0.0;
  double powerCooldown = 0.0;
  bool lastContraction = false;
  double intentX = 0.0;
  double intentY = 0.0;
  double hitFlash = 0.0;
  bool gameStopped = false;

  @override
  void initState() {
    super.initState();
    _loadMaze();
    phaseStart = DateTime.now();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  int get countdownNumber {
    final elapsed = DateTime.now().difference(phaseStart).inMilliseconds;
    return math.max(1, 3 - (elapsed ~/ 1000));
  }

  void _loadMaze() {
    pellets.clear();
    keys.clear();
    chasers.clear();
    for (var y = 0; y < _map.length; y++) {
      for (var x = 0; x < _map[y].length; x++) {
        final c = _map[y][x];
        final p = math.Point<int>(x, y);
        if (c == 'S') {
          start = p;
          player = p;
        } else if (c == 'E') {
          exit = p;
        } else if (c == 'K') {
          keys.add(p);
        } else if (c == '.') {
          pellets.add(p);
        }
      }
    }
    chasers
      ..add(const math.Point<int>(9, 3))
      ..add(const math.Point<int>(15, 7))
      ..add(const math.Point<int>(7, 11));
  }

  void _tick() {
    if (!mounted) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    const dt = 0.016;
    final now = DateTime.now();
    final elapsed = now.difference(phaseStart);
    final delta = widget.controller.consumeCursorDelta();

    if (gameStopped) {
      return;
    }

    if (phase == _MazePhase.instructions) {
      if (elapsed >= const Duration(seconds: 5)) {
        phase = _MazePhase.countdown;
        phaseStart = now;
      }
      setState(() {});
      return;
    }
    if (phase == _MazePhase.countdown) {
      if (elapsed >= const Duration(seconds: 3)) {
        phase = _MazePhase.playing;
        phaseStart = now;
        GameAudio.start();
      }
      setState(() {});
      return;
    }
    if (phase == _MazePhase.won) {
      if (elapsed >= const Duration(seconds: 3)) {
        collectedKeys = 0;
        score += 500;
        lives = 3;
        _loadMaze();
        phase = _MazePhase.playing;
        phaseStart = now;
      }
      setState(() {});
      return;
    }

    moveCooldown = math.max(0.0, moveCooldown - dt);
    chaserClock += dt;
    powerTimer = math.max(0.0, powerTimer - dt);
    powerCooldown = math.max(0.0, powerCooldown - dt);
    hitFlash = math.max(0.0, hitFlash - 2.5 * dt);

    intentX = intentX * 0.52 + delta[0];
    intentY = intentY * 0.52 + delta[1];

    if (moveCooldown <= 0.0) {
      final ax = intentX.abs();
      final ay = intentY.abs();
      if (math.max(ax, ay) > 7.0) {
        math.Point<int> direction;
        if (ax > ay) {
          direction = math.Point<int>(intentX > 0 ? 1 : -1, 0);
        } else {
          direction = math.Point<int>(0, intentY > 0 ? 1 : -1);
        }
        _tryMove(direction);
        moveCooldown = 0.115;
        intentX = 0.0;
        intentY = 0.0;
      }
    }

    final contraction = widget.controller.contraction;
    if (contraction && !lastContraction && powerCooldown <= 0.0) {
      powerTimer = 1.55;
      powerCooldown = 3.2;
      score += 35;
      GameAudio.power();
    }
    lastContraction = contraction;

    if (chaserClock >= (powerTimer > 0 ? 0.70 : 0.34)) {
      chaserClock = 0.0;
      _moveChasers();
      _checkChaserCollision();
    }

    setState(() {});
  }

  bool _walkable(math.Point<int> p) {
    if (p.y < 0 || p.y >= _map.length || p.x < 0 || p.x >= _map[0].length) return false;
    return _map[p.y][p.x] != '#';
  }

  void _tryMove(math.Point<int> d) {
    final next = math.Point<int>(player.x + d.x, player.y + d.y);
    if (!_walkable(next)) {
      GameAudio.mazeBump();
      return;
    }
    player = next;

    if (pellets.remove(player)) {
      score += 10;
      GameAudio.mazeEat();
    }
    if (keys.remove(player)) {
      collectedKeys++;
      score += 180;
      GameAudio.mazeKey();
    }
    if (player == exit && collectedKeys >= 3) {
      score += 1000;
      phase = _MazePhase.won;
      phaseStart = DateTime.now();
      GameAudio.win();
      return;
    }
    _checkChaserCollision();
  }

  void _moveChasers() {
    if (powerTimer > 0) return;
    for (var i = 0; i < chasers.length; i++) {
      final current = chasers[i];
      final candidates = <math.Point<int>>[
        math.Point<int>(current.x + 1, current.y),
        math.Point<int>(current.x - 1, current.y),
        math.Point<int>(current.x, current.y + 1),
        math.Point<int>(current.x, current.y - 1),
      ].where(_walkable).toList();
      if (candidates.isEmpty) continue;
      candidates.sort((a, b) {
        final da = (a.x - player.x).abs() + (a.y - player.y).abs();
        final db = (b.x - player.x).abs() + (b.y - player.y).abs();
        return da.compareTo(db);
      });
      if (random.nextDouble() < 0.72) {
        chasers[i] = candidates.first;
      } else {
        chasers[i] = candidates[random.nextInt(candidates.length)];
      }
    }
  }

  void _checkChaserCollision() {
    if (powerTimer > 0) return;
    if (!chasers.contains(player)) return;
    lives--;
    score = math.max(0, score - 250);
    hitFlash = 1.0;
    player = start;
    GameAudio.crash();
    if (lives <= 0) {
      lives = 3;
      collectedKeys = 0;
      score = math.max(0, score - 300);
      _loadMaze();
    }
  }

  void _stopOrResume() {
    setState(() {
      gameStopped = !gameStopped;
    });
    if (gameStopped) {
      GameAudio.stopGame();
    } else {
      GameAudio.resume();
    }
  }

  void _restartMaze() {
    setState(() {
      collectedKeys = 0;
      score = 0;
      lives = 3;
      moveCooldown = 0.0;
      chaserClock = 0.0;
      powerTimer = 0.0;
      powerCooldown = 0.0;
      lastContraction = false;
      intentX = 0.0;
      intentY = 0.0;
      hitFlash = 0.0;
      _loadMaze();
      phase = _MazePhase.countdown;
      phaseStart = DateTime.now();
      gameStopped = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: CustomPaint(
              painter: _MazeMunchPainter(
                map: _map,
                player: player,
                exit: exit,
                pellets: pellets,
                keys: keys,
                chasers: chasers,
                collectedKeys: collectedKeys,
                score: score,
                lives: lives,
                powerTimer: powerTimer,
                powerCooldown: powerCooldown,
                contractionPercent: widget.controller.contractionPercent,
                hitFlash: hitFlash,
              ),
            ),
          ),
          if (phase == _MazePhase.instructions)
            const Positioned.fill(child: _MazeInstructionOverlay()),
          if (phase == _MazePhase.countdown)
            Positioned.fill(
              child: _GameCountdownOverlay(number: countdownNumber, title: 'MAZE READY'),
            ),
          if (phase == _MazePhase.won)
            Positioned.fill(
              child: Container(
                color: const Color(0xB0081022),
                alignment: Alignment.center,
                child: const Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.emoji_events_rounded, color: Color(0xFFFFE45E), size: 92),
                    SizedBox(height: 12),
                    Text('MAZE CLEARED!', style: TextStyle(fontSize: 48, fontWeight: FontWeight.w900)),
                    SizedBox(height: 8),
                    Text('All 3 keys unlocked the exit', style: TextStyle(color: Colors.white70, fontSize: 18)),
                  ],
                ),
              ),
            ),
          if (gameStopped)
            Positioned.fill(
              child: _GameStoppedOverlay(
                title: 'Maze Munch',
                onResume: () => setState(() => gameStopped = false),
                onRestart: _restartMaze,
                onBack: () => Navigator.of(context).pop(),
              ),
            ),
          Positioned(
            left: 0,
            top: 0,
            child: _GameTopControls(
              controller: widget.controller,
              stopped: gameStopped,
              onBack: () => Navigator.of(context).pop(),
              onStop: _stopOrResume,
            ),
          ),
        ],
      ),
    );
  }
}

class _MazeInstructionOverlay extends StatelessWidget {
  const _MazeInstructionOverlay();

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xD9071020),
      alignment: Alignment.center,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 980),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.grid_4x4_rounded, color: Color(0xFFFFE45E), size: 76),
                SizedBox(height: 8),
                Text('Maze Munch', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
                Text(
                  'An original neon maze puzzle for HelloBand',
                  style: TextStyle(color: Colors.white70, fontSize: 17),
                ),
                SizedBox(height: 26),
                Row(
                  children: [
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.open_with_rounded,
                        title: 'MOVE',
                        subtitle: 'Navigate the maze',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.circle_rounded,
                        title: 'EAT DOTS',
                        subtitle: 'Dots increase score',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.key_rounded,
                        title: '3 KEYS',
                        subtitle: 'Unlock the green exit',
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _ControlHint(
                        icon: Icons.bolt_rounded,
                        title: 'CONTRACT',
                        subtitle: 'Pulse freezes chasers',
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MazeMunchPainter extends CustomPainter {
  _MazeMunchPainter({
    required this.map,
    required this.player,
    required this.exit,
    required this.pellets,
    required this.keys,
    required this.chasers,
    required this.collectedKeys,
    required this.score,
    required this.lives,
    required this.powerTimer,
    required this.powerCooldown,
    required this.contractionPercent,
    required this.hitFlash,
  });

  final List<String> map;
  final math.Point<int> player;
  final math.Point<int> exit;
  final Set<math.Point<int>> pellets;
  final Set<math.Point<int>> keys;
  final List<math.Point<int>> chasers;
  final int collectedKeys;
  final int score;
  final int lives;
  final double powerTimer;
  final double powerCooldown;
  final double contractionPercent;
  final double hitFlash;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF050817), Color(0xFF071C31), Color(0xFF180A31)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    final cols = map[0].length;
    final rows = map.length;
    final cell = math.min((size.width - 54) / cols, (size.height - 150) / rows);
    final mazeW = cell * cols;
    final mazeH = cell * rows;
    final origin = Offset((size.width - mazeW) / 2, 112 + math.max(0.0, (size.height - 112 - mazeH) / 2));

    final wallPaint = Paint()..color = const Color(0xFF163B83);
    final wallGlow = Paint()
      ..color = const Color(0xFF3B7CFF).withValues(alpha: 0.20)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);

    for (var y = 0; y < rows; y++) {
      for (var x = 0; x < cols; x++) {
        final rect = Rect.fromLTWH(origin.dx + x * cell, origin.dy + y * cell, cell, cell);
        final c = map[y][x];
        if (c == '#') {
          final r = RRect.fromRectAndRadius(rect.deflate(cell * 0.08), Radius.circular(cell * 0.18));
          canvas.drawRRect(r, wallGlow);
          canvas.drawRRect(r, wallPaint);
        }
      }
    }

    for (final p in pellets) {
      final center = Offset(origin.dx + (p.x + 0.5) * cell, origin.dy + (p.y + 0.5) * cell);
      canvas.drawCircle(center, cell * 0.09, Paint()..color = const Color(0xFFFFE98A));
    }

    for (final p in keys) {
      final center = Offset(origin.dx + (p.x + 0.5) * cell, origin.dy + (p.y + 0.5) * cell);
      final keyPaint = Paint()..color = const Color(0xFFFFD84D);
      canvas.drawCircle(center + Offset(-cell * 0.10, 0), cell * 0.12, keyPaint);
      canvas.drawRect(
        Rect.fromCenter(center: center + Offset(cell * 0.08, 0), width: cell * 0.28, height: cell * 0.08),
        keyPaint,
      );
    }

    final exitCenter = Offset(origin.dx + (exit.x + 0.5) * cell, origin.dy + (exit.y + 0.5) * cell);
    final open = collectedKeys >= 3;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: exitCenter, width: cell * 0.70, height: cell * 0.78),
        Radius.circular(cell * 0.12),
      ),
      Paint()..color = open ? const Color(0xFF2DD881) : const Color(0xFF5A6075),
    );
    final exitTp = TextPainter(textDirection: TextDirection.ltr)
      ..text = TextSpan(
        text: open ? 'EXIT' : 'LOCK',
        style: TextStyle(color: Colors.white, fontSize: cell * 0.18, fontWeight: FontWeight.w900),
      )
      ..layout();
    exitTp.paint(canvas, exitCenter - Offset(exitTp.width / 2, exitTp.height / 2));

    for (var i = 0; i < chasers.length; i++) {
      final p = chasers[i];
      final center = Offset(origin.dx + (p.x + 0.5) * cell, origin.dy + (p.y + 0.5) * cell);
      _drawChaser(canvas, center, cell * 0.34, i, powerTimer > 0);
    }

    final playerCenter = Offset(origin.dx + (player.x + 0.5) * cell, origin.dy + (player.y + 0.5) * cell);
    if (powerTimer > 0) {
      canvas.drawCircle(
        playerCenter,
        cell * (0.48 + 0.08 * math.sin(powerTimer * 12)),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4
          ..color = const Color(0xFF43E6C4).withValues(alpha: 0.72),
      );
    }
    _drawMuncher(canvas, playerCenter, cell * 0.31);

    _drawMazeHud(canvas, size);

    if (hitFlash > 0) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = const Color(0xFFFF3B4D).withValues(alpha: 0.28 * hitFlash),
      );
    }
  }

  void _drawMuncher(Canvas canvas, Offset center, double r) {
    final body = Paint()..color = const Color(0xFF43E6C4);
    canvas.drawCircle(center, r, body);
    final mouth = Path()
      ..moveTo(center.dx, center.dy)
      ..lineTo(center.dx + r * 1.05, center.dy - r * 0.42)
      ..lineTo(center.dx + r * 1.05, center.dy + r * 0.42)
      ..close();
    canvas.drawPath(mouth, Paint()..color = const Color(0xFF07101F));
    canvas.drawCircle(center + Offset(-r * 0.15, -r * 0.42), r * 0.13, Paint()..color = Colors.white);
  }

  void _drawChaser(Canvas canvas, Offset center, double r, int index, bool frozen) {
    final colors = <Color>[
      const Color(0xFFFF5D8F),
      const Color(0xFFFFA62B),
      const Color(0xFFA66CFF),
    ];
    final color = frozen ? const Color(0xFF7DDCFF) : colors[index % colors.length];
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: center, width: r * 1.9, height: r * 1.65),
        Radius.circular(r * 0.38),
      ),
      Paint()..color = color,
    );
    canvas.drawCircle(center + Offset(-r * 0.35, -r * 0.15), r * 0.18, Paint()..color = Colors.white);
    canvas.drawCircle(center + Offset(r * 0.35, -r * 0.15), r * 0.18, Paint()..color = Colors.white);
    canvas.drawCircle(center + Offset(-r * 0.30, -r * 0.12), r * 0.08, Paint()..color = const Color(0xFF182039));
    canvas.drawCircle(center + Offset(r * 0.40, -r * 0.12), r * 0.08, Paint()..color = const Color(0xFF182039));
  }

  void _drawMazeHud(Canvas canvas, Size size) {
    final panel = RRect.fromRectAndRadius(
      Rect.fromLTWH(size.width / 2 - 300, 18, 600, 72),
      const Radius.circular(22),
    );
    canvas.drawRRect(panel, Paint()..color = const Color(0xD9111B2B));
    final powerText = powerTimer > 0
        ? 'POWER ON'
        : powerCooldown > 0
            ? 'POWER ${powerCooldown.toStringAsFixed(1)}s'
            : 'CONTRACT = POWER';
    final tp = TextPainter(textDirection: TextDirection.ltr)
      ..text = TextSpan(
        text: 'SCORE $score     KEYS $collectedKeys/3     LIVES $lives     $powerText     EMG ${contractionPercent.toStringAsFixed(0)}%',
        style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900),
      )
      ..layout(maxWidth: 570);
    tp.paint(canvas, Offset(size.width / 2 - tp.width / 2, 45));
  }

  @override
  bool shouldRepaint(covariant _MazeMunchPainter oldDelegate) => true;
}

enum _DinoPhase { instructions, countdown, running }

class DinoJumpScreen extends StatefulWidget {
  const DinoJumpScreen({super.key, required this.controller});

  final HelloBandController controller;

  @override
  State<DinoJumpScreen> createState() => _DinoJumpScreenState();
}

class _DinoJumpScreenState extends State<DinoJumpScreen> {
  final math.Random random = math.Random();
  final List<_DinoObstacle> obstacles = <_DinoObstacle>[];
  Timer? timer;
  _DinoPhase phase = _DinoPhase.instructions;
  DateTime phaseStart = DateTime.now();
  bool gameStopped = false;
  bool lastContraction = false;
  double verticalIntent = 0.0;
  double jumpHeight = 0.0;
  double jumpVelocity = 0.0;
  double groundScroll = 0.0;
  double spawnClock = 0.0;
  double distance = 0.0;
  double speed = 1.0;
  int score = 0;
  int best = 0;
  double collisionFlash = 0.0;

  bool get jumping => jumpHeight > 0.01 || jumpVelocity.abs() > 0.01;

  @override
  void initState() {
    super.initState();
    phaseStart = DateTime.now();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  int get countdownNumber {
    final ms = DateTime.now().difference(phaseStart).inMilliseconds;
    return math.max(1, 3 - (ms ~/ 1000));
  }

  void _jump() {
    if (jumping) return;
    jumpVelocity = 2.85;
    GameAudio.jump();
  }

  void _tick() {
    if (!mounted || ModalRoute.of(context)?.isCurrent != true) return;
    const dt = 0.016;
    final now = DateTime.now();
    final elapsed = now.difference(phaseStart);

    if (gameStopped) {
      widget.controller.consumeCursorDelta();
      return;
    }

    if (phase == _DinoPhase.instructions) {
      widget.controller.consumeCursorDelta();
      if (elapsed >= const Duration(seconds: 5)) {
        phase = _DinoPhase.countdown;
        phaseStart = now;
      }
      setState(() {});
      return;
    }

    if (phase == _DinoPhase.countdown) {
      widget.controller.consumeCursorDelta();
      if (elapsed >= const Duration(seconds: 3)) {
        phase = _DinoPhase.running;
        phaseStart = now;
        GameAudio.start();
      }
      setState(() {});
      return;
    }

    final delta = widget.controller.consumeCursorDelta();
    verticalIntent = verticalIntent * 0.65 + delta[1];
    final contraction = widget.controller.contraction;

    if (verticalIntent < -8.0) {
      verticalIntent = 0.0;
      _jump();
    }
    if (contraction && !lastContraction) {
      _jump();
    }
    lastContraction = contraction;

    if (jumping) {
      jumpHeight += jumpVelocity * dt;
      jumpVelocity -= 5.9 * dt;
      if (jumpHeight <= 0.0 && jumpVelocity < 0.0) {
        jumpHeight = 0.0;
        jumpVelocity = 0.0;
      }
    }

    speed = math.min(1.85, 1.0 + distance / 950.0);
    groundScroll = (groundScroll + dt * speed * 0.9) % 1.0;
    distance += dt * 11.0 * speed;
    score += (dt * 22.0 * speed).round();
    best = math.max(best, score);
    collisionFlash = math.max(0.0, collisionFlash - dt * 2.5);

    spawnClock -= dt;
    if (spawnClock <= 0.0) {
      spawnClock = math.max(0.72, 1.55 - speed * 0.28) + random.nextDouble() * 0.55;
      obstacles.add(
        _DinoObstacle(
          x: 1.16,
          kind: random.nextDouble() < 0.62 ? _DinoObstacleKind.cactus : _DinoObstacleKind.rock,
        ),
      );
    }

    for (final o in obstacles) {
      o.x -= dt * (0.38 + speed * 0.20);
      if (!o.counted && o.x < 0.17) {
        o.counted = true;
        score += 35;
        GameAudio.collect();
      }
      if (!o.hit && o.x > 0.115 && o.x < 0.235 && jumpHeight < 0.38) {
        o.hit = true;
        score = math.max(0, score - 180);
        collisionFlash = 1.0;
        speed = math.max(1.0, speed - 0.25);
        GameAudio.crash();
      }
    }
    obstacles.removeWhere((o) => o.x < -0.12);

    setState(() {});
  }

  void _restart() {
    setState(() {
      phase = _DinoPhase.countdown;
      phaseStart = DateTime.now();
      gameStopped = false;
      lastContraction = false;
      verticalIntent = 0.0;
      jumpHeight = 0.0;
      jumpVelocity = 0.0;
      groundScroll = 0.0;
      spawnClock = 0.8;
      distance = 0.0;
      speed = 1.0;
      score = 0;
      collisionFlash = 0.0;
      obstacles.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          return Stack(
            fit: StackFit.expand,
            children: [
              RepaintBoundary(
                child: CustomPaint(
                  painter: _DinoJumpPainter(
                    groundScroll: groundScroll,
                    jumpHeight: jumpHeight,
                    obstacles: obstacles,
                    score: score,
                    best: best,
                    distance: distance,
                    speed: speed,
                    collisionFlash: collisionFlash,
                  ),
                ),
              ),
              Positioned(
                left: 0,
                right: 0,
                top: 16,
                child: IgnorePointer(
                  child: SafeArea(
                    child: Center(
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: 640),
                        margin: const EdgeInsets.symmetric(horizontal: 210),
                        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                        decoration: BoxDecoration(
                          color: const Color(0xC9142B1A),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: const Color(0x8864E572)),
                        ),
                        child: Text(
                          phase == _DinoPhase.running
                              ? 'MOVE UP or CONTRACT = JUMP  •  Avoid cactus and rocks'
                              : 'Dino Jump',
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                          style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFB7FF9C)),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              _GameTopControls(
                stopped: gameStopped,
                onBack: () => Navigator.pop(context),
                onStop: () {
                  setState(() => gameStopped = !gameStopped);
                  if (gameStopped) {
                    GameAudio.stopGame();
                  } else {
                    GameAudio.resume();
                  }
                },
              ),
              if (phase == _DinoPhase.instructions)
                _DinoInstructionOverlay(onStart: () {
                  setState(() {
                    phase = _DinoPhase.countdown;
                    phaseStart = DateTime.now();
                  });
                }),
              if (phase == _DinoPhase.countdown)
                _GameCountdownOverlay(number: countdownNumber, title: 'DINO READY'),
              if (gameStopped)
                _GameStoppedOverlay(
                  title: 'Dino Jump',
                  onResume: () => setState(() => gameStopped = false),
                  onRestart: _restart,
                  onBack: () => Navigator.pop(context),
                ),
            ],
          );
        },
      ),
    );
  }
}

enum _DinoObstacleKind { cactus, rock }

class _DinoObstacle {
  _DinoObstacle({required this.x, required this.kind});
  double x;
  final _DinoObstacleKind kind;
  bool hit = false;
  bool counted = false;
}

class _DinoInstructionOverlay extends StatelessWidget {
  const _DinoInstructionOverlay({required this.onStart});
  final VoidCallback onStart;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xD9081510),
      alignment: Alignment.center,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 680),
              child: Card(
                color: const Color(0xFF0F2418),
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                  side: const BorderSide(color: Color(0xFF2C5A38), width: 1.2),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 26),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.pets_rounded, color: Color(0xFF64E572), size: 72),
                      const SizedBox(height: 10),
                      const Text(
                        'Dino Jump',
                        style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, color: Colors.white),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Help the green dinosaur run as far as possible.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white70, fontSize: 16),
                      ),
                      const SizedBox(height: 18),
                      const Wrap(
                        alignment: WrapAlignment.center,
                        spacing: 18,
                        runSpacing: 10,
                        children: [
                          _DinoHelpChip(icon: Icons.arrow_upward_rounded, text: 'MOVE UP = JUMP'),
                          _DinoHelpChip(icon: Icons.bolt_rounded, text: 'CONTRACT = JUMP'),
                          _DinoHelpChip(icon: Icons.warning_amber_rounded, text: 'AVOID OBSTACLES'),
                        ],
                      ),
                      const SizedBox(height: 22),
                      FilledButton.icon(
                        onPressed: onStart,
                        icon: const Icon(Icons.play_arrow_rounded),
                        label: const Text('Start Game'),
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF64E572),
                          foregroundColor: const Color(0xFF0B1B10),
                          textStyle: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _DinoHelpChip extends StatelessWidget {
  const _DinoHelpChip({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF17311C),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0x5564E572)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: const Color(0xFF64E572), size: 21),
          const SizedBox(width: 7),
          Text(text, style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.white)),
        ],
      ),
    );
  }
}

class _DinoJumpPainter extends CustomPainter {
  _DinoJumpPainter({
    required this.groundScroll,
    required this.jumpHeight,
    required this.obstacles,
    required this.score,
    required this.best,
    required this.distance,
    required this.speed,
    required this.collisionFlash,
  });

  final double groundScroll;
  final double jumpHeight;
  final List<_DinoObstacle> obstacles;
  final int score;
  final int best;
  final double distance;
  final double speed;
  final double collisionFlash;

  @override
  void paint(Canvas canvas, Size size) {
    final sky = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFFBEEBFF), Color(0xFFF3FFD7)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, sky);

    final groundY = size.height * 0.77;
    canvas.drawRect(
      Rect.fromLTWH(0, groundY, size.width, size.height - groundY),
      Paint()..color = const Color(0xFFE6D49A),
    );
    canvas.drawRect(
      Rect.fromLTWH(0, groundY - 7, size.width, 7),
      Paint()..color = const Color(0xFF5EA64D),
    );

    // Scrolling ground marks.
    final markGap = math.max(55.0, size.width / 18);
    final offset = (groundScroll * markGap) % markGap;
    for (double x = -markGap + offset; x < size.width + markGap; x += markGap) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(x, groundY + 36, markGap * 0.45, 5), const Radius.circular(3)),
        Paint()..color = const Color(0xFFB9A873),
      );
    }

    // Clouds / distant hills.
    final hillPaint = Paint()..color = const Color(0x5574C56A);
    for (int i = 0; i < 7; i++) {
      final x = i * size.width / 6 - 40;
      canvas.drawCircle(Offset(x, groundY - 28), 72 + (i % 2) * 18, hillPaint);
    }

    // Player green dinosaur.
    final playerX = size.width * 0.18;
    final jumpPx = jumpHeight * math.min(145.0, size.height * 0.19);
    final playerY = groundY - 54 - jumpPx;
    _drawDino(canvas, Offset(playerX, playerY), math.min(66.0, size.height * 0.09));

    for (final o in obstacles) {
      final x = o.x * size.width;
      if (o.kind == _DinoObstacleKind.cactus) {
        _drawCactus(canvas, Offset(x, groundY - 39), 42);
      } else {
        _drawRock(canvas, Offset(x, groundY - 20), 48);
      }
    }

    _hud(canvas, const Offset(26, 92), 'SCORE', '$score');
    _hud(canvas, Offset(size.width - 216, 92), 'BEST', '$best');
    _hud(canvas, const Offset(26, 166), 'DIST', '${distance.toStringAsFixed(0)} m');
    _hud(canvas, Offset(size.width - 216, 166), 'PACE', '${(speed * 100).round()}%');

    if (collisionFlash > 0) {
      canvas.drawRect(Offset.zero & size, Paint()..color = Color.fromRGBO(255, 70, 70, collisionFlash * 0.22));
    }
  }

  void _drawDino(Canvas c, Offset p, double s) {
    final green = Paint()..color = const Color(0xFF4DCB62);
    final dark = Paint()..color = const Color(0xFF22883B);
    final white = Paint()..color = Colors.white;
    final black = Paint()..color = const Color(0xFF18301D);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: p, width: s * 1.15, height: s * 0.85), Radius.circular(s * 0.22)), green);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(p.dx + s * 0.25, p.dy - s * 0.66, s * 0.72, s * 0.52), Radius.circular(s * 0.16)), green);
    c.drawPath(
      Path()..moveTo(p.dx - s * 0.52, p.dy - s * 0.10)..lineTo(p.dx - s * 1.0, p.dy - s * 0.38)..lineTo(p.dx - s * 0.66, p.dy + s * 0.18)..close(),
      dark,
    );
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(p.dx - s * 0.38, p.dy + s * 0.28, s * 0.22, s * 0.55), Radius.circular(s * 0.08)), dark);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(p.dx + s * 0.12, p.dy + s * 0.28, s * 0.22, s * 0.55), Radius.circular(s * 0.08)), dark);
    c.drawCircle(Offset(p.dx + s * 0.70, p.dy - s * 0.47), s * 0.10, white);
    c.drawCircle(Offset(p.dx + s * 0.73, p.dy - s * 0.47), s * 0.045, black);
    c.drawRect(Rect.fromLTWH(p.dx + s * 0.63, p.dy - s * 0.25, s * 0.25, s * 0.035), black);
  }

  void _drawCactus(Canvas c, Offset p, double s) {
    final paint = Paint()..color = const Color(0xFF2FA64A);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: p, width: s * 0.34, height: s * 1.45), Radius.circular(s * 0.12)), paint);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(p.dx - s * 0.52, p.dy - s * 0.10, s * 0.45, s * 0.24), Radius.circular(s * 0.10)), paint);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(p.dx + s * 0.08, p.dy - s * 0.38, s * 0.45, s * 0.24), Radius.circular(s * 0.10)), paint);
  }

  void _drawRock(Canvas c, Offset p, double s) {
    c.drawOval(Rect.fromCenter(center: p, width: s, height: s * 0.62), Paint()..color = const Color(0xFF7B6D62));
    c.drawOval(Rect.fromCenter(center: p + Offset(-s * 0.12, -s * 0.10), width: s * 0.43, height: s * 0.22), Paint()..color = const Color(0xFFA99A8E));
  }

  void _hud(Canvas canvas, Offset pos, String label, String value) {
    final width = 190.0;
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(pos.dx, pos.dy, width, 60), const Radius.circular(14)),
      Paint()..color = const Color(0xCC18311E),
    );
    final tp = TextPainter(
      text: TextSpan(
        children: [
          TextSpan(text: '$label\n', style: const TextStyle(color: Color(0xFFA5DCA8), fontSize: 11, fontWeight: FontWeight.w800)),
          TextSpan(text: value, style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
        ],
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: width - 22);
    tp.paint(canvas, pos + const Offset(12, 8));
  }

  @override
  bool shouldRepaint(covariant _DinoJumpPainter oldDelegate) => true;
}


// ============================================================
// V0.5.0 EXTRA GAMES
// Balloon Pop, Word Balloons, Color Match
// ============================================================

class _ArcadeInstructionOverlay extends StatelessWidget {
  const _ArcadeInstructionOverlay({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.lines,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final List<String> lines;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xD9081020),
      alignment: Alignment.center,
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 86, 18, 24),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 660),
              child: Card(
                color: const Color(0xFF0F1B33),
                elevation: 8,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                  side: BorderSide(color: accent.withValues(alpha: 0.45), width: 1.2),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 28),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(icon, size: 70, color: accent),
                      const SizedBox(height: 10),
                      Text(
                        title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Colors.white),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        subtitle,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.white70, fontSize: 16),
                      ),
                      const SizedBox(height: 22),
                      for (final line in lines)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(Icons.check_circle_rounded, color: accent, size: 22),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  line,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      const SizedBox(height: 16),
                      const Text(
                        'Game starts automatically after this instruction screen.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white54, fontSize: 13),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

enum _BalloonPhase { instructions, countdown, playing }

enum _BalloonKind { normal, gold, hazard }

class BalloonPopScreen extends StatefulWidget {
  const BalloonPopScreen({super.key, required this.controller});
  final HelloBandController controller;

  @override
  State<BalloonPopScreen> createState() => _BalloonPopScreenState();
}

class _BalloonPopScreenState extends State<BalloonPopScreen> {
  final math.Random random = math.Random();
  Timer? timer;
  _BalloonPhase phase = _BalloonPhase.instructions;
  DateTime phaseStart = DateTime.now();
  Size area = Size.zero;
  Offset cursor = const Offset(600, 430);
  final List<_PopBalloon> balloons = <_PopBalloon>[];
  final List<_PopBurst> bursts = <_PopBurst>[];
  double spawnClock = 0.0;
  int score = 0;
  int popped = 0;
  int combo = 0;
  int bestCombo = 0;
  bool gameStopped = false;

  @override
  void initState() {
    super.initState();
    phaseStart = DateTime.now();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  int get countdownNumber {
    final elapsed = DateTime.now().difference(phaseStart).inMilliseconds;
    return math.max(1, 3 - (elapsed ~/ 1000));
  }

  void _tick() {
    if (!mounted || area == Size.zero) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    const dt = 0.016;
    final now = DateTime.now();
    final elapsed = now.difference(phaseStart);
    final delta = widget.controller.consumeCursorDelta();

    cursor = Offset(
      (cursor.dx + delta[0]).clamp(16.0, area.width - 16.0),
      (cursor.dy + delta[1]).clamp(12.0, area.height - 16.0),
    );

    if (gameStopped) return;

    if (phase == _BalloonPhase.instructions) {
      if (elapsed >= const Duration(seconds: 5)) {
        phase = _BalloonPhase.countdown;
        phaseStart = now;
      }
      setState(() {});
      return;
    }
    if (phase == _BalloonPhase.countdown) {
      if (elapsed >= const Duration(seconds: 3)) {
        phase = _BalloonPhase.playing;
        phaseStart = now;
        GameAudio.start();
      }
      setState(() {});
      return;
    }

    spawnClock += dt;
    final interval = (0.72 - score / 28000.0).clamp(0.36, 0.72);
    if (spawnClock >= interval) {
      spawnClock = 0.0;
      _spawnBalloon();
    }

    for (final b in balloons) {
      b.x += b.vx * dt;
      b.y -= b.speed * dt;
      b.phase += dt * 2.0;
      b.x += math.sin(b.phase) * 8.0 * dt;
    }

    for (final b in balloons) {
      if (b.popped) continue;
      if ((Offset(b.x, b.y) - cursor).distance <= b.radius + 13.0) {
        _pop(b);
      }
    }

    for (final burst in bursts) {
      burst.life -= 2.3 * dt;
      burst.radius += 70 * dt;
    }
    bursts.removeWhere((e) => e.life <= 0);

    for (final b in balloons) {
      if (!b.popped && b.y < -80) {
        b.popped = true;
        if (b.kind == _BalloonKind.normal || b.kind == _BalloonKind.gold) {
          combo = 0;
        }
      }
    }
    balloons.removeWhere((b) => b.popped && b.y < -120);
    balloons.removeWhere((b) => b.y < -130);
    setState(() {});
  }

  void _spawnBalloon() {
    if (area.width < 120 || area.height < 120) return;
    final roll = random.nextDouble();
    final kind = roll < 0.08
        ? _BalloonKind.hazard
        : roll < 0.18
            ? _BalloonKind.gold
            : _BalloonKind.normal;
    final radius = 25.0 + random.nextDouble() * 15.0;
    final margin = math.min(90.0, area.width * 0.10);
    balloons.add(
      _PopBalloon(
        x: margin + random.nextDouble() * math.max(1.0, area.width - margin * 2),
        y: area.height + radius + 10,
        vx: (random.nextDouble() - 0.5) * 32,
        speed: 75 + random.nextDouble() * 80,
        radius: radius,
        color: _balloonColors[random.nextInt(_balloonColors.length)],
        kind: kind,
        phase: random.nextDouble() * math.pi * 2,
      ),
    );
  }

  void _pop(_PopBalloon b) {
    b.popped = true;
    popped++;
    final pos = Offset(b.x, b.y);
    if (b.kind == _BalloonKind.hazard) {
      score = math.max(0, score - 220);
      combo = 0;
      GameAudio.wrong();
      bursts.add(_PopBurst(pos, const Color(0xFFFF5B5B)));
    } else {
      combo++;
      bestCombo = math.max(bestCombo, combo);
      final int bonus = b.kind == _BalloonKind.gold ? 260 : 100 + math.min(220, combo * 8);
      score += bonus;
      GameAudio.balloonPop(popped);
      if (b.kind == _BalloonKind.gold) GameAudio.sparkle();
      bursts.add(_PopBurst(pos, b.kind == _BalloonKind.gold ? const Color(0xFFFFD447) : b.color));
    }
    b.y = -200;
  }

  void _stopOrResume() {
    setState(() => gameStopped = !gameStopped);
    gameStopped ? GameAudio.stopGame() : GameAudio.resume();
  }

  void _restart() {
    setState(() {
      balloons.clear();
      bursts.clear();
      score = 0;
      popped = 0;
      combo = 0;
      bestCombo = 0;
      spawnClock = 0;
      cursor = Offset(area.width / 2, area.height / 2);
      phase = _BalloonPhase.countdown;
      phaseStart = DateTime.now();
      gameStopped = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          area = Size(constraints.maxWidth, constraints.maxHeight);
          if (cursor.dx > area.width || cursor.dy > area.height) {
            cursor = Offset(area.width / 2, area.height / 2);
          }
          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: _BalloonPopPainter(
                    balloons: balloons,
                    bursts: bursts,
                    cursor: cursor,
                    score: score,
                    popped: popped,
                    combo: combo,
                    bestCombo: bestCombo,
                  ),
                ),
              ),
              if (phase == _BalloonPhase.instructions)
                const Positioned.fill(
                  child: _ArcadeInstructionOverlay(
                    title: 'Balloon Pop',
                    subtitle: 'A precision game for smooth 2-D arm control',
                    icon: Icons.bubble_chart_rounded,
                    accent: Color(0xFF57C7FF),
                    lines: [
                      'Move the HelloBand cursor UP, DOWN, LEFT and RIGHT.',
                      'Touch a colored balloon to pop it automatically — no contraction needed.',
                      'Gold balloons give bonus points. Avoid dark hazard balloons.',
                    ],
                  ),
                ),
              if (phase == _BalloonPhase.countdown)
                Positioned.fill(
                  child: _GameCountdownOverlay(number: countdownNumber, title: 'POP READY'),
                ),
              if (gameStopped)
                Positioned.fill(
                  child: _GameStoppedOverlay(
                    title: 'Balloon Pop',
                    onResume: () => setState(() => gameStopped = false),
                    onRestart: _restart,
                    onBack: () => Navigator.of(context).pop(),
                  ),
                ),
              Positioned(
                left: 0,
                top: 0,
                child: _GameTopControls(
                  controller: widget.controller,
                  cursor: cursor,
                  stopped: gameStopped,
                  onBack: () => Navigator.of(context).pop(),
                  onStop: _stopOrResume,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

const List<Color> _balloonColors = <Color>[
  Color(0xFFFF5D8F),
  Color(0xFF57C7FF),
  Color(0xFF7DE47B),
  Color(0xFFFFB547),
  Color(0xFFA695FF),
  Color(0xFFFFE45E),
];

class _PopBalloon {
  _PopBalloon({
    required this.x,
    required this.y,
    required this.vx,
    required this.speed,
    required this.radius,
    required this.color,
    required this.kind,
    required this.phase,
  });
  double x;
  double y;
  double vx;
  double speed;
  double radius;
  Color color;
  _BalloonKind kind;
  double phase;
  bool popped = false;
}

class _PopBurst {
  _PopBurst(this.position, this.color);
  final Offset position;
  final Color color;
  double life = 1.0;
  double radius = 12.0;
}

class _BalloonPopPainter extends CustomPainter {
  _BalloonPopPainter({
    required this.balloons,
    required this.bursts,
    required this.cursor,
    required this.score,
    required this.popped,
    required this.combo,
    required this.bestCombo,
  });
  final List<_PopBalloon> balloons;
  final List<_PopBurst> bursts;
  final Offset cursor;
  final int score;
  final int popped;
  final int combo;
  final int bestCombo;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF102957), Color(0xFF284B8C), Color(0xFF7BD7FF)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    final cloud = Paint()..color = const Color(0x55FFFFFF);
    for (var i = 0; i < 6; i++) {
      final x = (i * 230.0 + 70) % math.max(1.0, size.width);
      final y = 150.0 + (i % 3) * 120.0;
      canvas.drawOval(Rect.fromCenter(center: Offset(x, y), width: 150, height: 48), cloud);
    }

    for (final b in balloons) {
      final center = Offset(b.x, b.y);
      final color = b.kind == _BalloonKind.gold
          ? const Color(0xFFFFD447)
          : b.kind == _BalloonKind.hazard
              ? const Color(0xFF273144)
              : b.color;
      final fill = Paint()..color = color;
      canvas.drawOval(
        Rect.fromCenter(center: center, width: b.radius * 1.65, height: b.radius * 2.05),
        fill,
      );
      canvas.drawOval(
        Rect.fromCenter(center: center + Offset(-b.radius * 0.27, -b.radius * 0.30), width: b.radius * 0.30, height: b.radius * 0.52),
        Paint()..color = Colors.white.withValues(alpha: 0.42),
      );
      canvas.drawLine(
        center + Offset(0, b.radius * 1.05),
        center + Offset(math.sin(b.phase) * 12, b.radius * 2.6),
        Paint()..color = const Color(0xAAFFFFFF)..strokeWidth = 1.5,
      );
      if (b.kind == _BalloonKind.gold) {
        _centerText(canvas, center, '★', Colors.white, b.radius * 0.9);
      } else if (b.kind == _BalloonKind.hazard) {
        _centerText(canvas, center, '!', const Color(0xFFFF6B6B), b.radius * 0.9);
      }
    }

    for (final burst in bursts) {
      canvas.drawCircle(
        burst.position,
        burst.radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 5
          ..color = burst.color.withValues(alpha: burst.life.clamp(0.0, 1.0)),
      );
    }

    canvas.drawCircle(cursor, 20, Paint()..color = const Color(0x33FFFFFF));
    canvas.drawCircle(
      cursor,
      16,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = Colors.white,
    );
    canvas.drawLine(cursor - const Offset(25, 0), cursor + const Offset(25, 0), Paint()..color = Colors.white..strokeWidth = 2);
    canvas.drawLine(cursor - const Offset(0, 25), cursor + const Offset(0, 25), Paint()..color = Colors.white..strokeWidth = 2);

    _hud(canvas, const Offset(24, 96), 'SCORE', '$score');
    _hud(canvas, const Offset(176, 96), 'POPPED', '$popped');
    _hud(canvas, const Offset(328, 96), 'COMBO', '${combo}x');
    _hud(canvas, const Offset(480, 96), 'BEST', '${bestCombo}x');
  }

  void _hud(Canvas canvas, Offset pos, String label, String value) {
    const width = 136.0;
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(pos.dx, pos.dy, width, 56), const Radius.circular(14)),
      Paint()..color = const Color(0xB30A1630),
    );
    final tp = TextPainter(
      text: TextSpan(
        children: [
          TextSpan(text: '$label\n', style: const TextStyle(color: Colors.white60, fontSize: 10, fontWeight: FontWeight.w700)),
          TextSpan(text: value, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
        ],
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: width - 18);
    tp.paint(canvas, pos + const Offset(10, 7));
  }

  void _centerText(Canvas canvas, Offset center, String text, Color color, double size) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.w900)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant _BalloonPopPainter oldDelegate) => true;
}

// ------------------------------------------------------------
// WORD BALLOONS
// ------------------------------------------------------------

enum _WordPhase { instructions, countdown, playing }

class WordBalloonScreen extends StatefulWidget {
  const WordBalloonScreen({super.key, required this.controller});
  final HelloBandController controller;

  @override
  State<WordBalloonScreen> createState() => _WordBalloonScreenState();
}

class _WordBalloonScreenState extends State<WordBalloonScreen> {
  static const List<String> words = <String>['CAT', 'SUN', 'DOG', 'RED', 'STAR', 'PLAY', 'MOON', 'BLUE'];
  final math.Random random = math.Random();
  Timer? timer;
  _WordPhase phase = _WordPhase.instructions;
  DateTime phaseStart = DateTime.now();
  Size area = Size.zero;
  Offset cursor = const Offset(600, 430);
  final List<_LetterBalloon> balloons = <_LetterBalloon>[];
  double spawnClock = 0.0;
  int wordIndex = 0;
  int letterIndex = 0;
  int score = 0;
  int completed = 0;
  int mistakes = 0;
  int popSerial = 0;
  bool gameStopped = false;

  String get target => words[wordIndex % words.length];
  String get nextLetter => target[letterIndex.clamp(0, target.length - 1).toInt()];

  @override
  void initState() {
    super.initState();
    phaseStart = DateTime.now();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  int get countdownNumber {
    final elapsed = DateTime.now().difference(phaseStart).inMilliseconds;
    return math.max(1, 3 - (elapsed ~/ 1000));
  }

  void _tick() {
    if (!mounted || area == Size.zero) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    const dt = 0.016;
    final now = DateTime.now();
    final elapsed = now.difference(phaseStart);
    final delta = widget.controller.consumeCursorDelta();
    cursor = Offset(
      (cursor.dx + delta[0]).clamp(16.0, area.width - 16.0),
      (cursor.dy + delta[1]).clamp(12.0, area.height - 16.0),
    );

    if (gameStopped) return;
    if (phase == _WordPhase.instructions) {
      if (elapsed >= const Duration(seconds: 5)) {
        phase = _WordPhase.countdown;
        phaseStart = now;
      }
      setState(() {});
      return;
    }
    if (phase == _WordPhase.countdown) {
      if (elapsed >= const Duration(seconds: 3)) {
        phase = _WordPhase.playing;
        phaseStart = now;
        GameAudio.start();
      }
      setState(() {});
      return;
    }

    spawnClock += dt;
    if (spawnClock >= 0.72) {
      spawnClock = 0;
      _spawnLetter();
    }

    for (final b in balloons) {
      b.y -= b.speed * dt;
      b.x += math.sin(b.phase += dt * 1.8) * 8 * dt;
    }

    for (final b in balloons) {
      if (b.used) continue;
      if ((Offset(b.x, b.y) - cursor).distance <= b.radius + 12) {
        _hitLetter(b);
      }
    }

    balloons.removeWhere((b) => b.used || b.y < -100);
    setState(() {});
  }

  void _spawnLetter() {
    if (area.width < 120 || area.height < 120) return;
    final useCorrect = random.nextDouble() < 0.52;
    final letter = useCorrect ? nextLetter : String.fromCharCode(65 + random.nextInt(26));
    final radius = 30.0 + random.nextDouble() * 7;
    final margin = math.min(100.0, area.width * 0.10);
    balloons.add(
      _LetterBalloon(
        x: margin + random.nextDouble() * math.max(1.0, area.width - margin * 2),
        y: area.height + radius,
        speed: 70 + random.nextDouble() * 65,
        radius: radius,
        letter: letter,
        color: _balloonColors[random.nextInt(_balloonColors.length)],
        phase: random.nextDouble() * math.pi * 2,
      ),
    );
  }

  void _hitLetter(_LetterBalloon b) {
    b.used = true;
    popSerial++;
    GameAudio.balloonPop(popSerial);
    if (b.letter == nextLetter) {
      score += 150;
      letterIndex++;
      GameAudio.correct();
      if (letterIndex >= target.length) {
        completed++;
        score += 400;
        GameAudio.wordComplete();
        wordIndex = (wordIndex + 1) % words.length;
        letterIndex = 0;
        balloons.clear();
      }
    } else {
      mistakes++;
      score = math.max(0, score - 75);
      GameAudio.wrong();
    }
  }

  void _stopOrResume() {
    setState(() => gameStopped = !gameStopped);
    gameStopped ? GameAudio.stopGame() : GameAudio.resume();
  }

  void _restart() {
    setState(() {
      balloons.clear();
      spawnClock = 0;
      wordIndex = 0;
      letterIndex = 0;
      score = 0;
      completed = 0;
      mistakes = 0;
      cursor = Offset(area.width / 2, area.height / 2);
      phase = _WordPhase.countdown;
      phaseStart = DateTime.now();
      gameStopped = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          area = Size(constraints.maxWidth, constraints.maxHeight);
          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: _WordBalloonPainter(
                    balloons: balloons,
                    cursor: cursor,
                    target: target,
                    letterIndex: letterIndex,
                    score: score,
                    completed: completed,
                    mistakes: mistakes,
                  ),
                ),
              ),
              if (phase == _WordPhase.instructions)
                const Positioned.fill(
                  child: _ArcadeInstructionOverlay(
                    title: 'Word Balloons',
                    subtitle: 'Combine arm control with spelling',
                    icon: Icons.abc_rounded,
                    accent: Color(0xFFFF8ED8),
                    lines: [
                      'A target word is shown at the top of the screen.',
                      'Move the cursor and pop the letters in the correct order.',
                      'Correct letters earn points; wrong letters reduce the score.',
                    ],
                  ),
                ),
              if (phase == _WordPhase.countdown)
                Positioned.fill(
                  child: _GameCountdownOverlay(number: countdownNumber, title: 'WORD READY'),
                ),
              if (gameStopped)
                Positioned.fill(
                  child: _GameStoppedOverlay(
                    title: 'Word Balloons',
                    onResume: () => setState(() => gameStopped = false),
                    onRestart: _restart,
                    onBack: () => Navigator.of(context).pop(),
                  ),
                ),
              Positioned(
                left: 0,
                top: 0,
                child: _GameTopControls(
                  controller: widget.controller,
                  cursor: cursor,
                  stopped: gameStopped,
                  onBack: () => Navigator.of(context).pop(),
                  onStop: _stopOrResume,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _LetterBalloon {
  _LetterBalloon({
    required this.x,
    required this.y,
    required this.speed,
    required this.radius,
    required this.letter,
    required this.color,
    required this.phase,
  });
  double x;
  double y;
  double speed;
  double radius;
  String letter;
  Color color;
  double phase;
  bool used = false;
}

class _WordBalloonPainter extends CustomPainter {
  _WordBalloonPainter({
    required this.balloons,
    required this.cursor,
    required this.target,
    required this.letterIndex,
    required this.score,
    required this.completed,
    required this.mistakes,
  });
  final List<_LetterBalloon> balloons;
  final Offset cursor;
  final String target;
  final int letterIndex;
  final int score;
  final int completed;
  final int mistakes;

  String get nextLetter {
    if (letterIndex >= target.length) {
      return 'DONE';
    }
    return target[letterIndex];
  }

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFFF7FAFF);
    canvas.drawRect(Offset.zero & size, bg);

    final targetBox = Rect.fromLTWH(math.max(20.0, size.width / 2 - 300), 86, math.min(600.0, size.width - 40), 116);
    canvas.drawRRect(
      RRect.fromRectAndRadius(targetBox, const Radius.circular(20)),
      Paint()..color = Colors.white,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(targetBox, const Radius.circular(20)),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFFFF8ED8),
    );
    _text(canvas, Offset(targetBox.left + 20, targetBox.top + 12), 'SPELL THIS WORD', const Color(0xFFC0267A), 12);
    final display = List<String>.generate(
      target.length,
      (i) => i < letterIndex ? target[i] : '_',
    ).join('  ');
    _text(canvas, Offset(targetBox.left + 20, targetBox.top + 38), display, const Color(0xFF101828), 32);
    _text(canvas, Offset(targetBox.left + 20, targetBox.top + 82), 'NEXT LETTER', const Color(0xFF667085), 11);
    _text(canvas, Offset(targetBox.left + 120, targetBox.top + 76), nextLetter, const Color(0xFF1F6FEB), 25);

    for (final b in balloons) {
      final center = Offset(b.x, b.y);
      canvas.drawOval(
        Rect.fromCenter(center: center, width: b.radius * 1.65, height: b.radius * 2.0),
        Paint()..color = b.color,
      );
      canvas.drawLine(
        center + Offset(0, b.radius),
        center + Offset(0, b.radius * 2.2),
        Paint()..color = const Color(0xAAFFFFFF)..strokeWidth = 1.2,
      );
      final tp = TextPainter(
        text: TextSpan(
          text: b.letter,
          style: TextStyle(color: const Color(0xFF111827), fontSize: b.radius * 0.95, fontWeight: FontWeight.w900),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
    }

    canvas.drawCircle(cursor, 18, Paint()..color = const Color(0x22000000));
    canvas.drawCircle(cursor, 14, Paint()..style = PaintingStyle.stroke..strokeWidth = 4..color = Colors.black);

    _smallHud(canvas, const Offset(22, 198), 'SCORE', '$score');
    _smallHud(canvas, const Offset(164, 198), 'WORDS', '$completed');
    _smallHud(canvas, const Offset(306, 198), 'MISTAKES', '$mistakes');
  }

  void _smallHud(Canvas canvas, Offset pos, String label, String value) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(pos.dx, pos.dy, 126, 54), const Radius.circular(13)),
      Paint()..color = Colors.white,
    );
    _text(canvas, pos + const Offset(10, 7), label, const Color(0xFF667085), 10);
    _text(canvas, pos + const Offset(10, 23), value, const Color(0xFF101828), 20);
  }

  void _text(Canvas canvas, Offset pos, String text, Color color, double size) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.w900)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, pos);
  }

  @override
  bool shouldRepaint(covariant _WordBalloonPainter oldDelegate) => true;
}

// ------------------------------------------------------------
// TARGET TAP — EASY CONTRACTION PRACTICE
// ------------------------------------------------------------

enum _TargetPhase { instructions, countdown, playing }

class TargetTapScreen extends StatefulWidget {
  const TargetTapScreen({super.key, required this.controller});
  final HelloBandController controller;

  @override
  State<TargetTapScreen> createState() => _TargetTapScreenState();
}

class _TargetTapScreenState extends State<TargetTapScreen> {
  final math.Random random = math.Random();
  Timer? timer;
  _TargetPhase phase = _TargetPhase.instructions;
  DateTime phaseStart = DateTime.now();
  Size area = Size.zero;
  Offset cursor = const Offset(600, 430);
  Offset target = const Offset(600, 430);
  int score = 0;
  int hits = 0;
  int misses = 0;
  int lastClickSerial = 0;
  bool gameStopped = false;

  @override
  void initState() {
    super.initState();
    lastClickSerial = widget.controller.clickSerial;
    phaseStart = DateTime.now();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  int get countdownNumber {
    final elapsed = DateTime.now().difference(phaseStart).inMilliseconds;
    return math.max(1, 3 - (elapsed ~/ 1000));
  }

  void _newTarget() {
    final minX = 90.0;
    final maxX = math.max(minX + 1, area.width - 90.0);
    final minY = 170.0;
    final maxY = math.max(minY + 1, area.height - 90.0);
    target = Offset(
      minX + random.nextDouble() * (maxX - minX),
      minY + random.nextDouble() * (maxY - minY),
    );
  }

  void _tick() {
    if (!mounted || area == Size.zero) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    final now = DateTime.now();
    final elapsed = now.difference(phaseStart);
    final delta = widget.controller.consumeCursorDelta();
    cursor = Offset(
      (cursor.dx + delta[0]).clamp(16.0, area.width - 16.0),
      (cursor.dy + delta[1]).clamp(12.0, area.height - 16.0),
    );

    final clickChanged = widget.controller.clickSerial != lastClickSerial;
    if (clickChanged) {
      lastClickSerial = widget.controller.clickSerial;
      if (phase == _TargetPhase.playing && !gameStopped) {
        if ((cursor - target).distance <= 58) {
          hits++;
          score += 100;
          GameAudio.correct();
          _newTarget();
        } else {
          misses++;
          score = math.max(0, score - 25);
          GameAudio.wrong();
        }
      }
    }

    if (gameStopped) {
      setState(() {});
      return;
    }

    if (phase == _TargetPhase.instructions && elapsed >= const Duration(seconds: 4)) {
      phase = _TargetPhase.countdown;
      phaseStart = now;
    } else if (phase == _TargetPhase.countdown && elapsed >= const Duration(seconds: 3)) {
      phase = _TargetPhase.playing;
      phaseStart = now;
      _newTarget();
      GameAudio.start();
    }
    setState(() {});
  }

  void _stopOrResume() {
    setState(() => gameStopped = !gameStopped);
    gameStopped ? GameAudio.stopGame() : GameAudio.resume();
  }

  void _restart() {
    setState(() {
      score = 0;
      hits = 0;
      misses = 0;
      gameStopped = false;
      cursor = Offset(area.width / 2, area.height / 2);
      phase = _TargetPhase.countdown;
      phaseStart = DateTime.now();
      _newTarget();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          area = Size(constraints.maxWidth, constraints.maxHeight);
          if (cursor == const Offset(600, 430) && area.width > 0) {
            cursor = Offset(area.width / 2, area.height / 2);
          }
          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: _TargetTapPainter(
                    cursor: cursor,
                    target: target,
                    score: score,
                    hits: hits,
                    misses: misses,
                  ),
                ),
              ),
              if (phase == _TargetPhase.instructions)
                const Positioned.fill(
                  child: _ArcadeInstructionOverlay(
                    title: 'Target Tap',
                    subtitle: 'The easiest game for contraction practice',
                    icon: Icons.ads_click_rounded,
                    accent: Color(0xFF4C8DFF),
                    lines: [
                      'Move the cursor onto the target.',
                      'Contract once to select it.',
                      'Each correct tap gives +100 points.',
                    ],
                  ),
                ),
              if (phase == _TargetPhase.countdown)
                Positioned.fill(
                  child: _GameCountdownOverlay(number: countdownNumber, title: 'TARGET READY'),
                ),
              if (gameStopped)
                Positioned.fill(
                  child: _GameStoppedOverlay(
                    title: 'Target Tap',
                    onResume: () => setState(() => gameStopped = false),
                    onRestart: _restart,
                    onBack: () => Navigator.of(context).pop(),
                  ),
                ),
              Positioned(
                left: 0,
                top: 0,
                child: _GameTopControls(
                  controller: widget.controller,
                  cursor: cursor,
                  stopped: gameStopped,
                  onBack: () => Navigator.of(context).pop(),
                  onStop: _stopOrResume,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _TargetTapPainter extends CustomPainter {
  const _TargetTapPainter({
    required this.cursor,
    required this.target,
    required this.score,
    required this.hits,
    required this.misses,
  });

  final Offset cursor;
  final Offset target;
  final int score;
  final int hits;
  final int misses;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFFF7FAFF));

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(math.max(20.0, size.width / 2 - 250), 90, math.min(500.0, size.width - 40), 92),
        const Radius.circular(20),
      ),
      Paint()..color = Colors.white,
    );
    _text(canvas, Offset(math.max(40.0, size.width / 2 - 230), 108), 'MOVE TO THE BLUE TARGET', const Color(0xFF344054), 18);
    _text(canvas, Offset(math.max(40.0, size.width / 2 - 230), 138), 'CONTRACT TO TAP', const Color(0xFF1F6FEB), 26);

    canvas.drawCircle(target, 48, Paint()..color = const Color(0xFF4C8DFF).withValues(alpha: 0.18));
    canvas.drawCircle(target, 34, Paint()..color = const Color(0xFF4C8DFF));
    canvas.drawCircle(target, 18, Paint()..color = Colors.white);
    canvas.drawCircle(target, 8, Paint()..color = const Color(0xFF4C8DFF));

    canvas.drawCircle(cursor, 20, Paint()..color = const Color(0x331F6FEB));
    canvas.drawCircle(cursor, 15, Paint()..style = PaintingStyle.stroke..strokeWidth = 4..color = const Color(0xFF1F6FEB));

    _hud(canvas, const Offset(24, 205), 'SCORE', '$score');
    _hud(canvas, const Offset(164, 205), 'HITS', '$hits');
    _hud(canvas, const Offset(304, 205), 'MISSES', '$misses');
  }

  void _hud(Canvas canvas, Offset pos, String label, String value) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(pos.dx, pos.dy, 126, 54), const Radius.circular(13)),
      Paint()..color = Colors.white,
    );
    _text(canvas, pos + const Offset(10, 7), label, const Color(0xFF667085), 10);
    _text(canvas, pos + const Offset(10, 23), value, const Color(0xFF101828), 20);
  }

  void _text(Canvas canvas, Offset pos, String text, Color color, double size) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.w900)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, pos);
  }

  @override
  bool shouldRepaint(covariant _TargetTapPainter oldDelegate) => true;
}

// ------------------------------------------------------------
// COLOR MATCH
// ------------------------------------------------------------

enum _ColorPhase { instructions, countdown, playing }

class ColorMatchScreen extends StatefulWidget {
  const ColorMatchScreen({super.key, required this.controller});
  final HelloBandController controller;

  @override
  State<ColorMatchScreen> createState() => _ColorMatchScreenState();
}

class _ColorMatchScreenState extends State<ColorMatchScreen> {
  static const List<String> names = <String>['RED', 'BLUE', 'GREEN', 'YELLOW'];
  static const List<Color> colors = <Color>[
    Color(0xFFFF5B6B),
    Color(0xFF4DA7FF),
    Color(0xFF65D77A),
    Color(0xFFFFD447),
  ];
  final math.Random random = math.Random();
  Timer? timer;
  _ColorPhase phase = _ColorPhase.instructions;
  DateTime phaseStart = DateTime.now();
  Size area = Size.zero;
  Offset cursor = const Offset(600, 430);
  final List<_ColorBubble> bubbles = <_ColorBubble>[];
  double spawnClock = 0.0;
  int targetIndex = 0;
  int score = 0;
  int streak = 0;
  int bestStreak = 0;
  int correct = 0;
  int wrong = 0;
  int popSerial = 0;
  bool gameStopped = false;

  @override
  void initState() {
    super.initState();
    targetIndex = random.nextInt(colors.length);
    phaseStart = DateTime.now();
    timer = Timer.periodic(const Duration(milliseconds: 16), (_) => _tick());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  int get countdownNumber {
    final elapsed = DateTime.now().difference(phaseStart).inMilliseconds;
    return math.max(1, 3 - (elapsed ~/ 1000));
  }

  void _tick() {
    if (!mounted || area == Size.zero) return;
    if (ModalRoute.of(context)?.isCurrent != true) return;
    const dt = 0.016;
    final now = DateTime.now();
    final elapsed = now.difference(phaseStart);
    final delta = widget.controller.consumeCursorDelta();
    cursor = Offset(
      (cursor.dx + delta[0]).clamp(16.0, area.width - 16.0),
      (cursor.dy + delta[1]).clamp(12.0, area.height - 16.0),
    );

    if (gameStopped) return;
    if (phase == _ColorPhase.instructions) {
      if (elapsed >= const Duration(seconds: 5)) {
        phase = _ColorPhase.countdown;
        phaseStart = now;
      }
      setState(() {});
      return;
    }
    if (phase == _ColorPhase.countdown) {
      if (elapsed >= const Duration(seconds: 3)) {
        phase = _ColorPhase.playing;
        phaseStart = now;
        GameAudio.start();
      }
      setState(() {});
      return;
    }

    spawnClock += dt;
    if (spawnClock >= 0.62) {
      spawnClock = 0;
      _spawnBubble();
    }

    for (final b in bubbles) {
      b.y -= b.speed * dt;
      b.x += b.vx * dt;
      if (b.x < b.radius || b.x > area.width - b.radius) b.vx = -b.vx;
    }

    for (final b in bubbles) {
      if (b.used) continue;
      if ((Offset(b.x, b.y) - cursor).distance <= b.radius + 12) {
        _hit(b);
      }
    }
    bubbles.removeWhere((b) => b.used || b.y < -100);
    setState(() {});
  }

  void _spawnBubble() {
    if (area.width < 120 || area.height < 120) return;
    final radius = 27.0 + random.nextDouble() * 12;
    final margin = math.min(95.0, area.width * 0.10);
    bubbles.add(
      _ColorBubble(
        x: margin + random.nextDouble() * math.max(1.0, area.width - margin * 2),
        y: area.height + radius,
        vx: (random.nextDouble() - 0.5) * 45,
        speed: 75 + random.nextDouble() * 70,
        radius: radius,
        colorIndex: random.nextInt(colors.length),
      ),
    );
  }

  void _hit(_ColorBubble b) {
    b.used = true;
    popSerial++;
    GameAudio.balloonPop(popSerial);
    if (b.colorIndex == targetIndex) {
      correct++;
      streak++;
      bestStreak = math.max(bestStreak, streak);
      score += 120 + math.min(240, streak * 10);
      GameAudio.correct();
      targetIndex = random.nextInt(colors.length);
    } else {
      wrong++;
      streak = 0;
      score = math.max(0, score - 90);
      GameAudio.wrong();
    }
  }

  void _stopOrResume() {
    setState(() => gameStopped = !gameStopped);
    gameStopped ? GameAudio.stopGame() : GameAudio.resume();
  }

  void _restart() {
    setState(() {
      bubbles.clear();
      score = 0;
      streak = 0;
      bestStreak = 0;
      correct = 0;
      wrong = 0;
      spawnClock = 0;
      targetIndex = random.nextInt(colors.length);
      cursor = Offset(area.width / 2, area.height / 2);
      phase = _ColorPhase.countdown;
      phaseStart = DateTime.now();
      gameStopped = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          area = Size(constraints.maxWidth, constraints.maxHeight);
          return Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: _ColorMatchPainter(
                    bubbles: bubbles,
                    cursor: cursor,
                    targetIndex: targetIndex,
                    score: score,
                    streak: streak,
                    bestStreak: bestStreak,
                    correct: correct,
                    wrong: wrong,
                  ),
                ),
              ),
              if (phase == _ColorPhase.instructions)
                const Positioned.fill(
                  child: _ArcadeInstructionOverlay(
                    title: 'Color Match',
                    subtitle: 'A visual reaction and selective-control challenge',
                    icon: Icons.palette_rounded,
                    accent: Color(0xFFA695FF),
                    lines: [
                      'The target color is shown clearly at the top.',
                      'Move the cursor and touch only a bubble with the matching color.',
                      'The target changes after every correct selection.',
                    ],
                  ),
                ),
              if (phase == _ColorPhase.countdown)
                Positioned.fill(
                  child: _GameCountdownOverlay(number: countdownNumber, title: 'COLOR READY'),
                ),
              if (gameStopped)
                Positioned.fill(
                  child: _GameStoppedOverlay(
                    title: 'Color Match',
                    onResume: () => setState(() => gameStopped = false),
                    onRestart: _restart,
                    onBack: () => Navigator.of(context).pop(),
                  ),
                ),
              Positioned(
                left: 0,
                top: 0,
                child: _GameTopControls(
                  controller: widget.controller,
                  cursor: cursor,
                  stopped: gameStopped,
                  onBack: () => Navigator.of(context).pop(),
                  onStop: _stopOrResume,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ColorBubble {
  _ColorBubble({
    required this.x,
    required this.y,
    required this.vx,
    required this.speed,
    required this.radius,
    required this.colorIndex,
  });
  double x;
  double y;
  double vx;
  double speed;
  double radius;
  int colorIndex;
  bool used = false;
}

class _ColorMatchPainter extends CustomPainter {
  _ColorMatchPainter({
    required this.bubbles,
    required this.cursor,
    required this.targetIndex,
    required this.score,
    required this.streak,
    required this.bestStreak,
    required this.correct,
    required this.wrong,
  });
  final List<_ColorBubble> bubbles;
  final Offset cursor;
  final int targetIndex;
  final int score;
  final int streak;
  final int bestStreak;
  final int correct;
  final int wrong;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF111A36), Color(0xFF20285A), Color(0xFF3B2E70)],
      ).createShader(Offset.zero & size);
    canvas.drawRect(Offset.zero & size, bg);

    final boxW = math.min(520.0, size.width - 40);
    final box = Rect.fromLTWH((size.width - boxW) / 2, 94, boxW, 86);
    canvas.drawRRect(
      RRect.fromRectAndRadius(box, const Radius.circular(20)),
      Paint()..color = const Color(0xC50C1424),
    );
    _text(canvas, Offset(box.left + 18, box.top + 10), 'TARGET COLOR', Colors.white60, 11);
    canvas.drawCircle(Offset(box.left + 54, box.top + 52), 23, Paint()..color = _ColorMatchScreenState.colors[targetIndex]);
    _text(
      canvas,
      Offset(box.left + 94, box.top + 35),
      _ColorMatchScreenState.names[targetIndex],
      _ColorMatchScreenState.colors[targetIndex],
      30,
    );

    for (final b in bubbles) {
      final center = Offset(b.x, b.y);
      final color = _ColorMatchScreenState.colors[b.colorIndex];
      canvas.drawCircle(center, b.radius, Paint()..color = color);
      canvas.drawCircle(
        center + Offset(-b.radius * 0.25, -b.radius * 0.30),
        b.radius * 0.22,
        Paint()..color = Colors.white.withValues(alpha: 0.42),
      );
    }

    canvas.drawCircle(cursor, 18, Paint()..color = const Color(0x33FFFFFF));
    canvas.drawCircle(cursor, 14, Paint()..style = PaintingStyle.stroke..strokeWidth = 4..color = Colors.white);

    _hud(canvas, const Offset(22, 198), 'SCORE', '$score');
    _hud(canvas, const Offset(164, 198), 'STREAK', '${streak}x');
    _hud(canvas, const Offset(306, 198), 'BEST', '${bestStreak}x');
    _hud(canvas, const Offset(448, 198), 'RIGHT', '$correct');
    _hud(canvas, const Offset(590, 198), 'WRONG', '$wrong');
  }

  void _hud(Canvas canvas, Offset pos, String label, String value) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(pos.dx, pos.dy, 126, 54), const Radius.circular(13)),
      Paint()..color = const Color(0xA80C1424),
    );
    _text(canvas, pos + const Offset(10, 7), label, Colors.white54, 10);
    _text(canvas, pos + const Offset(10, 23), value, Colors.white, 20);
  }

  void _text(Canvas canvas, Offset pos, String text, Color color, double size) {
    final tp = TextPainter(
      text: TextSpan(text: text, style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.w900)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, pos);
  }

  @override
  bool shouldRepaint(covariant _ColorMatchPainter oldDelegate) => true;
}

class _StatusPill extends StatelessWidget {
  const _StatusPill({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF1A2944),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0xFF314466)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white70,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}
