import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import 'waveletech.dart';

enum CalibrationStage {
  notStarted,
  rest,
  contract,
  neutral,
  right,
  down,
  spinLeft,
  spinRight,
  complete,
}

enum CalibrationPhase {
  idle,
  prepare,
  recording,
  finished,
}

class HelloBandController extends ChangeNotifier {
  final WaveletechSerialService serial = WaveletechSerialService();
  final EmgProcessor emg = EmgProcessor();
  final ControlEngine control = ControlEngine();
  final ClickStateMachine click = ClickStateMachine();

  static const Duration calibrationPrepareTime = Duration(seconds: 3);

  StreamSubscription<WaveletechPacket>? _packetSub;
  Timer? _uiTimer;
  Timer? _calibrationTimer;

  bool connected = false;
  String? connectedPort;
  String? lastError;

  int aaRate = 0;
  int bbRate = 0;
  int _aaCount = 0;
  int _bbCount = 0;
  DateTime _rateEpoch = DateTime.now();

  CalibrationStage stage = CalibrationStage.notStarted;
  CalibrationPhase calibrationPhase = CalibrationPhase.idle;
  double calibrationProgress = 0.0;
  int prepareSecondsRemaining = 3;
  double recordingSecondsRemaining = 0.0;
  String calibrationMessage = 'Connect the Waveletech wristband.';

  final List<List<double>> _restRmsSamples = <List<double>>[];
  final List<double> _contractScoreSamples = <double>[];
  final List<List<double>> _gyroSamples = <List<double>>[];

  List<double>? _rightRaw;
  List<double>? _downRaw;
  List<double>? _spinLeftRaw;

  List<double> latestEmg = List.filled(8, 0.0);
  List<double> latestRms = List.filled(8, 0.0);
  List<double> latestGyro = List.filled(3, 0.0);
  List<double> latestAcc = List.filled(3, 0.0);
  double activationScore = 0.0;
  bool contraction = false;

  double _pendingDx = 0.0;
  double _pendingDy = 0.0;
  double _pendingScroll = 0.0;
  int clickSerial = 0;

  List<String> get ports => serial.availablePorts;
  bool get calibrationComplete => stage == CalibrationStage.complete;
  bool get calibrationRecording => calibrationPhase == CalibrationPhase.recording;

  int get calibrationStepNumber {
    switch (stage) {
      case CalibrationStage.rest:
        return 1;
      case CalibrationStage.contract:
        return 2;
      case CalibrationStage.neutral:
        return 3;
      case CalibrationStage.right:
        return 4;
      case CalibrationStage.down:
        return 5;
      case CalibrationStage.spinLeft:
        return 6;
      case CalibrationStage.spinRight:
        return 7;
      case CalibrationStage.complete:
        return 7;
      case CalibrationStage.notStarted:
        return 0;
    }
  }

  double get contractionPercent {
    final rest = emg.restScoreMean;
    final contract = emg.contractScoreMean;
    if (rest == null || contract == null || contract <= rest) return 0.0;
    return (((activationScore - rest) / (contract - rest)) * 100.0)
        .clamp(0.0, 100.0);
  }

  /// Normalized muscle strength for drawing and adaptive UI controls.
  double get contractionLevel => (contractionPercent / 100.0).clamp(0.0, 1.0);

  Future<void> connect(String port) async {
    try {
      lastError = null;
      await serial.connect(port);
      connected = true;
      connectedPort = port;
      _packetSub = serial.packets.listen(
        _onPacket,
        onError: (Object error, StackTrace stack) {
          lastError = error.toString();
          connected = false;
          notifyListeners();
        },
      );
      _uiTimer ??= Timer.periodic(
        const Duration(milliseconds: 16),
        (_) => notifyListeners(),
      );
      calibrationMessage = 'Connected. Press Start Calibration when ready.';
      notifyListeners();
    } catch (e) {
      lastError = e.toString();
      connected = false;
      notifyListeners();
      rethrow;
    }
  }

  Future<void> disconnect() async {
    _calibrationTimer?.cancel();
    _calibrationTimer = null;
    await _packetSub?.cancel();
    _packetSub = null;
    await serial.disconnect();
    connected = false;
    connectedPort = null;
    stage = CalibrationStage.notStarted;
    calibrationPhase = CalibrationPhase.idle;
    notifyListeners();
  }

  void _onPacket(WaveletechPacket packet) {
    _updateRates(packet.kind);

    if (packet.kind == 'AA') {
      final raw = packet.emgUv!;
      latestEmg = List<double>.from(raw);
      emg.update(raw);
      latestRms = List<double>.from(emg.currentRms);
      activationScore = emg.activationScore();

      // Calibration samples are collected ONLY after the 3-second prepare
      // countdown finishes and the UI displays GO / RECORDING.
      if (calibrationRecording) {
        if (stage == CalibrationStage.rest) {
          _restRmsSamples.add(List<double>.from(latestRms));
        } else if (stage == CalibrationStage.contract) {
          _contractScoreSamples.add(activationScore);
        }
      }

      final didClick = click.update(
        activationScore,
        emg.clickThreshold,
        emg.releaseThreshold,
      );
      contraction = emg.clickThreshold != null &&
          activationScore >= emg.clickThreshold!;
      if (didClick && calibrationComplete) {
        clickSerial++;
      }
      return;
    }

    if (packet.kind == 'BB') {
      latestGyro = List<double>.from(packet.gyro!);
      latestAcc = List<double>.from(packet.acc!);

      if (calibrationRecording &&
          (stage == CalibrationStage.neutral ||
              stage == CalibrationStage.right ||
              stage == CalibrationStage.down ||
              stage == CalibrationStage.spinLeft ||
              stage == CalibrationStage.spinRight)) {
        _gyroSamples.add(List<double>.from(latestGyro));
      }

      if (control.vectorCalibrated && calibrationComplete) {
        final delta = control.cursorDelta(latestGyro);
        _pendingDx += delta[0];
        _pendingDy += delta[1];
      }

      if (control.spinCalibrated && calibrationComplete) {
        _pendingScroll += control.scrollDelta(latestGyro);
      }
    }
  }

  void _updateRates(String kind) {
    if (kind == 'AA') {
      _aaCount++;
    } else {
      _bbCount++;
    }

    final now = DateTime.now();
    final elapsedMs = now.difference(_rateEpoch).inMilliseconds;
    if (elapsedMs >= 1000) {
      final factor = 1000.0 / math.max(1, elapsedMs);
      aaRate = (_aaCount * factor).round();
      bbRate = (_bbCount * factor).round();
      _aaCount = 0;
      _bbCount = 0;
      _rateEpoch = now;
    }
  }

  List<double> consumeCursorDelta() {
    final out = <double>[_pendingDx, _pendingDy];
    _pendingDx = 0.0;
    _pendingDy = 0.0;
    return out;
  }

  /// Positive values follow SPIN LEFT and are used as scroll-up.
  double consumeScrollDelta() {
    final out = _pendingScroll;
    _pendingScroll = 0.0;
    return out;
  }

  void beginCalibration() {
    if (!connected) return;
    _calibrationTimer?.cancel();
    emg.resetFilter();
    click.reset();
    control.rightVector = null;
    control.downVector = null;
    control.spinAxis = null;
    _rightRaw = null;
    _downRaw = null;
    _spinLeftRaw = null;
    _pendingDx = 0.0;
    _pendingDy = 0.0;
    _pendingScroll = 0.0;
    startRestCalibration();
  }

  void startRestCalibration() {
    _restRmsSamples.clear();
    emg.resetFilter();
    _startGuidedStage(
      CalibrationStage.rest,
      const Duration(seconds: 5),
      'Relax your arm and keep it still. Do not squeeze yet.',
      _finishRest,
    );
  }

  void _finishRest() {
    try {
      emg.setRestCalibration(_restRmsSamples);
      startContractCalibration();
    } catch (e) {
      _failCalibration(e);
    }
  }

  void startContractCalibration() {
    _contractScoreSamples.clear();
    _startGuidedStage(
      CalibrationStage.contract,
      const Duration(seconds: 5),
      'When GO appears, make your comfortable muscle squeeze and hold it.',
      _finishContract,
    );
  }

  void _finishContract() {
    try {
      emg.setContractCalibration(_contractScoreSamples);
      click.reset();
      startNeutralCalibration();
    } catch (e) {
      _failCalibration(e);
    }
  }

  void startNeutralCalibration() {
    _gyroSamples.clear();
    _startGuidedStage(
      CalibrationStage.neutral,
      const Duration(seconds: 2),
      'Place your arm in a comfortable centre position and keep completely still.',
      _finishNeutral,
    );
  }

  void _finishNeutral() {
    try {
      if (_gyroSamples.length < 10) {
        throw Exception('Too few IMU samples during NEUTRAL calibration.');
      }
      final bias = <double>[
        median(_gyroSamples.map((v) => v[0]).toList()),
        median(_gyroSamples.map((v) => v[1]).toList()),
        median(_gyroSamples.map((v) => v[2]).toList()),
      ];
      control.setGyroBias(bias);
      startRightCalibration();
    } catch (e) {
      _failCalibration(e);
    }
  }

  void startRightCalibration() {
    _gyroSamples.clear();
    _startGuidedStage(
      CalibrationStage.right,
      const Duration(milliseconds: 1500),
      'Wait for GO, then make ONE comfortable movement toward screen RIGHT and stop.',
      _finishRight,
    );
  }

  void _finishRight() {
    try {
      _rightRaw = control.extractMotionVector(_gyroSamples);
      startDownCalibration();
    } catch (e) {
      _failCalibration(e);
    }
  }

  void startDownCalibration() {
    _gyroSamples.clear();
    _startGuidedStage(
      CalibrationStage.down,
      const Duration(milliseconds: 1500),
      'Wait for GO, then make ONE comfortable movement toward screen DOWN and stop.',
      _finishDown,
    );
  }

  void _finishDown() {
    try {
      _downRaw = control.extractMotionVector(_gyroSamples);
      final angle = control.applyVectorCalibration(
        control.gyroBias,
        _rightRaw!,
        _downRaw!,
      );
      if (angle < 25.0 || angle > 155.0) {
        throw Exception(
          'RIGHT and DOWN were too similar (${angle.toStringAsFixed(1)} degrees).',
        );
      }
      startSpinLeftCalibration();
    } catch (e) {
      _failCalibration(e);
    }
  }

  void startSpinLeftCalibration() {
    _gyroSamples.clear();
    _startGuidedStage(
      CalibrationStage.spinLeft,
      const Duration(milliseconds: 1500),
      'Wait for GO, then rotate your forearm LEFT once and stop.',
      _finishSpinLeft,
    );
  }

  void _finishSpinLeft() {
    try {
      _spinLeftRaw = control.extractMotionVector(_gyroSamples);
      startSpinRightCalibration();
    } catch (e) {
      _failCalibration(e);
    }
  }

  void startSpinRightCalibration() {
    _gyroSamples.clear();
    _startGuidedStage(
      CalibrationStage.spinRight,
      const Duration(milliseconds: 1500),
      'Wait for GO, then rotate your forearm RIGHT once and stop.',
      _finishSpinRight,
    );
  }

  void _finishSpinRight() {
    try {
      final rightSpin = control.extractMotionVector(_gyroSamples);
      control.applySpinCalibration(_spinLeftRaw!, rightSpin);
      stage = CalibrationStage.complete;
      calibrationPhase = CalibrationPhase.finished;
      calibrationProgress = 1.0;
      prepareSecondsRemaining = 0;
      recordingSecondsRemaining = 0.0;
      calibrationMessage = 'Calibration complete. Entering Cursor Mode...';
      notifyListeners();
    } catch (e) {
      _failCalibration(e);
    }
  }

  /// Every calibration step now has a 3-second PREPARE period before the
  /// successful V2.7 recording window starts. No calibration samples are used
  /// during PREPARE, so an early movement will not contaminate the stage.
  void _startGuidedStage(
    CalibrationStage newStage,
    Duration recordingDuration,
    String instruction,
    VoidCallback onFinished,
  ) {
    _calibrationTimer?.cancel();
    stage = newStage;
    calibrationPhase = CalibrationPhase.prepare;
    calibrationProgress = 0.0;
    calibrationMessage = instruction;
    prepareSecondsRemaining = calibrationPrepareTime.inSeconds;
    recordingSecondsRemaining =
        recordingDuration.inMilliseconds / 1000.0;

    final start = DateTime.now();
    final prepareMs = calibrationPrepareTime.inMilliseconds;
    final recordMs = recordingDuration.inMilliseconds;

    notifyListeners();

    _calibrationTimer = Timer.periodic(
      const Duration(milliseconds: 50),
      (timer) {
        final elapsedMs = DateTime.now().difference(start).inMilliseconds;

        if (elapsedMs < prepareMs) {
          calibrationPhase = CalibrationPhase.prepare;
          final remainingMs = prepareMs - elapsedMs;
          prepareSecondsRemaining = math.max(1, (remainingMs / 1000.0).ceil());
          calibrationProgress = 0.0;
          recordingSecondsRemaining = recordMs / 1000.0;
          notifyListeners();
          return;
        }

        calibrationPhase = CalibrationPhase.recording;
        prepareSecondsRemaining = 0;
        final recordingElapsedMs = elapsedMs - prepareMs;
        calibrationProgress =
            (recordingElapsedMs / recordMs).clamp(0.0, 1.0);
        recordingSecondsRemaining =
            math.max(0.0, (recordMs - recordingElapsedMs) / 1000.0);

        if (recordingElapsedMs >= recordMs) {
          timer.cancel();
          _calibrationTimer = null;
          calibrationProgress = 1.0;
          recordingSecondsRemaining = 0.0;
          onFinished();
        }
        notifyListeners();
      },
    );
  }

  void _failCalibration(Object error) {
    _calibrationTimer?.cancel();
    _calibrationTimer = null;
    stage = CalibrationStage.notStarted;
    calibrationPhase = CalibrationPhase.idle;
    calibrationProgress = 0.0;
    prepareSecondsRemaining = 3;
    recordingSecondsRemaining = 0.0;
    calibrationMessage = 'Calibration failed: $error';
    lastError = error.toString();
    notifyListeners();
  }

  String get stageTitle {
    switch (stage) {
      case CalibrationStage.rest:
        return 'REST';
      case CalibrationStage.contract:
        return 'CONTRACT';
      case CalibrationStage.neutral:
        return 'NEUTRAL';
      case CalibrationStage.right:
        return 'MOVE RIGHT';
      case CalibrationStage.down:
        return 'MOVE DOWN';
      case CalibrationStage.spinLeft:
        return 'SPIN LEFT';
      case CalibrationStage.spinRight:
        return 'SPIN RIGHT';
      case CalibrationStage.complete:
        return 'READY';
      case CalibrationStage.notStarted:
        return 'CALIBRATION';
    }
  }

  String get nextStageTitle {
    switch (stage) {
      case CalibrationStage.rest:
        return 'Next: CONTRACT';
      case CalibrationStage.contract:
        return 'Next: NEUTRAL';
      case CalibrationStage.neutral:
        return 'Next: MOVE RIGHT';
      case CalibrationStage.right:
        return 'Next: MOVE DOWN';
      case CalibrationStage.down:
        return 'Next: SPIN LEFT';
      case CalibrationStage.spinLeft:
        return 'Next: SPIN RIGHT';
      case CalibrationStage.spinRight:
        return 'Next: Cursor Mode';
      case CalibrationStage.complete:
        return 'Cursor Mode';
      case CalibrationStage.notStarted:
        return 'Step 1: REST';
    }
  }

  String get calibrationPhaseTitle {
    switch (calibrationPhase) {
      case CalibrationPhase.prepare:
        return 'GET READY';
      case CalibrationPhase.recording:
        return 'GO NOW';
      case CalibrationPhase.finished:
        return 'COMPLETE';
      case CalibrationPhase.idle:
        return 'READY TO START';
    }
  }

  @override
  void dispose() {
    _uiTimer?.cancel();
    _calibrationTimer?.cancel();
    _packetSub?.cancel();
    serial.dispose();
    super.dispose();
  }
}
