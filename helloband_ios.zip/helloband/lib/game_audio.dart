import 'package:audioplayers/audioplayers.dart';

/// Shared sound-effect mixer for the HelloBand games.
///
/// All bundled sounds are original synthesized effects created for this
/// project. Audio failures are intentionally ignored so sound can never stop
/// the assistive controls or game loop from working.
class GameAudio {
  GameAudio._();

  static bool enabled = true;
  static final List<AudioPlayer> _players = List<AudioPlayer>.generate(
    8,
    (_) => AudioPlayer(),
  );
  static int _next = 0;

  static Future<void> _play(String asset, {double volume = 0.8}) async {
    if (!enabled) return;
    final player = _players[_next % _players.length];
    _next++;
    try {
      await player.stop();
      await player.play(AssetSource('sounds/$asset'), volume: volume);
    } catch (_) {
      // Sound must never break cursor/game control.
    }
  }

  // General UI / game-state sounds.
  static Future<void> select() => _play('select.wav', volume: 0.65);
  static Future<void> back() => _play('ui_back.wav', volume: 0.58);
  static Future<void> start() => _play('start.wav', volume: 0.62);
  static Future<void> stopGame() => _play('stop.wav', volume: 0.68);
  static Future<void> resume() => _play('resume.wav', volume: 0.62);
  static Future<void> restart() => _play('restart.wav', volume: 0.68);
  static Future<void> win() => _play('win.wav', volume: 0.82);

  // Racing / runner sounds.
  static Future<void> collect() => _play('collect.wav', volume: 0.55);
  static Future<void> coin() => _play('coin.wav', volume: 0.58);
  static Future<void> crash() => _play('crash.wav', volume: 0.80);
  static Future<void> boost() => _play('boost.wav', volume: 0.68);
  static Future<void> brake() => _play('brake.wav', volume: 0.58);
  static Future<void> laneChange() => _play('lane.wav', volume: 0.45);
  static Future<void> jump() => _play('jump.wav', volume: 0.62);
  static Future<void> slide() => _play('slide.wav', volume: 0.56);

  // Fruit Slice sounds. Alternate between three slice timbres so repeated
  // slicing feels less mechanical.
  static Future<void> fruitSlice(int serial) {
    final index = serial.abs() % 3;
    final asset = switch (index) {
      0 => 'slice.wav',
      1 => 'slice_2.wav',
      _ => 'slice_3.wav',
    };
    return _play(asset, volume: 0.74);
  }

  static Future<void> slice() => _play('slice.wav', volume: 0.75);
  static Future<void> fruitMiss() => _play('fruit_miss.wav', volume: 0.34);
  static Future<void> combo() => _play('combo.wav', volume: 0.72);


  // Balloon / cognitive game sounds.
  static Future<void> balloonPop(int serial) {
    final index = serial.abs() % 3;
    final asset = switch (index) {
      0 => 'balloon_pop_1.wav',
      1 => 'balloon_pop_2.wav',
      _ => 'balloon_pop_3.wav',
    };
    return _play(asset, volume: 0.70);
  }

  static Future<void> correct() => _play('correct.wav', volume: 0.68);
  static Future<void> wrong() => _play('wrong.wav', volume: 0.56);
  static Future<void> wordComplete() => _play('word_complete.wav', volume: 0.76);
  static Future<void> sparkle() => _play('sparkle.wav', volume: 0.62);

  // Maze sounds.
  static Future<void> power() => _play('power.wav', volume: 0.72);
  static Future<void> mazeEat() => _play('maze_eat.wav', volume: 0.42);
  static Future<void> mazeKey() => _play('maze_key.wav', volume: 0.72);
  static Future<void> mazeBump() => _play('maze_bump.wav', volume: 0.34);

  static Future<void> dispose() async {
    for (final player in _players) {
      try {
        await player.dispose();
      } catch (_) {}
    }
  }
}
