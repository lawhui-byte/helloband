import 'package:flutter/material.dart';

import 'helloband_controller.dart';
import 'screens.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HelloBandApp());
}

class HelloBandApp extends StatefulWidget {
  const HelloBandApp({super.key});

  @override
  State<HelloBandApp> createState() => _HelloBandAppState();
}

class _HelloBandAppState extends State<HelloBandApp> {
  late final HelloBandController controller;

  @override
  void initState() {
    super.initState();
    controller = HelloBandController();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HelloBand',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4C8DFF),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF7FAFF),
        cardTheme: const CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
        ),
        textTheme: const TextTheme(
          bodyMedium: TextStyle(color: Color(0xFF344054)),
          bodyLarge: TextStyle(color: Color(0xFF344054)),
          titleLarge: TextStyle(color: Color(0xFF101828)),
        ),
      ),
      home: RootGate(controller: controller),
    );
  }
}

class RootGate extends StatelessWidget {
  const RootGate({
    super.key,
    required this.controller,
  });

  final HelloBandController controller;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        if (!controller.connected) {
          return ConnectionScreen(controller: controller);
        }
        if (!controller.calibrationComplete) {
          return CalibrationScreen(controller: controller);
        }
        return CursorHomeScreen(controller: controller);
      },
    );
  }
}
