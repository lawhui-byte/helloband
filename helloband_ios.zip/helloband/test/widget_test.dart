import 'package:flutter_test/flutter_test.dart';
import 'package:helloband/main.dart';

void main() {
  testWidgets('HelloBand starts on connection screen', (tester) async {
    await tester.pumpWidget(const HelloBandApp());
    await tester.pumpAndSettle();

    expect(find.text('HelloBand'), findsOneWidget);
    expect(find.textContaining('Waveletech'), findsWidgets);
  });
}
