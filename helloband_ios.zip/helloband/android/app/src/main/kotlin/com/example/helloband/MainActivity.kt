package com.example.helloband

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
